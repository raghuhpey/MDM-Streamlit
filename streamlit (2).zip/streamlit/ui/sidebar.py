import streamlit as st
from streamlit_extras.stylable_container import stylable_container
from ui.home import reset_classification_working_state


def render_sidebar():
   flow = st.session_state.get("active_flow")
   choice = st.session_state.get("mode")
   with stylable_container(
       key="left_sidebar_panel",
       css_styles="""
       {
           background: #0b3d91;
           border-radius: 24px;
           padding: 1.5rem 1.2rem 1.75rem 1.2rem;
           min-height: calc(100vh - 40px);
           box-shadow: 0 6px 20px rgba(15, 23, 42, 0.10);
           border: 1px solid rgba(255,255,255,0.08);
       }
       button {
           border-radius: 14px !important;
           min-height: 48px !important;
           font-weight: 700 !important;
       }
       """,
   ):
       if flow is None:

        st.markdown('<div class="landing-brand-wrap">', unsafe_allow_html=True)

        st.image('/home/dataiku/workspace/code_studio-versioned/streamlit/assets/Alstom_logo.svg.png', use_container_width=False)

        st.markdown('<div class="brand-subtitle">AI-Parts Classifier</div>', unsafe_allow_html=True)

        st.markdown('<div class="brand-caption">Classification Assist Tool</div>', unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

        return

       else:
            
        st.image('/home/dataiku/workspace/code_studio-versioned/streamlit/assets/Alstom_logo.svg.png', use_container_width=False)

        st.markdown('<div class="brand-subtitle">AI - Parts Classifier</div>', unsafe_allow_html=True)

        st.markdown('<div class="brand-caption">Classification Assist Tool</div>', unsafe_allow_html=True)
 
 
       if flow is None:
            st.markdown('<div class="landing-brand-spacer-top"></div>', unsafe_allow_html=True)
            st.markdown('<div class="landing-brand-center"></div>', unsafe_allow_html=True)
            return
       if flow == "Classification":
           existing_selected = choice == "Classify Existing Parts"
           new_selected = choice == "Create New Parts"
           pred_jobs_selected = choice == "Runs"
           st.markdown('<div class="side-section-title">Choose</div>', unsafe_allow_html=True)
           if st.button(
               "Classify Existing Parts",
               key="btn_existing",
               use_container_width=True,
               type=("primary" if existing_selected else "secondary"),
           ):
               reset_classification_working_state()
               st.session_state["active_flow"] = "Classification"
               st.session_state["mode"] = "Classify Existing Parts"
               st.session_state["home_view"] = "upload"
               st.rerun()
           st.write("")
           if st.button(
               "Create New Parts",
               key="btn_new",
               use_container_width=True,
               type=("primary" if new_selected else "secondary"),
           ):
               reset_classification_working_state()
               st.session_state["active_flow"] = "Classification"
               st.session_state["mode"] = "Create New Parts"
               st.session_state["home_view"] = "upload"
               st.rerun()
           st.markdown('<div class="sidebar-divider"></div>', unsafe_allow_html=True)
           st.markdown('<div class="side-section-title">Section</div>', unsafe_allow_html=True)
           if st.button(
               "Runs",
               key="btn_prediction_jobs",
               use_container_width=True,
               type=("primary" if pred_jobs_selected else "secondary"),
           ):
               st.session_state["mode"] = "Runs"
               st.session_state["home_view"] = "upload"
               st.rerun()
           workflow_text = (
               "Classify/Create Parts",
               "Upload files, classify records, and review run history.",
           )
       elif flow == "Validation":
           val_jobs_selected = choice == "To Validate"
           golden_selected = choice == "Golden Dataset"
           st.markdown('<div class="side-section-title">Section</div>', unsafe_allow_html=True)
           if st.button(
               "To Validate",
               key="btn_validation_jobs",
               use_container_width=True,
               type=("primary" if val_jobs_selected else "secondary"),
           ):
               st.session_state["mode"] = "To Validate"
               st.session_state["home_view"] = "upload"
               st.rerun()
           st.write("")
           if st.button(
               "Golden Dataset",
               key="btn_golden_dataset",
               use_container_width=True,
               type=("primary" if golden_selected else "secondary"),
           ):
               st.session_state["mode"] = "Golden Dataset"
               st.session_state["home_view"] = "upload"
               st.rerun()
           workflow_text = (
               "Validation",
               "Validate predictions, approve records, and review golden dataset.",
           )
       elif flow == "Model Retraining":
           retraining_selected = choice == "Retraining"
           retraining_jobs_selected = choice == "Retraining Jobs"
           st.markdown('<div class="side-section-title">Section</div>', unsafe_allow_html=True)
           if st.button(
               "Retraining",
               key="btn_retraining",
               use_container_width=True,
               type=("primary" if retraining_selected else "secondary"),
           ):
               st.session_state["mode"] = "Retraining"
               st.session_state["home_view"] = "upload"
               st.rerun()
           st.write("")
           if st.button(
               "Retraining Jobs",
               key="btn_retraining_jobs",
               use_container_width=True,
               type=("primary" if retraining_jobs_selected else "secondary"),
           ):
               st.session_state["mode"] = "Retraining Jobs"
               st.session_state["home_view"] = "upload"
               st.rerun()
           workflow_text = (
               "Model Retraining",
               "Launch retraining workflows and monitor retraining jobs.",
           )
       else:
           workflow_text = ("Workflow", "Use the main panel to continue.")
       st.markdown('<div class="side-section-title">Workflow</div>', unsafe_allow_html=True)
       st.markdown(
           f"""
<div class="workflow-card">
<div class="workflow-title">{workflow_text[0]}</div>
<div class="workflow-text">{workflow_text[1]}</div>
</div>
           """,
           unsafe_allow_html=True,
       )