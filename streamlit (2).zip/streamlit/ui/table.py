from typing import Optional
import pandas as pd
import streamlit as st
from config.constants import APPROVED_COL, OUTPUT_COLS, PRED_COLS
from services.jobs import (
   get_or_create_validation_job,
   save_prediction_input_df,
   update_prediction_job_status,
)
from services.prediction import trigger_prediction_scenario, wait_for_prediction_completion
from utils.file_readers import calc_df_height, normalize_headers, sanitize_headers, view_with_bool_as_text
from utils.pagination import init_pagination_keys, on_jump_change, on_jump_down, on_jump_up, on_next, on_prev

def show_paginated_table(
   df: pd.DataFrame,
   page_size: int = 5,
   key: str = "tbl",
   fingerprint: Optional[str] = None,
   show_classify: bool = True,
   show_validation_button: bool = False,
   show_download_output_button: bool = False,
):
   if df is None or len(df) == 0:
       st.info("No data to show.")
       return
   init_pagination_keys(key)
   total_rows = len(df)
   total_pages = max((total_rows - 1) // page_size + 1, 1)
   st.session_state[f"{key}_total_pages"] = total_pages
   if fingerprint is not None and st.session_state.get(f"{key}_fp") != fingerprint:
       st.session_state[f"{key}_fp"] = fingerprint
       st.session_state[f"{key}_page"] = 1
       st.session_state[f"{key}_jump"] = 1
   left, mid, right = st.columns([1.2, 2.6, 1.8], gap="small")
   with left:
       c1, c2 = st.columns([1, 1], gap="small")
       with c1:
           st.button(
               "Prev",
               disabled=(st.session_state[f"{key}_page"] <= 1),
               on_click=on_prev,
               args=(key,),
               key=f"{key}_prev_btn",
           )
       with c2:
           st.button(
               "Next",
               disabled=(st.session_state[f"{key}_page"] >= total_pages),
               on_click=on_next,
               args=(key,),
               key=f"{key}_next_btn",
           )
   page = st.session_state[f"{key}_page"]
   start_idx = (page - 1) * page_size
   end_idx = min(start_idx + page_size, total_rows)
   start_disp = start_idx + 1 if total_rows else 0
   with mid:
       st.markdown(
           f"<div class='page-status-rect'>Page <b>{page}</b> / <b>{total_pages}</b> • Rows <b>{start_disp}-{end_idx}</b> of <b>{total_rows:,}</b></div>",
           unsafe_allow_html=True,
       )
   with right:
       up_col, num_col, down_col = st.columns([0.4, 1.4, 0.4], gap="small")
       with up_col:
           st.button(
               "▲",
               key=f"{key}_jump_up",
               disabled=(page >= total_pages),
               on_click=on_jump_up,
               args=(key,),
           )
       with num_col:
           st.number_input(
               "Go to page",
               label_visibility="collapsed",
               min_value=1,
               max_value=total_pages,
               step=1,
               key=f"{key}_jump",
               on_change=on_jump_change,
               args=(key,),
           )
       with down_col:
           st.button(
               "▼",
               key=f"{key}_jump_down",
               disabled=(page <= 1),
               on_click=on_jump_down,
               args=(key,),
           )
   page_df = df.iloc[start_idx:end_idx].copy()
   page_df.index = range(start_idx + 1, end_idx + 1)
   page_df.index.name = "#"
   page_df = sanitize_headers(page_df.copy())
   st.dataframe(
       view_with_bool_as_text(page_df),
       use_container_width=True,
       height=calc_df_height(len(page_df)),
   )
   if st.session_state.get("prediction_completed_message"):
       st.success("Classification completed. Output is shown below and ready for validation.")
       st.session_state["prediction_completed_message"] = False
   clicked = False
   if show_download_output_button:
       csv_data = df.to_csv(index=False).encode("utf-8")
       st.download_button(
           "Download Output File",
           data=csv_data,
           file_name="prediction_output.csv",
           mime="text/csv",
           key=f"{key}_download_output_btn",
       )
   elif show_classify and show_validation_button:
       left_actions, right_actions = st.columns([1, 1])
       with left_actions:
           clicked = st.button("Classify", key=f"{key}_classify_btn")
       with right_actions:
           target_df = st.session_state.get("prediction_output_df")
           can_validate = isinstance(target_df, pd.DataFrame) and len(target_df) > 0 and (
               all(c in target_df.columns for c in OUTPUT_COLS) or (APPROVED_COL in target_df.columns)
           )
           if st.button("→ Go to Validation", key=f"{key}_goto_validation_btn", disabled=not can_validate):
               prediction_job_id = st.session_state.get("current_prediction_job_id")
               if prediction_job_id and not st.session_state.get("current_validation_job_id"):
                   st.session_state["current_validation_job_id"] = get_or_create_validation_job(prediction_job_id)
               st.session_state["home_view"] = "validation"
               st.rerun()
   elif show_classify:
       clicked = st.button("Classify", key=f"{key}_classify_btn")
   elif show_validation_button:
       target_df = st.session_state.get("prediction_output_df")
       can_validate = isinstance(target_df, pd.DataFrame) and len(target_df) > 0 and (
           all(c in target_df.columns for c in OUTPUT_COLS) or (APPROVED_COL in target_df.columns)
       )
       if st.button("→ Go to Validation", key=f"{key}_goto_validation_btn", disabled=not can_validate):
           prediction_job_id = st.session_state.get("current_prediction_job_id")
           if prediction_job_id and not st.session_state.get("current_validation_job_id"):
               st.session_state["current_validation_job_id"] = get_or_create_validation_job(prediction_job_id)
           st.session_state["home_view"] = "validation"
           st.rerun()
   if clicked:
       data_to_classify = normalize_headers(df.copy())
       prediction_job_id = st.session_state.get("current_prediction_job_id")
       if not prediction_job_id:
           st.error("Prediction job not found for this file. Please upload the file again.")
           return
       if all(col in df.columns for col in PRED_COLS) and df[PRED_COLS].notna().any().any():
           st.warning("This file is already classified.")
           return
       try:
           save_prediction_input_df(prediction_job_id, data_to_classify)
           update_prediction_job_status(prediction_job_id, "running")
           trigger_prediction_scenario(prediction_job_id)
           status, refreshed_df, _ = wait_for_prediction_completion(prediction_job_id)
           if status == "completed":
            if refreshed_df is not None:
                st.session_state["prediction_output_df"] = refreshed_df
            st.session_state["uploaded_df"] = data_to_classify.copy()
            st.session_state["run_view_mode"] = True
            st.session_state["home_view"] = "upload"
            st.session_state["active_flow"] = "Classification"
            st.session_state["mode"] = "Classify Existing Parts"
            st.session_state["prediction_display_mode"] = "show_both"
            st.session_state["prediction_completed_message"] = True
            
            if not st.session_state.get("current_validation_job_id"):
                st.session_state["current_validation_job_id"] = get_or_create_validation_job(prediction_job_id)
            st.rerun()
       except Exception as e:
           update_prediction_job_status(prediction_job_id, "failed", error_message=str(e))
           st.error(f"Failed to start prediction job: {e}")