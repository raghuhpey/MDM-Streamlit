import streamlit as st

CUSTOM_CSS = """
<style>
:root {
   --bg: #f5f7fb;
   --card: #ffffff;
   --text: #1f2937;
   --muted: #6b7280;
   --border: #e5e7eb;
   --primary: #d92323;
   --shadow: 0 6px 20px rgba(15, 23, 42, 0.10);
   --header-dark: #4b5563;
}
html, body, [class*="block-container"] {
   font-size: 16px;
   color: var(--text);
}
.stApp {
   background: var(--bg);
}
.main .block-container {
   padding-top: 0.35rem;
   padding-right: 0.45rem;
   padding-bottom: 0.55rem;
   padding-left: 0.45rem;
   max-width: 100%;
}
/* Tabs */
.stTabs [role="tablist"] {
   background: #ececec;
   border-radius: 14px;
   padding: 8px 10px;
   gap: 1rem;
   margin-bottom: 1.2rem;
   box-shadow: inset 0 0 0 1px #e5e7eb;
}
.stTabs [role="tab"] {
   height: 52px;
   border-radius: 10px;
   padding: 0.8rem 1.6rem;
   background: transparent;
   color: #4b5563;
   border: none !important;
   font-weight: 600;
   font-size: 1rem;
}
.stTabs [aria-selected="true"] {
   background: var(--primary) !important;
   color: #ffffff !important;
   box-shadow: 0 4px 10px rgba(217, 35, 35, 0.25);
}
.stTabs [data-baseweb="tab-highlight"] {
   display: none !important;
}
/* Sidebar text only */
.brand-title {
   font-size: 2rem;
   font-weight: 800;
   color: #ffffff;
   margin-bottom: 0.2rem;
}
.brand-subtitle {
   font-size: 1.2rem;
   color: #ffd7d7 !important;
   font-weight: 800;
   margin-bottom: 0.15rem;
}

.brand-caption {
   color: #dbe7ff !important;
   font-weight: 600;
   font-size: 0.95rem;
   margin-bottom: 2rem;
}

.side-section-title {
   font-size: 0.95rem;
   font-weight: 700;
   color: #ffffff !important;
   margin-top: 1rem;
   margin-bottom: 0.5rem;
}

.landing-brand-wrap {
   min-height: calc(100vh - 500px);
   display: flex;
   flex-direction: column;
   justify-content: center;
   align-items: center;
   text-align: center;
}
.landing-brand-wrap .brand-title {
   justify-content: center;
   text-align: center;
},
.landing-brand-wrap .brand-subtitle,
.landing-brand-wrap .brand-caption {
   text-align: center;
   width: 100%;
}
.sidebar-divider {
   height: 1px;
   background: rgba(255,255,255,0.20);
   margin: 1.1rem 0 0.9rem 0;
}
.workflow-card {
   background: var(--card);
   border: 1px solid var(--border);
   border-radius: 16px;
   padding: 1rem;
   box-shadow: var(--shadow);
   margin-top: 0.25rem;
}
.workflow-title {
   color: #111827;
   font-weight: 700;
   margin-bottom: 0.3rem;
}
.workflow-text {
   color: var(--muted);
   font-size: 0.9rem;
}
/* Runs / Validation headers */
.jobs-header-row {
   display: grid;
   grid-template-columns: 1.8fr 2.4fr 1.5fr 1fr 1.4fr 2fr 1.8fr;
   gap: 12px;
   margin: 0.6rem 0 1rem 0;
}
.jobs-header-cell {
   background: var(--header-dark);
   color: #ffffff;
   border-radius: 12px;
   padding: 12px 14px;
   font-weight: 700;
   font-size: 0.95rem;
   line-height: 1.2;
   text-align: left;
}
.validation-header-row {
   display: grid;
   grid-template-columns: 0.5fr 1.25fr 1fr 1.3fr 1.9fr 1.3fr;
   gap: 12px;
   margin: 0.6rem 0 1rem 0;
}
.validation-header-cell {
   background: var(--header-dark);
   color: #ffffff;
   border-radius: 12px;
   padding: 6px 7px;
   font-weight: 700;
   font-size: 0.95rem;
   line-height: 1.2;
   text-align: left;
}
.toolbar-rect {
   background: #ffffff !important;
   border: 1px solid var(--border) !important;
   border-radius: 14px !important;
   padding: 12px 14px !important;
   margin: 0 0 12px 0 !important;
   box-shadow: var(--shadow);
}
.page-status-rect {
   text-align: center;
   font-weight: 600;
   color: #1f2937;
   line-height: 32px;
}
[data-testid="stDataFrame"] {
   border-radius: 14px;
   overflow: hidden;
   border: 1px solid var(--border);
   box-shadow: var(--shadow);
}
.table-footer {
   margin-top: 12px;
}
.table-footer .stButton > button {
   background: var(--primary) !important;
   color: #fff !important;
   border: 1px solid var(--primary) !important;
   border-radius: 10px !important;
   height: 40px !important;
   padding: 0 18px !important;
}
[data-testid="stNumberInput"] [data-baseweb="button-group"] {
   display: none !important;
}
[data-testid="stNumberInput"] input {
   text-align: center;
}

button[kind = "primary"] {
   background-color: #ef4444 !important;
   color: white !important;
}
</style>
"""

def apply_styles():
   st.markdown(CUSTOM_CSS, unsafe_allow_html=True)