import streamlit as st
import pandas as pd
from services.jobs import load_golden_dataset
from utils.file_readers import calc_df_height, view_with_bool_as_text

def show_golden_dataset_page():
   st.markdown("## Golden Dataset")
   golden_df = load_golden_dataset()
   if golden_df is None or len(golden_df) == 0:
       st.info("Golden dataset is empty. Approve rows from validation to build it.")
       return
   st.caption(f"Approved rows: {len(golden_df):,}")
   display_df = golden_df.copy()
   st.dataframe(
       view_with_bool_as_text(display_df),
       use_container_width=True,
       height=calc_df_height(min(len(display_df), 12)),
   )
   st.download_button(
       "Download Golden Dataset (CSV)",
       data=golden_df.to_csv(index=False).encode("utf-8"),
       file_name="golden_dataset.csv",
       mime="text/csv",
       key="golden_dataset_download",
   )