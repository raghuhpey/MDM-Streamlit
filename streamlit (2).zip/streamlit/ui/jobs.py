import streamlit as st
from services.dataiku_context import USER_ID
from services.jobs import (
   list_prediction_jobs_for_user,
   list_validation_jobs_for_user,
   open_prediction_job_in_preview,
   open_validation_job,
)

def _render_job_status_badge(status: str):
   color = {
       "uploaded": "#64748b",
       "running": "#2563eb",
       "completed": "#16a34a",
       "failed": "#dc2626",
       "pending": "#f59e0b",
       "in_progress": "#2563eb",
   }.get(status, "#64748b")
   st.markdown(
       f"<span style='background:{color};color:white;padding:0.2rem 0.55rem;border-radius:999px;font-size:0.8rem;font-weight:600;'>{status}</span>",
       unsafe_allow_html=True,
   )

def show_prediction_jobs_page():
   st.markdown("## Runs")
   jobs = list_prediction_jobs_for_user(USER_ID)
   if not jobs:
       st.info("No Runs found for your user.")
       return
   st.markdown(
       """
<div class="jobs-header-row">
<div class="jobs-header-cell">Run ID</div>
<div class="jobs-header-cell">File Name</div>
<div class="jobs-header-cell">Created By</div>
<div class="jobs-header-cell">Rows</div>
<div class="jobs-header-cell">Status</div>
<div class="jobs-header-cell">Created</div>
<div class="jobs-header-cell">Actions</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   col_spec = [1.8, 2.4, 1.5, 1.0, 1.4, 2.0, 1.8]
   for job in jobs:
       cols = st.columns(col_spec, gap="small")
       cols[0].write(job.get("prediction_job_id", ""))
       cols[1].write(job.get("file_name", ""))
       cols[2].write(job.get("created_by", "Unknown"))
       cols[3].write(job.get("row_count", ""))
       with cols[4]:
           _render_job_status_badge(job.get("status", "unknown"))
       cols[5].write(job.get("created_time", ""))
       with cols[6]:
           can_view = job.get("status") == "completed"
           if st.button(
               "View",
               key=f"view_run_{job['prediction_job_id']}",
               use_container_width=True,
               disabled=not can_view,
           ):
               open_prediction_job_in_preview(job["prediction_job_id"], view="output")
       st.divider()


def show_validation_jobs_page():
   st.markdown("## To Validate")
   jobs = list_validation_jobs_for_user(USER_ID)
   if not jobs:
       st.info("No validation jobs found for your user.")
       return
   st.markdown(
       """
<div class="validation-header-row">
<div class="validation-header-cell">S. No</div>
<div class="validation-header-cell">Prediction Job</div>
<div class="validation-header-cell">Prediction Created By</div>
<div class="validation-header-cell">Approved Rows</div>
<div class="validation-header-cell">Status</div>
<div class="validation-header-cell">Updated</div>
<div class="validation-header-cell">Action</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   col_spec = [0.7, 1.8, 1.7, 0.5, 1.2, 1.8, 1.2]
   for idx, job in enumerate(jobs, start=1):
       cols = st.columns(col_spec, gap="small")
       approved_rows = int(job.get("approved_rows", 0) or 0)
       initial_total_rows = job.get("initial_total_rows", None)
       remaining_rows = int(job.get("remaining_rows", 0) or 0)
       # Fallback for older jobs that do not yet have initial_total_rows saved
       if initial_total_rows is None:
           initial_total_rows = approved_rows + remaining_rows
       initial_total_rows = int(initial_total_rows or 0)
       progress_text = f"{approved_rows}/{initial_total_rows}"
       cols[0].write(idx)
       cols[1].write(job.get("prediction_job_id", ""))
       cols[2].write(job.get("prediction_job_created_by", "Unknown"))
       cols[3].write(progress_text)
       with cols[4]:
           _render_job_status_badge(job.get("status", "unknown"))
       cols[5].write(job.get("last_updated", ""))
       if cols[6].button(
           "Continue",
           key=f"continue_val_{job['validation_job_id']}",
           use_container_width=True,
       ):
           open_validation_job(job["validation_job_id"])
       st.divider()