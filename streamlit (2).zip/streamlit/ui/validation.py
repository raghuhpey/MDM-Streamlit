import math
import pandas as pd
import streamlit as st
from config.constants import (
   APPROVED_COL,
   OUTPUT_COLS,
   UNSPSC_LOOKUP_PATH,
   UNSPSC_CODE_COL,
   UNSPSC_DESC_COL,
)
from services.dataiku_context import USER_ID
from services.jobs import (
   _find_validation_job,
   load_jobs_metadata,
   update_validation_job,
   load_unspsc_lookup_df,
   build_unspsc_description_map,
   append_row_to_golden_dataset,
)
from utils.pagination import init_pagination_keys, on_jump_change, on_next, on_prev

@st.cache_data(show_spinner=False)
def get_unspsc_description_map():
   lookup_df = load_unspsc_lookup_df(UNSPSC_LOOKUP_PATH)
   return build_unspsc_description_map(lookup_df, UNSPSC_CODE_COL, UNSPSC_DESC_COL)

def render_prediction_descriptions(row, desc_map):
   pred_pairs = [
       ("Model 1", row.get("Model 1 OP")),
       ("Model 2", row.get("Model 2 OP")),
       ("Model 3", row.get("Model 3 OP")),
       ("LLM Judge", row.get("LLM as a Judge OP")),
   ]
   lines = []
   for label, code in pred_pairs:
       code_str = "" if pd.isna(code) else str(code).strip()
       desc = desc_map.get(code_str, "Description not found")
       if code_str:
           lines.append((label, code_str, desc))
   if not lines:
       st.write("-")
       return
   for label, code_str, desc in lines:
       st.markdown(
           f"""
<div style="margin-bottom:0.75rem;">
<div style="font-weight:700;">{label}: {code_str}</div>
<div style="color:#475569; font-size:0.92rem;">{desc}</div>
</div>
           """,
           unsafe_allow_html=True,
       )

def show_validation_page(page_size: int = 5, key: str = "val"):
   df = st.session_state.get("uploaded_df")
   if df is None or len(df) == 0:
       st.info("No data to validate. Go back and run a classification.")
       return
   desc_map = get_unspsc_description_map()
   for c in OUTPUT_COLS:
       if c not in df.columns:
           df[c] = None
   if "Explanation" not in df.columns:
       df["Explanation"] = None
   if APPROVED_COL not in df.columns:
       df[APPROVED_COL] = None
   init_pagination_keys(key)
   total_rows = len(df)
   total_pages = max((total_rows - 1) // page_size + 1, 1)
   st.session_state[f"{key}_total_pages"] = total_pages
   if st.session_state.get(f"{key}_page", 1) > total_pages:
    st.session_state[f"{key}_page"] = total_pages
   if st.session_state.get(f"{key}_jump", 1) > total_pages:
    st.session_state[f"{key}_jump"] = total_pages
   st.markdown("## Validation")
   st.caption("Pick a model prediction to set the revised code, or click Edit and type your own.")
   left, mid, right = st.columns([1.2, 2.6, 1.8], gap="small")
   with left:
       c1, c2 = st.columns([1, 1], gap="small")
       c1.button(
           "Prev",
           disabled=(st.session_state[f"{key}_page"] <= 1),
           on_click=on_prev,
           args=(key,),
           key=f"{key}_prev_btn",
       )
       c2.button(
           "Next",
           disabled=(st.session_state[f"{key}_page"] >= total_pages),
           on_click=on_next,
           args=(key,),
           key=f"{key}_next_btn",
       )
   page = st.session_state[f"{key}_page"]
   start_idx = (page - 1) * page_size
   end_idx = min(start_idx + page_size, total_rows)
   with mid:
       st.markdown(f"Page **{page}** / **{total_pages}**")
   with right:
       st.number_input(
           "Go to page",
           label_visibility="collapsed",
           min_value=1,
           max_value=total_pages,
           step=1,
           key=f"{key}_jump",
           on_change=on_jump_change,
           args=(key,),
       )
   page_df = df.iloc[start_idx:end_idx].copy()
   page_df["_row_pos"] = list(range(start_idx, end_idx))
   candidate_short_cols = [
       "short_description",
       "short_description_(english)",
       "short_description_(en)",
       "short_desc",
       "shortdesc",
       "description",
       "item_description",
   ]
   short_col = next((c for c in df.columns if c.lower() in candidate_short_cols), None)
   if short_col is None:
       str_cols = [c for c in df.columns if df[c].dtype == "object"]
       short_col = str_cols[0] if str_cols else df.columns[0]
   essential = set([short_col, "Explanation", APPROVED_COL] + OUTPUT_COLS + ["_row_pos"])
   candidate_other_cols = [c for c in df.columns if c not in essential]
   other_cols = st.multiselect(
       "Input Paramter to show (per row):",
       options=candidate_other_cols,
       default=st.session_state.get(f"{key}_other_cols", candidate_other_cols[:4]),
       key=f"{key}_other_cols",
   )
   expand_all = st.toggle(
       "Expand all other sections by default",
       value=False,
       key=f"{key}_expand_all",
   )
   # 6-column layout
   header_widths = [1.2, 2.3, 1.4, 1.9, 1.1, 0.9]
   hdr_cols = st.columns(header_widths, gap="large")
   header_labels = [
       "Short Description",
       "Explanation",
       "Model Prediction",
       "Predicted Code Description",
       "Revised Code",
       "Approve",
   ]
   for i, lbl in enumerate(header_labels):
       hdr_cols[i].markdown(f"**{lbl}**")
   def _fmt_val(v):
       if v is True:
           return "Yes"
       if v is False:
           return "No"
       if v is None:
           return ""
       try:
           if isinstance(v, float) and math.isnan(v):
               return ""
       except Exception:
           pass
       return str(v)
   for _, row in page_df.iterrows():
       row_pos = int(row["_row_pos"])
       row_cols = st.columns(header_widths, gap="large")
       # Column 1: Short Description
       row_cols[0].markdown(f"**{_fmt_val(row.get(short_col, ''))}**")
       # Column 2: Explanation
       with row_cols[1]:
           st.text_area(
               "Explanation",
               value=_fmt_val(row.get("Explanation", "")),
               key=f"{key}_expl_{row_pos}",
               height=120,
               label_visibility="collapsed",
               disabled=True,
           )
       # Column 3: Model Prediction
       with row_cols[2]:
           model_pairs = []
           for col_name, nice_label in [
               ("Model 1 OP", "Model 1"),
               ("Model 2 OP", "Model 2"),
               ("Model 3 OP", "Model 3"),
               ("LLM as a Judge OP", "LLM Judge"),
           ]:
               raw = row.get(col_name)
               s = "" if raw is None or (isinstance(raw, float) and math.isnan(raw)) else str(raw).strip()
               if s:
                   model_pairs.append((f"{nice_label}: {s}", s))
           radio_labels = ["Edit"] + [lbl for (lbl, _) in model_pairs]
           label_to_value = {lbl: val for (lbl, val) in model_pairs}
           label_to_value["Edit"] = None
           approved_val = df.iat[row_pos, df.columns.get_loc(APPROVED_COL)]
           approved_str = "" if approved_val in (None, "") else str(approved_val).strip()
           default_label = next((lbl for lbl, val in model_pairs if val == approved_str), "Edit")
           picked_label = st.radio(
               "Model Prediction",
               options=radio_labels,
               index=radio_labels.index(default_label),
               key=f"{key}_radio_{row_pos}",
               label_visibility="collapsed",
           )
       # Column 4: Predicted Code Description
       with row_cols[3]:
           render_prediction_descriptions(row, desc_map)
       # Column 5: Revised Code
       with row_cols[4]:
           manual_key = f"{key}_manual_{row_pos}"
           if picked_label != "Edit":
               selected_code = label_to_value[picked_label]
               df.iat[row_pos, df.columns.get_loc(APPROVED_COL)] = selected_code
               st.session_state[manual_key] = selected_code
           elif manual_key not in st.session_state:
               st.session_state[manual_key] = approved_str
           manual = st.text_input(
               "Revised Code",
               key=manual_key,
               label_visibility="collapsed",
               placeholder="Enter UNSPSC code",
               disabled=(picked_label != "Edit"),
           )
           if picked_label == "Edit":
               new_val = (manual or "").strip()
               df.iat[row_pos, df.columns.get_loc(APPROVED_COL)] = new_val if new_val else None
       # Column 6: Approve
       with row_cols[5]:
        if st.button("Approve", key=f"{key}_approve_{row_pos}", use_container_width=True):
            # Row to move to golden dataset
            approved_row = df.iloc[row_pos].copy()
            approved_payload = approved_row.to_dict()
            # Append to golden dataset first
            updated_golden = append_row_to_golden_dataset(
                approved_payload,
                approved_by_user=USER_ID,
            )
            st.session_state["golden_df"] = updated_golden
            # Remove approved row from validation dataframe
            updated_df = df.drop(index=row_pos).reset_index(drop=True)
            # Persist reduced validation dataframe immediately
            validation_job_id = st.session_state.get("current_validation_job_id")
            if validation_job_id:
                update_validation_job(
                    validation_job_id,
                    status="in_progress",
                    validation_df=updated_df,
                )
            # Update session state after save
            st.session_state["uploaded_df"] = updated_df
            # Fix page number if current page exceeds new total pages
            total_rows_after = len(updated_df)
            total_pages_after = max((total_rows_after - 1) // page_size + 1, 1)
            if st.session_state.get(f"{key}_page", 1) > total_pages_after:
                st.session_state[f"{key}_page"] = total_pages_after
            st.success("Row approved and moved to golden dataset.")
            st.rerun()
       if other_cols:
           with st.expander("Input Parameters", expanded=expand_all):
               for oc in other_cols:
                   st.caption(f"**{oc}**")
                   st.text_area(
                       oc,
                       value=_fmt_val(row.get(oc)),
                       key=f"{key}_other_{oc}_{row_pos}",
                       height=70,
                       label_visibility="collapsed",
                       disabled=True,
                   )
       st.divider()
   st.session_state["uploaded_df"] = df
   validation_job_id = st.session_state.get("current_validation_job_id")
   if validation_job_id:
       existing_jobs = load_jobs_metadata()
       val_job = _find_validation_job(existing_jobs, validation_job_id)
       auto_status = val_job.get("status", "in_progress") if val_job else "in_progress"
       if auto_status == "pending":
           auto_status = "in_progress"
       update_validation_job(validation_job_id, status=auto_status, validation_df=df)
   left_btn, right_btn = st.columns([1, 1])
   if left_btn.button("← Back to upload & preview", key=f"{key}_back"):
    st.session_state["home_view"] = "upload"
    st.rerun()
   if right_btn.button("Mark Validation Complete", key=f"{key}_complete"):
    if validation_job_id:
        update_validation_job(validation_job_id, status="completed", validation_df=df)
        st.success("Validation job marked as completed.")
   st.download_button(
       "Download Validated (CSV)",
       data=df.to_csv(index=False).encode("utf-8"),
       file_name="validated_output.csv",
       mime="text/csv",
       key=f"{key}_validated_dl",
   )