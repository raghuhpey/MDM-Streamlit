import hashlib

import pandas as pd

import streamlit as st

from config.constants import SUPPORTED_UPLOAD_TYPES

from services.jobs import create_prediction_job

from ui.golden import show_golden_dataset_page

from ui.jobs import show_prediction_jobs_page, show_validation_jobs_page

from ui.table import show_paginated_table

from ui.validation import show_validation_page

from utils.file_readers import (

    get_excel_sheet_names,

    human_size,

    load_json_as_df,

    normalize_headers,

    preview_non_tabular_file,

    read_csv_from_bytes,

    read_excel_sheet_from_bytes,

    sanitize_headers,

)


def reset_classification_working_state():

    st.session_state["uploaded_name"] = None

    st.session_state["uploaded_bytes"] = None

    st.session_state["uploaded_ext"] = None

    st.session_state["uploaded_sheet"] = None

    st.session_state["uploaded_df"] = None

    st.session_state["prediction_output_df"] = None

    st.session_state["prediction_completed_message"] = False

    st.session_state["prediction_display_mode"] = "input_only"

    st.session_state["current_prediction_job_id"] = None

    st.session_state["current_validation_job_id"] = None

    st.session_state["current_upload_fp"] = None

    st.session_state["home_view"] = "upload"

    st.session_state["run_view_mode"] = False


def _render_output_section():

    output_df = st.session_state.get("prediction_output_df")

    display_mode = st.session_state.get("prediction_display_mode", "input_only")

    run_view_mode = st.session_state.get("run_view_mode", False)

    if display_mode == "show_both" and isinstance(output_df, pd.DataFrame) and len(output_df) > 0:

        st.markdown("### Output Table")

        show_paginated_table(

            output_df,

            page_size=5,

            key="prediction_output",

            fingerprint=st.session_state.get("current_prediction_job_id", "prediction_output"),

            show_classify=False,

            show_validation_button=(not run_view_mode),

            show_download_output_button=run_view_mode,

        )


def preview_from_cached():

    name = st.session_state["uploaded_name"]

    file_bytes = st.session_state["uploaded_bytes"]

    ext = st.session_state["uploaded_ext"]

    sheet = st.session_state["uploaded_sheet"]

    run_view_mode = st.session_state.get("run_view_mode", False)

    if not (name and file_bytes and ext):

        return

    if st.session_state["uploaded_df"] is not None:

        fp = f"{name}|{len(file_bytes)}" + (f"|{sheet}" if sheet else "")

        st.markdown("### Preview Table")

        show_paginated_table(

            st.session_state["uploaded_df"],

            page_size=5,

            key=f"home_{ext.strip('.')}",

            fingerprint=fp,

            show_classify=(not run_view_mode),

            show_validation_button=False,

            show_download_output_button=False,

        )

        _render_output_section()

        return

    if ext == ".csv":

        df = normalize_headers(sanitize_headers(read_csv_from_bytes(file_bytes)))

        st.markdown("### Preview Table")

        show_paginated_table(

            df,

            page_size=5,

            key="home_csv",

            fingerprint=f"{name}|{len(file_bytes)}",

            show_classify=(not run_view_mode),

            show_validation_button=False,

            show_download_output_button=False,

        )

        _render_output_section()

    elif ext in (".xlsx", ".xls"):

        sheets = get_excel_sheet_names(file_bytes)

        sheet_sel = sheet if sheet in sheets else sheets[0]

        df = normalize_headers(sanitize_headers(read_excel_sheet_from_bytes(file_bytes, sheet_sel)))

        st.markdown("### Preview Table")

        show_paginated_table(

            df,

            page_size=5,

            key="home_xlsx",

            fingerprint=f"{name}|{len(file_bytes)}|{sheet_sel}",

            show_classify=(not run_view_mode),

            show_validation_button=False,

            show_download_output_button=False,

        )

        _render_output_section()

    elif ext == ".json":

        df = load_json_as_df(file_bytes)

        if df is not None:

            st.markdown("### Preview Table")

            show_paginated_table(

                normalize_headers(sanitize_headers(df)),

                page_size=5,

                key="home_json",

                fingerprint=name,

                show_classify=(not run_view_mode),

                show_validation_button=False,

                show_download_output_button=False,

            )

            _render_output_section()

    else:

        preview_non_tabular_file(name, ext, file_bytes)


def render_home_content():

    flow = st.session_state.get("active_flow")

    mode = st.session_state.get("mode")

    home_view = st.session_state.get("home_view", "upload")

    run_view_mode = st.session_state.get("run_view_mode", False)

    # Validation detail page must take priority

    if home_view == "validation":

        show_validation_page(page_size=5, key="val")

        return

    # Validation flow

    if flow == "Validation":

        if mode == "To Validate":

            show_validation_jobs_page()

            return

        if mode == "Golden Dataset":

            show_golden_dataset_page()

            return

    # Model Retraining flow

    if flow == "Model Retraining":

        if mode == "Retraining":

            st.markdown("## Retraining")

            st.info("Retraining screen goes here.")

            return

        if mode == "Retraining Jobs":

            st.markdown("## Retraining Jobs")

            st.info("Retraining jobs list goes here.")

            return

    # Classification flow

    if mode == "Runs":

        show_prediction_jobs_page()

        return

    if mode == "Create New Parts":

        st.info("This section is reserved for manually creating new parts in a future phase.")

        return

    current_df = st.session_state.get("uploaded_df")

    uploaded = None

    if not run_view_mode:

        uploaded = st.file_uploader(

            "Upload file to classify",

            type=SUPPORTED_UPLOAD_TYPES,

            accept_multiple_files=False,

            key="uploader_main",

        )

    loaded_job_id = st.session_state.get("current_prediction_job_id")

    if loaded_job_id and not run_view_mode:

        st.caption(f"Current Prediction Job: {loaded_job_id}")

    # Fresh upload path

    if uploaded:

        name = uploaded.name

        ext = "." + name.lower().split(".")[-1] if "." in name else ""

        file_bytes = uploaded.getvalue()

        fp_hash = hashlib.md5(file_bytes).hexdigest()

        base_upload_fp = f"{name}|{ext}|{fp_hash}"

        st.caption(f"Name: {name} | Type: {ext.upper()} | Size: {human_size(len(file_bytes))}")

        st.session_state["uploaded_name"] = name

        st.session_state["uploaded_bytes"] = file_bytes

        st.session_state["uploaded_ext"] = ext

        try:

            df = None

            preview_key = "home_generic"

            fingerprint = base_upload_fp

            if ext == ".csv":

                df = read_csv_from_bytes(file_bytes)

                preview_key = "home_csv"

            elif ext in (".xlsx", ".xls"):

                sheets = get_excel_sheet_names(file_bytes)

                default_sheet = st.session_state.get("uploaded_sheet")

                default_index = sheets.index(default_sheet) if default_sheet in sheets else 0

                sheet_sel = st.selectbox("Sheet", sheets, index=default_index)

                st.session_state["uploaded_sheet"] = sheet_sel

                df = read_excel_sheet_from_bytes(file_bytes, sheet_sel)

                preview_key = "home_xlsx"

                fingerprint = f"{base_upload_fp}|{sheet_sel}"

            elif ext == ".json":

                df = load_json_as_df(file_bytes)

                preview_key = "home_json"

            else:

                preview_non_tabular_file(name, ext, file_bytes)

            if df is not None:

                df = normalize_headers(sanitize_headers(df))

                st.session_state["uploaded_df"] = df

                current_df = df

                is_new_upload = st.session_state.get("current_upload_fp") != fingerprint

                if is_new_upload:

                    st.session_state["prediction_output_df"] = None

                    st.session_state["prediction_completed_message"] = False

                    st.session_state["current_validation_job_id"] = None

                    st.session_state["prediction_display_mode"] = "input_only"

                    st.session_state["run_view_mode"] = False

                    st.session_state["home_view"] = "upload"

                    prediction_job_id = create_prediction_job(name, ext, file_bytes, df)

                    st.session_state["current_prediction_job_id"] = prediction_job_id

                    st.session_state["current_upload_fp"] = fingerprint

                    st.success(f"Prediction job created: {prediction_job_id}")

                st.markdown("### Preview Table")

                show_paginated_table(

                    current_df,

                    page_size=5,

                    key=preview_key,

                    fingerprint=fingerprint,

                    show_classify=(not run_view_mode),

                    show_validation_button=False,

                    show_download_output_button=False,

                )

                _render_output_section()

        except Exception as e:

            st.error(f"Preview failed: {e}")

        return

    # Strong, explicit view-mode rendering to avoid blank screens

    if run_view_mode:

        current_df = st.session_state.get("uploaded_df")

        output_df = st.session_state.get("prediction_output_df")

        if isinstance(current_df, pd.DataFrame) and len(current_df) > 0:

            st.markdown("### Preview Table")

            show_paginated_table(

                current_df,

                page_size=5,

                key="view_preview",

                fingerprint=st.session_state.get("current_prediction_job_id", "view_preview"),

                show_classify=False,

                show_validation_button=False,

                show_download_output_button=False,

            )

        if isinstance(output_df, pd.DataFrame) and len(output_df) > 0:

            st.markdown("### Output Table")

            show_paginated_table(

                output_df,

                page_size=5,

                key="view_output",

                fingerprint=st.session_state.get("current_prediction_job_id", "view_output"),

                show_classify=False,

                show_validation_button=False,

                show_download_output_button=True,

            )

            return

        st.warning("No data available to display.")

        return

    # Re-render existing working state after rerun

    if isinstance(current_df, pd.DataFrame) and len(current_df) > 0:

        st.markdown("### Preview Table")

        show_paginated_table(

            current_df,

            page_size=5,

            key="job_loaded",

            fingerprint=st.session_state.get("current_prediction_job_id", "loaded"),

            show_classify=True,

            show_validation_button=False,

            show_download_output_button=False,

        )

        _render_output_section()

    elif st.session_state.get("uploaded_name") and st.session_state.get("uploaded_bytes"):

        preview_from_cached()

    else:

        st.info("Upload a supported file to preview, classify, validate, and download results.")

    if st.session_state.get("uploaded_df") is not None and not run_view_mode:

        st.download_button(

            "Download Output File (CSV)",

            data=st.session_state["uploaded_df"].to_csv(index=False).encode("utf-8"),

            file_name="working_classification_progress.csv",

            mime="text/csv",

            key="download_working_csv",

        )
 