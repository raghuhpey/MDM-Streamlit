import dataiku

from config.constants import FOLDER_ID


def get_current_user() -> str:
    client = dataiku.api_client()
    auth_info = client.get_auth_info()
    return auth_info.get("userForImpersonation") or auth_info.get("user")


USER_ID = get_current_user()
folder = dataiku.Folder(FOLDER_ID)
