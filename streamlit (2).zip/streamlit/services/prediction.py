import time

import dataiku
import streamlit as st

from config.constants import PREDICTION_SCENARIO_ID
from services.jobs import get_prediction_job_by_id, load_df_from_managed_folder


def trigger_prediction_scenario(prediction_job_id: str):
    client = dataiku.api_client()
    project = client.get_default_project()
    scenario = project.get_scenario(PREDICTION_SCENARIO_ID)
    return scenario.run(params={"prediction_job_id": prediction_job_id})


def wait_for_prediction_completion(prediction_job_id: str, poll_seconds: int = 5, max_wait_seconds: int = 1800):
    status_placeholder = st.empty()
    message_placeholder = st.empty()
    waited = 0

    with status_placeholder.container():
        with st.spinner("Classification in progress. Please wait..."):
            while waited < max_wait_seconds:
                time.sleep(poll_seconds)
                waited += poll_seconds
                latest_job = get_prediction_job_by_id(prediction_job_id)
                if not latest_job:
                    continue
                latest_status = str(latest_job.get("status", "")).lower()
                if latest_status == "completed":
                    status_placeholder.empty()
                    message_placeholder.success("Classification Completed and ready for Validation.")
                    prediction_df_path = latest_job.get("prediction_df_path")
                    refreshed_df = load_df_from_managed_folder(prediction_df_path) if prediction_df_path else None
                    return "completed", refreshed_df, latest_job
                if latest_status == "failed":
                    status_placeholder.empty()
                    err_msg = latest_job.get("error_message", "Prediction scenario failed.")
                    message_placeholder.error(f"Classification failed: {err_msg}")
                    return "failed", None, latest_job

    status_placeholder.empty()
    message_placeholder.warning("Prediction is still running in background. Please check again after some time.")
    return "timeout", None, None
