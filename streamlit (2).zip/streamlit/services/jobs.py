import io
import json
import uuid
from datetime import datetime
from io import BytesIO
from typing import Optional

import pandas as pd
import streamlit as st

from config.constants import JOBS_META_PATH, GOLDEN_DATASET_EXPORT_CSV_PATH, GOLDEN_DATASET_PATH, APPROVED_COL
from services.dataiku_context import USER_ID, folder

def _calc_stable_validation_progress(job: dict, validation_df) -> tuple[int, int]:
   current_remaining_rows = 0 if validation_df is None else len(validation_df)
   initial_total_rows = job.get("initial_total_rows")
   if initial_total_rows is None:
       initial_total_rows = current_remaining_rows
   approved_rows = max(int(initial_total_rows) - int(current_remaining_rows), 0)
   return approved_rows, int(initial_total_rows)

def _calc_validation_progress(validation_df: pd.DataFrame) -> tuple[int, int]:
   if validation_df is None or len(validation_df) == 0:
       return 0, 0
   if APPROVED_COL not in validation_df.columns:
       return 0, len(validation_df)
   approved_series = validation_df[APPROVED_COL].fillna("").astype(str).str.strip()
   approved_rows = (approved_series != "").sum()
   total_rows = len(validation_df)
   return int(approved_rows), int(total_rows)



def _now_ts() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")


def _safe_read_json(path: str, default):
    try:
        raw = folder.get_download_stream(path).read()
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        return json.loads(raw)
    except Exception:
        return default


def _write_json(path: str, payload: dict):
    folder.upload_data(path, json.dumps(payload, indent=2).encode("utf-8"))


def _save_bytes(path: str, data: bytes):
    folder.upload_data(path, data)


def _save_df_pickle(df: pd.DataFrame, path: str):
    bio = io.BytesIO()
    df.to_pickle(bio)
    folder.upload_data(path, bio.getvalue())


def _load_df_pickle(path: str) -> Optional[pd.DataFrame]:
    try:
        raw = folder.get_download_stream(path).read()
        return pd.read_pickle(io.BytesIO(raw))
    except Exception:
        return None


def load_df_from_managed_folder(path: str) -> Optional[pd.DataFrame]:
    try:
        with folder.get_download_stream(path) as f:
            data = f.read()
        return pd.read_parquet(BytesIO(data))
    except Exception:
        return None


def load_jobs_metadata() -> dict:
    return _safe_read_json(JOBS_META_PATH, {"prediction_jobs": [], "validation_jobs": []})


def save_jobs_metadata(meta: dict):
    _write_json(JOBS_META_PATH, meta)


def _find_prediction_job(meta: dict, prediction_job_id: str):
    for job in meta.get("prediction_jobs", []):
        if job.get("prediction_job_id") == prediction_job_id:
            return job
    return None


def _find_validation_job(meta: dict, validation_job_id: str):
    for job in meta.get("validation_jobs", []):
        if job.get("validation_job_id") == validation_job_id:
            return job
    return None


def list_prediction_jobs_for_user(user_id: str):
    meta = load_jobs_metadata()
    jobs = [j for j in meta.get("prediction_jobs", []) if j.get("created_by") == user_id]
    return sorted(jobs, key=lambda x: x.get("created_time", ""), reverse=True)


def list_validation_jobs_for_user(user_id: str):
    meta = load_jobs_metadata()
    jobs = []
    for job in meta.get("validation_jobs", []):
        if job.get("created_by") == user_id or job.get("prediction_job_created_by") == user_id:
            jobs.append(job)
    return sorted(jobs, key=lambda x: x.get("created_time", ""), reverse=True)


def get_prediction_job_by_id(prediction_job_id: str):
    jobs = list_prediction_jobs_for_user(USER_ID)
    for job in jobs:
        if job.get("prediction_job_id") == prediction_job_id:
            return job
    return None


def create_prediction_job(file_name: str, file_ext: str, file_bytes: bytes, input_df: Optional[pd.DataFrame] = None) -> str:
    meta = load_jobs_metadata()
    prediction_job_id = f"pred_{USER_ID}_{uuid.uuid4().hex[:10]}"
    base = f"prediction_jobs/{prediction_job_id}"
    raw_path = f"{base}/raw/{file_name}"
    input_df_path = f"{base}/input_df.pkl"

    _save_bytes(raw_path, file_bytes)
    if input_df is not None:
        _save_df_pickle(input_df, input_df_path)

    meta["prediction_jobs"].append(
        {
            "prediction_job_id": prediction_job_id,
            "file_name": file_name,
            "file_ext": file_ext,
            "created_by": USER_ID,
            "status": "uploaded",
            "created_time": _now_ts(),
            "last_updated": _now_ts(),
            "raw_file_path": raw_path,
            "input_df_path": input_df_path if input_df is not None else None,
            "prediction_df_path": None,
            "row_count": int(len(input_df)) if input_df is not None else None,
        }
    )
    save_jobs_metadata(meta)
    return prediction_job_id


def update_prediction_job(
    prediction_job_id: str,
    *,
    status: Optional[str] = None,
    input_df: Optional[pd.DataFrame] = None,
    prediction_df: Optional[pd.DataFrame] = None,
    error_message: Optional[str] = None,
):
    meta = load_jobs_metadata()
    job = _find_prediction_job(meta, prediction_job_id)
    if not job:
        return

    base = f"prediction_jobs/{prediction_job_id}"
    if status:
        job["status"] = status
    if input_df is not None:
        path = f"{base}/input_df.pkl"
        _save_df_pickle(input_df, path)
        job["input_df_path"] = path
        job["row_count"] = int(len(input_df))
    if prediction_df is not None:
        path = f"{base}/prediction_df.pkl"
        _save_df_pickle(prediction_df, path)
        job["prediction_df_path"] = path
        job["prediction_completed_time"] = _now_ts()
    if error_message:
        job["error_message"] = error_message
    job["last_updated"] = _now_ts()
    save_jobs_metadata(meta)


def update_prediction_job_status(prediction_job_id: Optional[str], status: str, error_message: Optional[str] = None):
    if prediction_job_id:
        update_prediction_job(prediction_job_id, status=status, error_message=error_message)


def load_prediction_input_df(prediction_job_id: str) -> Optional[pd.DataFrame]:
    meta = load_jobs_metadata()
    job = _find_prediction_job(meta, prediction_job_id)
    if not job or not job.get("input_df_path"):
        return None
    return _load_df_pickle(job["input_df_path"])


def load_prediction_output_df(prediction_job_id: str) -> Optional[pd.DataFrame]:
    meta = load_jobs_metadata()
    job = _find_prediction_job(meta, prediction_job_id)
    if not job or not job.get("prediction_df_path"):
        return None
    return _load_df_pickle(job["prediction_df_path"])

def save_prediction_input_df(prediction_job_id: str, df: pd.DataFrame):
    update_prediction_job(prediction_job_id, input_df=df)


def save_prediction_output_df(prediction_job_id: str, df: pd.DataFrame):
    update_prediction_job(prediction_job_id, prediction_df=df)


def get_or_create_validation_job(prediction_job_id: str) -> str:
    meta = load_jobs_metadata()
    pred_job = _find_prediction_job(meta, prediction_job_id)
    if not pred_job:
        raise ValueError(f"Prediction job not found: {prediction_job_id}")

    for job in meta.get("validation_jobs", []):
        if job.get("prediction_job_id") == prediction_job_id:
            return job["validation_job_id"]

    validation_job_id = f"val_{uuid.uuid4().hex[:10]}"
    base = f"validation_jobs/{validation_job_id}"
    validation_df_path = f"{base}/validation_df.pkl"

    seed_df = None
    if pred_job.get("prediction_df_path"):
        seed_df = _load_df_pickle(pred_job["prediction_df_path"])
    if seed_df is None and pred_job.get("input_df_path"):
        seed_df = _load_df_pickle(pred_job["input_df_path"])
    if seed_df is not None:
        _save_df_pickle(seed_df, validation_df_path)

    meta["validation_jobs"].append(
        {
            "validation_job_id": validation_job_id,
            "prediction_job_id": prediction_job_id,
            "prediction_job_created_by": pred_job.get("created_by"),
            "created_by": USER_ID,
            "status": "pending",
            "created_time": _now_ts(),
            "last_updated": _now_ts(),
            "validation_df_path": validation_df_path if seed_df is not None else None,
        }
    )
    save_jobs_metadata(meta)
    return validation_job_id



def load_unspsc_lookup_df(path_in_folder: str) -> pd.DataFrame:
   data = folder.get_download_stream(path_in_folder).read()
   lower_path = path_in_folder.lower()
   if lower_path.endswith(".csv"):
       encodings_to_try = ["utf-8", "utf-8-sig", "cp1252", "latin-1", "iso-8859-1"]
       last_error = None
       for enc in encodings_to_try:
           try:
               return pd.read_csv(io.BytesIO(data), dtype=str, encoding=enc)
           except UnicodeDecodeError as e:
               last_error = e
       raise ValueError(
           f"Unable to decode CSV lookup file '{path_in_folder}' with supported encodings. "
           f"Last error: {last_error}"
       )
   elif lower_path.endswith(".xlsx") or lower_path.endswith(".xls"):
       return pd.read_excel(io.BytesIO(data), dtype=str)
   elif lower_path.endswith(".json"):
       return pd.read_json(io.BytesIO(data), dtype=str)
   else:
       raise ValueError(f"Unsupported lookup file type: {path_in_folder}")


def build_unspsc_description_map(df: pd.DataFrame, code_col: str, desc_col: str) -> dict:
   temp = df[[code_col, desc_col]].copy()
   temp[code_col] = temp[code_col].fillna("").astype(str).str.replace("\xa0", " ", regex=False).str.strip()
   temp[desc_col] = temp[desc_col].fillna("").astype(str).str.replace("\xa0", " ", regex=False).str.strip()
   temp = temp[temp[code_col] != ""]
   return dict(zip(temp[code_col], temp[desc_col]))


def update_validation_job(validation_job_id, status=None, validation_df=None, **kwargs):
   jobs = load_jobs_metadata()
   job = _find_validation_job(jobs, validation_job_id)
   if not job:
       return
   if status is not None:
       job["status"] = status
   if validation_df is not None:
       validation_df_path = f"validation/{validation_job_id}/validation_df.pkl"
       _save_df_pickle(validation_df, validation_df_path)
       job["validation_df_path"] = validation_df_path
       if job.get("initial_total_rows") is None:
           job["initial_total_rows"] = len(validation_df)
       approved_rows, initial_total_rows = _calc_stable_validation_progress(job, validation_df)
       job["approved_rows"] = approved_rows
       job["initial_total_rows"] = initial_total_rows
       job["remaining_rows"] = len(validation_df)
   for k, v in kwargs.items():
       job[k] = v
   save_jobs_metadata(jobs)


def load_validation_df(validation_job_id: str) -> Optional[pd.DataFrame]:
    meta = load_jobs_metadata()
    job = _find_validation_job(meta, validation_job_id)
    if not job or not job.get("validation_df_path"):
        return None
    return _load_df_pickle(job["validation_df_path"])


def open_prediction_job_in_preview(prediction_job_id: str, view: str = "input"):
   input_df = load_prediction_input_df(prediction_job_id)
   output_df = load_prediction_output_df(prediction_job_id)
   st.session_state["current_prediction_job_id"] = prediction_job_id
   st.session_state["active_flow"] = "Classify/Create Parts"
   st.session_state["mode"] = "Classify Existing Parts"
   st.session_state["home_view"] = "upload"
   if view == "input":
       st.session_state["uploaded_df"] = input_df
       st.session_state["prediction_output_df"] = None
       st.session_state["prediction_display_mode"] = "input_only"
       st.session_state["run_view_mode"] = True
   elif view == "output":
       st.session_state["uploaded_df"] = input_df if input_df is not None else output_df
       st.session_state["prediction_output_df"] = output_df
       st.session_state["prediction_display_mode"] = "show_both"
       st.session_state["run_view_mode"] = True
   st.rerun()


def open_validation_job(validation_job_id: str):
   meta = load_jobs_metadata()
   val_job = _find_validation_job(meta, validation_job_id)
   if not val_job:
       st.error("Validation job not found.")
       return
   pred_job = _find_prediction_job(meta, val_job.get("prediction_job_id"))
   df = load_validation_df(validation_job_id)
   if df is None and pred_job:
       df = load_prediction_output_df(pred_job["prediction_job_id"])
   if df is None:
       st.warning("No validation data is available for this job.")
       return
   st.session_state["uploaded_df"] = df
   st.session_state["uploaded_name"] = pred_job.get("file_name") if pred_job else None
   st.session_state["uploaded_ext"] = pred_job.get("file_ext") if pred_job else None
   st.session_state["uploaded_bytes"] = None
   st.session_state["uploaded_sheet"] = None
   st.session_state["current_prediction_job_id"] = val_job.get("prediction_job_id")
   st.session_state["current_validation_job_id"] = validation_job_id
   st.session_state["home_view"] = "validation"
   st.session_state["active_flow"] = "Validation"
   st.session_state["mode"] = "To Validate"
   st.session_state["run_view_mode"] = False
   if val_job.get("status") == "pending":
       update_validation_job(validation_job_id, status="in_progress", validation_df=df)
   st.rerun()


def load_golden_dataset() -> pd.DataFrame:
   try:
       raw = folder.get_download_stream(GOLDEN_DATASET_PATH).read()
       return pd.read_pickle(io.BytesIO(raw))
   except Exception:
       return pd.DataFrame()

def save_golden_dataset(df: pd.DataFrame):
   pkl_buf = io.BytesIO()
   df.to_pickle(pkl_buf)
   pkl_buf.seek(0)
   folder.upload_data(GOLDEN_DATASET_PATH, pkl_buf.getvalue())
   csv_buf = io.BytesIO()
   csv_buf.write(df.to_csv(index=False).encode("utf-8"))
   csv_buf.seek(0)
   folder.upload_data(GOLDEN_DATASET_EXPORT_CSV_PATH, csv_buf.getvalue())

def append_row_to_golden_dataset(row_dict: dict, approved_by_user: str) -> pd.DataFrame:
   golden_df = load_golden_dataset()
   row_to_add = dict(row_dict)
   row_to_add["approved_by_user"] = approved_by_user
   row_to_add["approved_at"] = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
   new_row_df = pd.DataFrame([row_to_add])
   if golden_df is None or len(golden_df) == 0:
       updated = new_row_df
   else:
       updated = pd.concat([golden_df, new_row_df], ignore_index=True)
   save_golden_dataset(updated)
   return updated
