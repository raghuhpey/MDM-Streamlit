import streamlit as st
from streamlit_extras.stylable_container import stylable_container
from config.constants import (
   DEFAULT_SESSION_STATE,
   INITIAL_SIDEBAR_STATE,
   LAYOUT,
   PAGE_TITLE,
)
from ui.home import render_home_content, reset_classification_working_state
from ui.styles import apply_styles
from ui.sidebar import render_sidebar

st.set_page_config(
   page_title=PAGE_TITLE,
   layout=LAYOUT,
   initial_sidebar_state=INITIAL_SIDEBAR_STATE,
)
for k, v in DEFAULT_SESSION_STATE.items():
   st.session_state.setdefault(k, v)
st.session_state.setdefault("active_top_tab", "Home")
apply_styles()
left, main = st.columns([1, 4], gap="small")
with left:
   render_sidebar()
with main:
   nav_labels = [
       ("Home", "🏠 Home"),
       ("Admin", "🔒 Admin"),
       ("Super Admin", "🛡️ Super Admin"),
       ("About", "ℹ️ About"),
       ("Help", "❓ Help"),
   ]
   with stylable_container(
       key="top_nav_container",
       css_styles="""
       {
           background: #e5e7eb;
           border-radius: 18px;
           padding-top: 0.35rem;
           padding-right: 0.45rem;
           padding-bottom: 1.55rem;
           padding-left: 0.45rem;
           max-width: 100%;
           margin-bottom: 1rem;
           border: 1px solid #d1d5db;
       }
       button {
           border-radius: 12px !important;
           height: 44px !important;
           font-weight: 600 !important;
       }
       """,
   ):
       nav_cols = st.columns([1, 1, 1.2, 1, 1], gap="small")
       for i, (tab_key, tab_label) in enumerate(nav_labels):
           btn_type = "primary" if st.session_state["active_top_tab"] == tab_key else "secondary"
           if nav_cols[i].button(
               tab_label,
               key=f"top_nav_{tab_key}",
               use_container_width=True,
               type=btn_type,
           ):
               st.session_state["active_top_tab"] = tab_key
               if tab_key == "Home":
                   st.session_state["active_flow"] = None
                   st.session_state["mode"] = None
                   st.session_state["home_view"] = "upload"
               st.rerun()
   st.markdown("---")
   active_top_tab = st.session_state.get("active_top_tab", "Home")
   flow = st.session_state.get("active_flow")
   if active_top_tab == "Home":
       if flow is None:
           st.markdown("## Options")
           c1, c2, c3 = st.columns(3, gap="large")
           with c1:
            with stylable_container(
                key="landing_btn_classification_wrap",
                css_styles="""
                button {
                background: #dbeafe !important;
                color: #1e3a8a !important;
                border: 1px solid #bfdbfe !important;
                border-radius: 14px !important;
                min-height: 54px !important;
                font-weight: 700 !important;
                }
                """,
                ):
                if st.button("Classify/Create Parts", key="landing_classification", use_container_width=True):
                    reset_classification_working_state()
                    st.session_state["active_flow"] = "Classification"
                    st.session_state["mode"] = "Classify Existing Parts"
                    st.session_state["home_view"] = "upload"
                    st.rerun()
            with c2:
                with stylable_container(
                    key="landing_btn_validation_wrap",
                    css_styles="""
                    button {
                        background: #dbeafe !important;
                        color: #1e3a8a !important;
                        border: 1px solid #bfdbfe !important;
                        border-radius: 14px !important;
                        min-height: 54px !important;
                        font-weight: 700 !important;
                    }
                    """,
                    ):
                    if st.button("Validate Classified Parts", key="landing_validation", use_container_width=True):
                        st.session_state["active_flow"] = "Validation"
                        st.session_state["mode"] = "To Validate"
                        st.session_state["home_view"] = "upload"
                        st.rerun()
            with c3:
                with stylable_container(
                    key="landing_btn_train_wrap",
                    css_styles="""
                    button {
                        background: #dbeafe !important;
                        color: #1e3a8a !important;
                        border: 1px solid #bfdbfe !important;
                        border-radius: 14px !important;
                        min-height: 54px !important;
                        font-weight: 700 !important;
                    }
                    """,
                ):
                    if st.button("Model Retraining", key="landing_train_models", use_container_width=True):
                        st.session_state["active_flow"] = "Model Retraining"
                        st.session_state["mode"] = "Retraining"
                        st.session_state["home_view"] = "upload"
                        st.rerun()
       else:
           render_home_content()
   elif active_top_tab == "Admin":
       st.markdown("## Admin")
       st.info("Manage application settings, mappings, and controls.")
   elif active_top_tab == "Super Admin":
       st.markdown("## Super Admin")
       st.info("Reserved for advanced governance, roles, and application administration.")
   elif active_top_tab == "About":
       st.markdown("## About")
       st.info("Information about the Parts Classification application.")
   elif active_top_tab == "Help":
       st.markdown("## Help")
       st.info("Guidance for upload, classification, validation, and download results.")