import streamlit as st


def init_pagination_keys(base_key: str):
    st.session_state.setdefault(f"{base_key}_page", 1)
    st.session_state.setdefault(f"{base_key}_total_pages", 1)
    st.session_state.setdefault(f"{base_key}_fp", "")
    st.session_state.setdefault(f"{base_key}_jump", 1)


def on_prev(base_key: str):
    key = f"{base_key}_page"
    st.session_state[key] = max(1, st.session_state[key] - 1)
    st.session_state[f"{base_key}_jump"] = st.session_state[key]


def on_next(base_key: str):
    key = f"{base_key}_page"
    total = st.session_state[f"{base_key}_total_pages"]
    st.session_state[key] = min(total, st.session_state[key] + 1)
    st.session_state[f"{base_key}_jump"] = st.session_state[key]


def on_jump_change(base_key: str):
    val = int(st.session_state[f"{base_key}_jump"])
    total = st.session_state[f"{base_key}_total_pages"]
    st.session_state[f"{base_key}_page"] = max(1, min(total, val))


def on_jump_up(base_key: str):
    total = st.session_state.get(f"{base_key}_total_pages", 1)
    cur = int(st.session_state.get(f"{base_key}_jump", 1) or 1)
    st.session_state[f"{base_key}_jump"] = min(total, cur + 1)
    on_jump_change(base_key)


def on_jump_down(base_key: str):
    cur = int(st.session_state.get(f"{base_key}_jump", 1) or 1)
    st.session_state[f"{base_key}_jump"] = max(1, cur - 1)
    on_jump_change(base_key)
