import io
import json
import math
from typing import Optional

import numpy as np
import pandas as pd
import streamlit as st
# from PyPDF2 import PdfReader


def human_size(num_bytes: int) -> str:
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num_bytes < 1024:
            return f"{num_bytes:.0f} {unit}"
        num_bytes /= 1024
    return f"{num_bytes:.0f} PB"


def calc_df_height(n_rows: int, base_header: int = 38, row_h: int = 34) -> int:
    return base_header + (n_rows * row_h)


def is_nan_like(v) -> bool:
    try:
        return v is None or (isinstance(v, float) and math.isnan(v)) or (isinstance(v, np.floating) and np.isnan(v))
    except Exception:
        return False


@st.cache_data(show_spinner=False)
def read_csv_from_bytes(file_bytes: bytes) -> pd.DataFrame:
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(file_bytes), engine="python", encoding=enc)
        except Exception:
            continue
    sample = file_bytes[:4096].decode("latin-1", errors="ignore")
    return pd.read_csv(io.StringIO(sample), engine="python")


@st.cache_data(show_spinner=False)
def get_excel_sheet_names(file_bytes: bytes) -> list[str]:
    with io.BytesIO(file_bytes) as bio:
        xls = pd.ExcelFile(bio, engine="openpyxl")
        return xls.sheet_names


@st.cache_data(show_spinner=True)
def read_excel_sheet_from_bytes(file_bytes: bytes, sheet_name: str) -> pd.DataFrame:
    with io.BytesIO(file_bytes) as bio:
        return pd.read_excel(bio, sheet_name=sheet_name, engine="openpyxl")


def sanitize_headers(df: pd.DataFrame) -> pd.DataFrame:
    new_cols = []
    for i, c in enumerate(df.columns):
        if pd.isna(c) or str(c).strip() == "":
            new_cols.append(f"col_{i+1}")
        else:
            new_cols.append(str(c).strip())
    df.columns = new_cols
    return df


def normalize_headers(df: pd.DataFrame) -> pd.DataFrame:
    cols = (
        df.columns.str.strip()
        .str.lower()
        .str.replace(r"\s+", "_", regex=True)
        .str.replace(r"\s*\(\s*", "_(", regex=True)
        .str.replace(r"\s*\)\s*", ")", regex=True)
        .str.replace(r"__+", "_", regex=True)
        .str.strip("_")
    )
    df.columns = cols
    return df


def view_with_bool_as_text(df: pd.DataFrame, yes="Yes", no="No") -> pd.DataFrame:
    vdf = df.copy()
    bool_cols = [c for c in vdf.columns if str(vdf[c].dtype) == "bool" or str(vdf[c].dtype).startswith("boolean")]
    for c in bool_cols:
        vdf[c] = vdf[c].map(lambda x: yes if x is True else (no if x is False else ""))
    return vdf


def preview_non_tabular_file(name: str, ext: str, file_bytes: bytes):
    if ext == ".txt":
        st.text(file_bytes.decode("utf-8", errors="ignore")[:5000])
    elif ext in (".png", ".jpg", ".jpeg"):
        st.image(io.BytesIO(file_bytes), caption=name, use_container_width=True)
    # elif ext == ".pdf":
    #     reader = PdfReader(io.BytesIO(file_bytes))
    #     st.info(f"PDF loaded with {len(reader.pages)} pages.")


def load_json_as_df(file_bytes: bytes) -> Optional[pd.DataFrame]:
    raw = file_bytes.decode("utf-8", errors="ignore")
    data = json.loads(raw)
    return pd.DataFrame(data) if isinstance(data, list) else None
