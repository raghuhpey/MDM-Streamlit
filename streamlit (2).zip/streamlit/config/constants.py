APPROVED_COL = "Approved OP"
OUTPUT_COLS = ["Model 1 OP", "Model 2 OP", "Model 3 OP", "LLM as a Judge OP"]
EXPL_COL = "Explanation"
PRED_COLS = [
    "Model 1 OP",
    "Model 2 OP",
    "Model 3 OP",
    "LLM as a Judge OP",
    "LLM Decision Source",
    "Explanation",
]

FOLDER_ID = "streamlit_user_progress"
JOBS_META_PATH = "metadata/jobs_metadata.json"
PREDICTION_SCENARIO_ID = "RUN_PREDICTION_JOB"

PAGE_TITLE = "Parts Classification"
LAYOUT = "wide"
INITIAL_SIDEBAR_STATE = "expanded"

UNSPSC_LOOKUP_PATH = "reference/unspsc_code_description.csv"
UNSPSC_CODE_COL = "unspsc_code"
UNSPSC_DESC_COL = "unspsc_description"

GOLDEN_DATASET_PATH = "golden/golden_dataset.pkl"
GOLDEN_DATASET_EXPORT_CSV_PATH = "golden/golden_dataset.csv"

DEFAULT_SESSION_STATE = {
    "uploaded_name": None,
    "uploaded_bytes": None,
    "uploaded_ext": None,
    "uploaded_sheet": None,
    "uploaded_df": None,
    "home_view": "upload",
    "results_df": None,
    # "mode": "Classify Existing Parts",
    "current_prediction_job_id": None,
    "current_validation_job_id": None,
    "current_upload_fp": None,
    "prediction_output_df": None,
    "prediction_completed_message":False,
    "prediction_display_mode": "input_only",
    "show_prediction_output": False,
    "golden_df": None,
    "active_flow": None,  
    "mode": None,
    "active_top_tab": "Home",
   "admin_mode": "Retraining",
   "run_view_mode": False
}

SUPPORTED_UPLOAD_TYPES = ["csv", "xlsx", "xls", "json", "txt", "png", "jpg", "jpeg", "pdf"]
