import dataiku
from services.classification_table_service import (
   mark_run_submitted,
   mark_run_running,
   mark_run_queued,
   update_run_rows_by_run_id,
   fetch_queued_run_ids,
)
PROJECT_KEY = "MDM_PARTS_CLASSIFICATION"
WORKER_SCENARIO_IDS = [
   "RUN_PREDICTION_JOB_1",
   "RUN_PREDICTION_JOB_2",
   "RUN_PREDICTION_JOB_3",
]
def _try_start_on_worker(project, run_id: str, scenario_id: str):
   scenario = project.get_scenario(scenario_id)
   # skip worker if already busy
   if scenario.get_current_run() is not None:
       return None
   trigger_fire = scenario.run(params={"run_id": run_id})
   trigger_raw = trigger_fire.get_raw()
   trigger_fire_id = trigger_raw.get("runId")
   # wait for actual scenario run creation
   scenario_run = trigger_fire.wait_for_scenario_run(no_fail=True)
   if scenario_run is None:
       return None
   update_run_rows_by_run_id(
       run_id,
       {
           "worker_scenario_id": scenario_id,
           "backend_trigger_id": trigger_fire_id,
       }
   )
   mark_run_running(run_id, backend_run_id=scenario_run.id)
   return {
       "worker_scenario_id": scenario_id,
       "backend_trigger_id": trigger_fire_id,
       "backend_run_id": scenario_run.id,
   }
def trigger_prediction_scenario(run_id: str):
   client = dataiku.api_client()
   project = client.get_project(PROJECT_KEY)
   mark_run_submitted(run_id)
   for scenario_id in WORKER_SCENARIO_IDS:
       result = _try_start_on_worker(project, run_id, scenario_id)
       if result is not None:
           return result
   mark_run_queued(run_id)
   return {
       "worker_scenario_id": None,
       "backend_trigger_id": None,
       "backend_run_id": None,
       "queued": True,
   }
def dispatch_queued_runs(max_to_dispatch: int = 3):
   client = dataiku.api_client()
   project = client.get_project(PROJECT_KEY)
   queued_run_ids = fetch_queued_run_ids(limit=max_to_dispatch * 3)
   started = []
   for run_id in queued_run_ids:
       for scenario_id in WORKER_SCENARIO_IDS:
           result = _try_start_on_worker(project, run_id, scenario_id)
           if result is not None:
               started.append(run_id)
               break
       if len(started) >= max_to_dispatch:
           break
   return started