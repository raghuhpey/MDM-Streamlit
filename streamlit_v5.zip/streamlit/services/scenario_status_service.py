import dataiku
from services.classification_table_service import (
   fetch_classification_run_metadata,
   mark_run_running,
   mark_run_completed,
   mark_run_failed,
   mark_run_stopped,
)
PROJECT_KEY = "MDM_PARTS_CLASSIFICATION"
def refresh_backend_run_status(run_id: str):
   meta = fetch_classification_run_metadata(run_id)
   if meta is None:
       return None
   current_status = str(meta.get("run_status") or "").strip().lower()
   if current_status in {"completed", "failed", "stopped"}:
       return meta
   worker_scenario_id = str(meta.get("worker_scenario_id") or "").strip()
   backend_run_id = str(meta.get("backend_run_id") or "").strip()
   if not worker_scenario_id or not backend_run_id:
       return meta
   client = dataiku.api_client()
   project = client.get_project(PROJECT_KEY)
   scenario = project.get_scenario(worker_scenario_id)
   scenario_run = scenario.get_run(backend_run_id)
   scenario_run.refresh()
   if scenario_run.running:
       if current_status != "running":
           mark_run_running(run_id, backend_run_id=backend_run_id)
       return fetch_classification_run_metadata(run_id)
   outcome = str(scenario_run.outcome or "").upper()
   if outcome == "SUCCESS":
       mark_run_completed(run_id)
   elif outcome == "ABORTED":
       mark_run_stopped(run_id)
   else:
       mark_run_failed(run_id)
   return fetch_classification_run_metadata(run_id)