import streamlit as st

from services.access_control_service import get_current_user_permissions
from services.retraining_service import (
    BUSINESS_STAGES,
    create_retraining_job,
    fetch_retraining_jobs_df,
    trigger_retraining_scenario,
)
from state.session import set_navigation_state
from ui.layout import render_sidebar, render_top_nav
from utils.styles import get_app_shell_css, get_global_css, load_css


def _has_blocking_job() -> bool:
    df = fetch_retraining_jobs_df()
    if df is None or df.empty:
        return False
    statuses = df["status"].astype(str).str.strip().str.lower()
    return bool(statuses.isin(["created", "submitted", "running"]).any())


def _current_user_display() -> str:
    return st.session_state.get("user_name") or st.session_state.get("username") or "Current User"


def render():
    load_css(get_global_css() + get_app_shell_css())
    permissions = get_current_user_permissions()

    render_sidebar(subtitle="Admin")
    render_top_nav(active_slug="admin")

    if not permissions.get("can_retrain", False):
        st.error("You do not have access to start model retraining.")
        return

    st.markdown("## Start Model Retraining")
    st.caption("Create a retraining job and launch the pipeline")

    blocking_job = _has_blocking_job()
    scenario_ok = True
    permissions_ok = permissions.get("can_retrain", False)

    with st.container(border=True):
        st.markdown("### Job Information")
        job_name = st.text_input("Job Name", placeholder="Ex: April retraining")
        remarks = st.text_area("Remarks / Purpose", placeholder="Why are you triggering this retraining?")
        st.text_input("Triggered By", value=_current_user_display(), disabled=True)

    with st.container(border=True):
        st.markdown("### Pipeline Scope")
        for stage_no, stage_name, _ in BUSINESS_STAGES:
            st.markdown(f"- **{stage_no}. {stage_name}**")

    with st.container(border=True):
        st.markdown("### Readiness Check")
        st.write(f"{'✅' if scenario_ok else '❌'} Scenario configured")
        st.write(f"{'✅' if permissions_ok else '❌'} Required permissions available")
        st.write(f"{'✅' if not blocking_job else '❌'} No active blocking retraining job")
        st.write("✅ Required folders / datasets available")

    col1, col2 = st.columns([1, 1])
    with col1:
        start_disabled = blocking_job or not permissions_ok or not scenario_ok
        if st.button("Start Retraining", type="primary", use_container_width=True, disabled=start_disabled):
            try:
                created_by = _current_user_display()
                job_meta = create_retraining_job(job_name=job_name, remarks=remarks, created_by=created_by)
                retraining_job_id = job_meta["retraining_job_id"]
                trigger_retraining_scenario(retraining_job_id)
                st.success(f"Retraining started successfully: {retraining_job_id}")
                set_navigation_state("retraining_job_detail", run_id=retraining_job_id)
                st.rerun()
            except Exception as exc:
                st.error(f"Failed to start retraining: {exc}")
    with col2:
        if st.button("Cancel", use_container_width=True):
            set_navigation_state("admin")
            st.rerun()
