from typing import Any

import pandas as pd
import streamlit as st

from services.retraining_service import (
    fetch_retraining_business_stages_df,
    fetch_retraining_job_metadata,
    fetch_retraining_job_steps_df,
)
from state.session import set_navigation_state
from ui.layout import render_sidebar, render_top_nav
from utils.styles import get_app_shell_css, get_global_css, load_css


STATUS_COLOR = {
    "pending": "#6b7280",
    "created": "#6b7280",
    "submitted": "#6b7280",
    "running": "#2563eb",
    "completed": "#16a34a",
    "failed": "#dc2626",
}


def _display_value(value: Any, default: str = "-") -> str:
    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    text = str(value).strip()
    if text.lower() in {"", "nan", "none", "null"}:
        return default
    return text


def _status_badge(status: str) -> str:
    norm = _display_value(status, "pending").lower()
    color = STATUS_COLOR.get(norm, "#6b7280")
    label = norm.capitalize()
    return f"<span style='padding:6px 12px;border-radius:999px;background:{color};color:white;font-weight:700;font-size:12px;'>{label}</span>"


def render():
    load_css(get_global_css() + get_app_shell_css())
    render_sidebar(subtitle="Admin")
    render_top_nav(active_slug="admin")

    retraining_job_id = st.session_state.get("nav_run_id") or st.query_params.get("run_id")
    retraining_job_id = retraining_job_id[0] if isinstance(retraining_job_id, list) else retraining_job_id
    if not retraining_job_id:
        st.warning("No retraining job selected.")
        return

    meta = fetch_retraining_job_metadata(str(retraining_job_id))
    if not meta:
        st.error(f"Retraining job not found: {retraining_job_id}")
        return

    stages_df = fetch_retraining_business_stages_df(str(retraining_job_id))
    technical_df = fetch_retraining_job_steps_df(str(retraining_job_id))

    st.markdown("## Retraining Job Detail")
    top_left, top_right = st.columns([3, 1])
    with top_left:
        st.markdown(f"### {_display_value(meta.get('job_name'), 'Untitled Job')}")
        st.caption(_display_value(meta.get("retraining_job_id")))
        st.caption(_display_value(meta.get("remarks")))
    with top_right:
        st.markdown(_status_badge(_display_value(meta.get("status"))), unsafe_allow_html=True)

    st.progress(min(max(float(meta.get("progress_pct") or 0.0) / 100.0, 0.0), 1.0))

    c1, c2, c3 = st.columns(3)
    c1.write(f"**Current Stage:** {_display_value(meta.get('current_stage'))}")
    c1.write(f"**Triggered By:** {_display_value(meta.get('created_by'))}")
    c2.write(f"**Started At:** {_display_value(meta.get('started_ts'))}")
    c2.write(f"**Completed At:** {_display_value(meta.get('completed_ts'))}")
    c3.write(f"**Scenario Run ID:** {_display_value(meta.get('scenario_run_id'))}")
    c3.write(f"**Duration (sec):** {_display_value(meta.get('duration_seconds'))}")

    status_norm = _display_value(meta.get("status")).lower()
    if status_norm == "failed":
        st.error(f"Retraining failed. {_display_value(meta.get('error_message'), 'Check scenario logs for details.')}")
    elif status_norm == "completed":
        st.success("Retraining completed successfully.")
    else:
        st.info(f"Retraining is in progress. Current stage: {_display_value(meta.get('current_stage'))}")

    st.markdown("### Business Stage Tracker")
    if stages_df is None or stages_df.empty:
        st.info("No stage details found yet.")
    else:
        for _, row in stages_df.iterrows():
            with st.container(border=True):
                left, right = st.columns([3, 1])
                with left:
                    st.markdown(f"**{int(row['stage_no'])}. {_display_value(row['stage_name'])}**")
                    st.caption(_display_value(row.get('message')) or _display_value(row.get('error_message')))
                    st.write(f"Started: {_display_value(row.get('started_ts'))}")
                    st.write(f"Completed: {_display_value(row.get('completed_ts'))}")
                    st.write(f"Duration (sec): {_display_value(row.get('duration_seconds'))}")
                with right:
                    st.markdown(_status_badge(_display_value(row.get("status"))), unsafe_allow_html=True)

    with st.expander("Show Technical Scenario Steps"):
        if technical_df is None or technical_df.empty:
            st.info("No technical steps found yet.")
        else:
            show_df = technical_df[[
                "step_no", "step_name", "business_stage", "step_status",
                "started_ts", "completed_ts", "duration_seconds", "error_message"
            ]].copy()
            show_df = show_df.where(pd.notna(show_df), "-")
            st.dataframe(show_df, use_container_width=True, hide_index=True)

    st.markdown("### Outputs")
    a1, a2, a3 = st.columns(3)
    a1.metric("Model Version", _display_value(meta.get("model_version")))
    a2.metric("Artifact Path", _display_value(meta.get("output_artifact_path")))
    a3.metric("Trigger ID", _display_value(meta.get("trigger_id")))

    b1, b2 = st.columns(2)
    if b1.button("Refresh Status", use_container_width=True):
        st.rerun()
    if b2.button("Back to Jobs", use_container_width=True):
        set_navigation_state("retraining_jobs")
        st.rerun()
