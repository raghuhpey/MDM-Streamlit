from typing import Any

import pandas as pd
import streamlit as st

from services.retraining_service import fetch_retraining_jobs_df
from state.session import set_navigation_state
from ui.layout import render_sidebar, render_top_nav
from utils.styles import get_app_shell_css, get_global_css, load_css


def _display_value(value: Any, default: str = "-") -> str:
    if value is None:
        return default
    try:
        if pd.isna(value):
            return default
    except Exception:
        pass
    text = str(value).strip()
    if text.lower() in {"", "nan", "none", "null"}:
        return default
    return text


def render():
    load_css(get_global_css() + get_app_shell_css())
    render_sidebar(subtitle="Admin")
    render_top_nav(active_slug="admin")

    st.markdown("## Retraining Jobs")
    st.caption("Track active and completed retraining pipelines")

    df = fetch_retraining_jobs_df()
    if df is None or df.empty:
        st.info("No retraining jobs found.")
        return

    filter_col1, filter_col2, filter_col3 = st.columns([1, 1, 2])
    status_filter = filter_col1.selectbox("Status", ["All"] + sorted(df["status"].dropna().astype(str).unique().tolist()))
    job_search = filter_col2.text_input("Job Name")
    refresh = filter_col3.button("Refresh", use_container_width=True)
    if refresh:
        st.rerun()

    work = df.copy()
    if status_filter != "All":
        work = work[work["status"].astype(str) == status_filter]
    if job_search.strip():
        work = work[work["job_name"].astype(str).str.contains(job_search.strip(), case=False, na=False)]

    if work.empty:
        st.info("No retraining jobs match the selected filters.")
        return

    for _, row in work.iterrows():
        job_id = _display_value(row.get("retraining_job_id"))
        with st.container(border=True):
            c1, c2, c3, c4 = st.columns([2.3, 1.2, 1.2, 0.8])
            with c1:
                st.markdown(f"**{_display_value(row.get('job_name'), 'Untitled Job')}**")
                st.caption(job_id)
                st.caption(f"Triggered by: {_display_value(row.get('created_by'))}")
            with c2:
                st.write(f"Status: {_display_value(row.get('status'))}")
                st.write(f"Stage: {_display_value(row.get('current_stage'))}")
            with c3:
                st.write(f"Progress: {_display_value(row.get('progress_pct'))}%")
                st.write(f"Started: {_display_value(row.get('started_ts'))}")
            with c4:
                if st.button("View", key=f"view_{job_id}", use_container_width=True):
                    set_navigation_state("retraining_job_detail", run_id=job_id)
                    st.rerun()
