import streamlit as st

from services.access_control_service import get_current_user_permissions
from services.retraining_service import fetch_retraining_jobs_df
from state.session import set_navigation_state
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
    get_app_shell_css,
    get_classify_page_css,
    get_global_css,
    get_home_page_css,
    load_css,
)


def _summary_counts():
    df = fetch_retraining_jobs_df()
    if df is None or df.empty:
        return {"active": 0, "last_completed": "-", "current_version": "-"}

    work = df.copy()
    work["status_norm"] = work["status"].astype(str).str.strip().str.lower()
    active = int(work["status_norm"].isin(["created", "submitted", "running"]).sum())

    completed = work[work["status_norm"] == "completed"]
    last_completed = "-"
    current_version = "-"
    if not completed.empty:
        row = completed.iloc[0].to_dict()
        last_completed = str(row.get("completed_ts") or row.get("updated_ts") or "-")
        current_version = str(row.get("model_version") or "-")
    return {"active": active, "last_completed": last_completed, "current_version": current_version}


def _nav_card(title: str, subtitle: str, target_page: str, disabled: bool = False):
    with st.container(border=True):
        st.markdown(f"### {title}")
        st.caption(subtitle)
        if st.button("Open", key=f"card_{target_page}", disabled=disabled, use_container_width=True):
            set_navigation_state(target_page)
            st.rerun()


def render():
    load_css(get_global_css() + get_app_shell_css() + get_home_page_css() + get_classify_page_css())
    permissions = get_current_user_permissions()

    render_sidebar(subtitle="Admin")
    render_top_nav(active_slug="admin")

    st.markdown("## Admin")
    st.caption("Manage model retraining and monitor pipeline runs")

    summary = _summary_counts()
    c1, c2, c3 = st.columns(3)
    c1.metric("Active Jobs", summary["active"])
    c2.metric("Last Successful Retraining", summary["last_completed"])
    c3.metric("Current Active Model Version", summary["current_version"])

    st.markdown("### Actions")
    left, right = st.columns(2)
    with left:
        _nav_card(
            "Start Retraining",
            "Trigger a new end-to-end retraining pipeline",
            "retraining",
            disabled=not permissions.get("can_retrain", False),
        )
    with right:
        _nav_card(
            "Retraining Jobs",
            "Track running, failed, and completed retraining jobs",
            "retraining_jobs",
            disabled=not permissions.get("can_retrain", False),
        )
