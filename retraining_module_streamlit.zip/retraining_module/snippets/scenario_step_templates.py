# Example Custom Python step templates for Dataiku scenario

# Step 1: Mark Job Running
import dataiku.scenario
from services.retraining_service import update_retraining_job_status
s = dataiku.scenario.Scenario()
params = s.get_trigger_params()
retraining_job_id = params.get("retraining_job_id")
if not retraining_job_id:
    raise ValueError("Missing retraining_job_id")
update_retraining_job_status(
    retraining_job_id=retraining_job_id,
    status="running",
    started_ts="2026-01-01 00:00:00 UTC"  # replace with service helper if preferred
)

# Generic: Mark technical step running
import dataiku.scenario
from services.retraining_service import mark_retraining_step_running
s = dataiku.scenario.Scenario()
params = s.get_trigger_params()
retraining_job_id = params.get("retraining_job_id")
mark_retraining_step_running(retraining_job_id=retraining_job_id, step_no=2, message="Prepare Input Data started")

# Generic: Mark technical step completed
import dataiku.scenario
from services.retraining_service import mark_retraining_step_completed
s = dataiku.scenario.Scenario()
params = s.get_trigger_params()
retraining_job_id = params.get("retraining_job_id")
mark_retraining_step_completed(retraining_job_id=retraining_job_id, step_no=4, message="Prepare Input Data completed")

# Final step: Mark Job Completed
import dataiku.scenario
from services.retraining_service import update_retraining_job_status, refresh_retraining_job_progress
s = dataiku.scenario.Scenario()
params = s.get_trigger_params()
retraining_job_id = params.get("retraining_job_id")
refresh_retraining_job_progress(retraining_job_id)
update_retraining_job_status(retraining_job_id=retraining_job_id, status="completed")
