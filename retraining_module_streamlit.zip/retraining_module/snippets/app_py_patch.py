# Add these imports in app.py
from ui.pages.retraining_page import render as render_retraining
from ui.pages.retraining_jobs_page import render as render_retraining_jobs
from ui.pages.retraining_job_detail_page import render as render_retraining_job_detail

# Add these routes in app.py
elif page == "retraining":
    if has_retrain_access():
        render_retraining()
    else:
        render_access_denied("You do not have access to Model Retraining.")
elif page == "retraining_jobs":
    if has_retrain_access():
        render_retraining_jobs()
    else:
        render_access_denied("You do not have access to Retraining Jobs.")
elif page == "retraining_job_detail":
    if has_retrain_access():
        render_retraining_job_detail()
    else:
        render_access_denied("You do not have access to Retraining Jobs.")
