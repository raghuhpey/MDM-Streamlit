# Add these defaults in init_session_state()
"nav_page": "home",
"nav_sub": None,
"nav_run_id": None,

# Use existing set_navigation_state(page, sub=None, run_id=None)
# The retraining pages use:
# set_navigation_state("retraining")
# set_navigation_state("retraining_jobs")
# set_navigation_state("retraining_job_detail", run_id=retraining_job_id)
