CREATE TABLE IF NOT EXISTS mdm_retraining_jobs_tbl (
    retraining_job_id      TEXT PRIMARY KEY,
    job_name               TEXT,
    status                 TEXT,
    current_stage          TEXT,
    current_stage_no       INTEGER,
    total_stages           INTEGER,
    completed_stages       INTEGER,
    progress_pct           NUMERIC,
    created_by             TEXT,
    remarks                TEXT,
    created_ts             TEXT,
    started_ts             TEXT,
    completed_ts           TEXT,
    duration_seconds       NUMERIC,
    scenario_id            TEXT,
    scenario_run_id        TEXT,
    trigger_id             TEXT,
    model_version          TEXT,
    output_artifact_path   TEXT,
    error_message          TEXT,
    updated_ts             TEXT
);

CREATE INDEX IF NOT EXISTS idx_mdm_retraining_jobs_status ON mdm_retraining_jobs_tbl(status);
CREATE INDEX IF NOT EXISTS idx_mdm_retraining_jobs_created_ts ON mdm_retraining_jobs_tbl(created_ts DESC);
