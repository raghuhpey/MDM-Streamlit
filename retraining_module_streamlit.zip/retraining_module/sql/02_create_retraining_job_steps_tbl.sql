CREATE TABLE IF NOT EXISTS mdm_retraining_job_steps_tbl (
    retraining_job_id   TEXT,
    step_no             INTEGER,
    step_name           TEXT,
    business_stage      TEXT,
    business_stage_no   INTEGER,
    step_status         TEXT,
    started_ts          TEXT,
    completed_ts        TEXT,
    duration_seconds    NUMERIC,
    message             TEXT,
    error_message       TEXT,
    updated_ts          TEXT,
    PRIMARY KEY (retraining_job_id, step_no)
);

CREATE INDEX IF NOT EXISTS idx_mdm_retraining_job_steps_job ON mdm_retraining_job_steps_tbl(retraining_job_id, step_no);
CREATE INDEX IF NOT EXISTS idx_mdm_retraining_job_steps_status ON mdm_retraining_job_steps_tbl(step_status);
