import streamlit as st
from state.session import init_session_state
from ui.pages.home_page import render as render_home
from ui.pages.classify_page import render as render_classify
from ui.pages.validation_page import render as render_validation
from ui.pages.admin_page import render as render_admin
from ui.pages.super_admin_page import render as render_super_admin
from ui.pages.about_page import render as render_about
from ui.pages.help_page import render as render_help
from ui.pages.retraining_page import render as render_retraining

PAGE_MAP = {
   "home": "Home",
   "classify": "Classify/Create Parts",
   "validation": "Validation",
   "admin": "Admin",
   "super_admin": "Super Admin",
   "about": "About",
   "help": "Help",
   "retraining": "Model Retraining",
}
RENDER_MAP = {
   "home": render_home,
   "classify": render_classify,
   "validation": render_validation,
   "admin": render_admin,
   "super_admin": render_super_admin,
   "about": render_about,
   "help": render_help,
   "retraining": render_retraining,
}

def get_page_slug():
   page_slug = st.query_params.get("page", "home")
   if isinstance(page_slug, list):
       page_slug = page_slug[0]
   if page_slug not in PAGE_MAP:
       page_slug = "home"
   return page_slug

st.set_page_config(
   page_title="Parts Classification App",
   layout="wide"
)
init_session_state()
page_slug = get_page_slug()
st.session_state["current_page"] = PAGE_MAP[page_slug]
RENDER_MAP[page_slug]()