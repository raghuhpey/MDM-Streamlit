import streamlit as st

def load_css(css: str):
   st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)

def get_global_css():
   return """
   .stApp {
       background-color: #f2f3f7;
   }
   header[data-testid="stHeader"] {
       height: 0rem;
       background: transparent;
   }
   [data-testid="stToolbar"] {
       right: 10px;
       top: 10px;
   }
   #MainMenu {
       visibility: hidden;
   }
   footer {
       visibility: hidden;
   }
   .block-container {
       padding-top: 4.2rem;
       padding-left: 0.7rem;
       padding-right: 0.7rem;
       padding-bottom: 1rem;
       max-width: 100%;
   }
   """

def get_home_page_css():
   return """
   .home-shell {
       display: flex;
       gap: 18px;
       align-items: flex-start;
       width: 100%;
       box-sizing: border-box;
   }
   .brand-panel {
       width: 292px;
       min-height: 665px;
       background: #0d47a1;
       border-radius: 22px;
       padding: 26px 20px 26px 20px;
       display: flex;
       flex-direction: column;
       justify-content: center;
       box-sizing: border-box;
       flex-shrink: 0;
   }
   .brand-logo-wrap {
       margin-bottom: 22px;
   }
   .brand-logo-img {
       width: 185px;
       max-width: 100%;
       display: block;
   }
   .brand-title {
       font-size: 18px;
       font-weight: 700;
       color: #ffd8cc;
       margin-bottom: 8px;
       line-height: 1.3;
   }
   .brand-subtitle {
       font-size: 13px;
       font-weight: 600;
       color: #dbe8ff;
       line-height: 1.35;
   }
   .content-panel {
       flex: 1;
       box-sizing: border-box;
       min-width: 0;
   }
   .nav-strip {
       background: #e3e5ea;
       border-radius: 18px;
       padding: 8px;
       display: grid;
       grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
       gap: 14px;
       box-sizing: border-box;
       width: 100%;
       margin-bottom: 34px;
   }
   .nav-pill {
   background: #f7f7f8;
   border: 1px solid #d6d8dd;
   border-radius: 14px;
   text-align: center;
   padding: 13px 10px;
   font-size: 15px;
   font-weight: 600;
   color: #6b7280 !important;
   line-height: 1.2;
   box-sizing: border-box;
   white-space: nowrap;
   overflow: hidden;
   text-overflow: ellipsis;
   display: block;
   text-decoration: none !important;
   transition: 0.2s ease;
   width: 100%;
   cursor: pointer;
   appearance: none;
   -webkit-appearance: none;
   font-family: inherit;
}
   .nav-pill:hover {
   transform: translateY(-1px);
}
.nav-pill.active {
   background: #f44747;
   color: #ffffff !important;
   border: 1px solid #f44747;
}
   .section-divider {
       border: none;
       height: 1px;
       background: #d2d6dc;
       margin-top: 18px;
       margin-bottom: 34px;
   }
   .options-title {
       font-size: 28px;
       font-weight: 700;
       color: #111827;
       margin-bottom: 28px;
       line-height: 1.2;
   }
   .options-grid {
       display: grid;
       grid-template-columns: 1fr 1fr 1fr;
       gap: 24px;
       width: 100%;
   }
   .option-card {
   background: #dce9fb;
   border: 1px solid #c9daf4;
   border-radius: 16px;
   text-align: center;
   padding: 18px 14px;
   font-size: 15px;
   font-weight: 600;
   color: #566fbe !important;
   box-sizing: border-box;
   display: block;
   text-decoration: none !important;
   transition: 0.2s ease;
   width: 100%;
   cursor: pointer;
   appearance: none;
   -webkit-appearance: none;
   font-family: inherit;
}

   .option-card:hover {
   transform: translateY(-1px);
   background: #d4e4fb;
}
   @media (max-width: 1200px) {
       .nav-strip {
           grid-template-columns: 1fr 1fr 1fr;
       }
       .options-grid {
           grid-template-columns: 1fr;
       }
   }
   @media (max-width: 900px) {
       .home-shell {
           flex-direction: column;
       }
       .brand-panel {
           width: 100%;
           min-height: 220px;
           border-radius: 22px;
       }
       .nav-strip {
           grid-template-columns: 1fr 1fr;
       }
   }
   @media (max-width: 600px) {
       .nav-strip {
           grid-template-columns: 1fr;
       }
   }
   """

   
def get_workflow_page_css():
   return """
   .workflow-shell {
       display: flex;
       gap: 18px;
       align-items: flex-start;
       width: 100%;
       box-sizing: border-box;
   }
   .workflow-left {
       width: 320px;
       background: #0d47a1;
       border-radius: 22px;
       padding: 24px 20px;
       box-sizing: border-box;
       flex-shrink: 0;
       color: white;
       min-height: 640px;
   }
   .workflow-left-title {
       font-size: 24px;
       font-weight: 700;
       margin-bottom: 10px;
       line-height: 1.25;
       color: #ffffff;
   }
   .workflow-left-subtitle {
       font-size: 14px;
       line-height: 1.5;
       color: #dbe8ff;
       margin-bottom: 24px;
   }
   .section-label {
       font-size: 14px;
       font-weight: 700;
       color: #ffffff;
       margin-top: 18px;
       margin-bottom: 8px;
   }
   .upload-box {
       border: 2px dashed rgba(255,255,255,0.45);
       border-radius: 16px;
       padding: 22px 16px;
       text-align: center;
       color: #dbe8ff;
       background: rgba(255,255,255,0.06);
       margin-bottom: 18px;
   }
   .upload-box-title {
       font-size: 15px;
       font-weight: 700;
       margin-bottom: 6px;
       color: #ffffff;
   }
   .upload-box-subtext {
       font-size: 13px;
       color: #dbe8ff;
       line-height: 1.4;
   }
   .workflow-right {
       flex: 1;
       min-width: 0;
       box-sizing: border-box;
   }
   .workflow-topbar {
       background: #e3e5ea;
       border-radius: 18px;
       padding: 8px;
       display: grid;
       grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
       gap: 14px;
       box-sizing: border-box;
       width: 100%;
       margin-bottom: 24px;
   }
   .content-card {
       background: #ffffff;
       border: 1px solid #e4e7ec;
       border-radius: 18px;
       padding: 22px;
       box-sizing: border-box;
       margin-bottom: 18px;
   }
   .content-card-title {
       font-size: 20px;
       font-weight: 700;
       color: #111827;
       margin-bottom: 12px;
   }
   .content-card-subtitle {
       font-size: 14px;
       color: #6b7280;
       margin-bottom: 18px;
       line-height: 1.5;
   }
   .status-box {
       background: #fff4db;
       border: 1px solid #f4d58d;
       color: #8a6514;
       border-radius: 14px;
       padding: 14px 16px;
       font-size: 14px;
       font-weight: 600;
   }
   .preview-box {
       background: #f8fafc;
       border: 1px dashed #cbd5e1;
       border-radius: 14px;
       padding: 26px 18px;
       text-align: center;
       color: #64748b;
       font-size: 14px;
   }
   .stFileUploader {
       background: transparent;
   }
   .stSelectbox > div > div {
       border-radius: 12px;
   }
   .stButton > button {
       width: 100%;
       border-radius: 12px;
       min-height: 42px;
       font-weight: 700;
   }
   @media (max-width: 1200px) {
       .workflow-topbar {
           grid-template-columns: 1fr 1fr 1fr;
       }
   }
   @media (max-width: 900px) {
       .workflow-shell {
           flex-direction: column;
       }
       .workflow-left {
           width: 100%;
           min-height: auto;
       }
       .workflow-topbar {
           grid-template-columns: 1fr 1fr;
       }
   }
   @media (max-width: 600px) {
       .workflow-topbar {
           grid-template-columns: 1fr;
       }
   }
   """


def get_classify_page_css():
   return """
   .classify-left-panel {
       background: #0d47a1;
       border-radius: 22px;
       padding: 24px 20px;
       min-height: 620px;
       box-sizing: border-box;
       color: #ffffff;
   }
   .classify-logo-wrap {
       margin-bottom: 18px;
   }
   .classify-logo-img {
       width: 185px;
       max-width: 100%;
       display: block;
   }
   .classify-title {
       font-size: 18px;
       font-weight: 700;
       color: #ffd8cc;
       margin-bottom: 8px;
       line-height: 1.3;
   }
   .classify-subtitle {
       font-size: 13px;
       font-weight: 600;
       color: #dbe8ff;
       line-height: 1.35;
       margin-bottom: 28px;
   }
   .left-group-title {
       font-size: 14px;
       font-weight: 700;
       color: #ffffff;
       margin-top: 10px;
       margin-bottom: 10px;
   }
   .left-divider {
       border: none;
       height: 1px;
       background: rgba(255,255,255,0.18);
       margin-top: 18px;
       margin-bottom: 18px;
   }
   .left-menu-form {
       margin: 0 0 10px 0;
   }
   .left-menu-btn {
       width: 100%;
       border: 1px solid #d7d9dd;
       border-radius: 14px;
       padding: 13px 14px;
       font-size: 15px;
       font-weight: 700;
       cursor: pointer;
       background: #f7f7f8;
       color: #4b5563;
       box-sizing: border-box;
       font-family: inherit;
       appearance: none;
       -webkit-appearance: none;
   }
   .left-menu-btn.active {
       background: #f44747;
       color: #ffffff;
       border: 1px solid #f44747;
   }
   .classify-topbar {
       background: #e3e5ea;
       border-radius: 18px;
       padding: 8px;
       display: grid;
       grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
       gap: 14px;
       box-sizing: border-box;
       width: 100%;
       margin-bottom: 22px;
   }
   .page-divider {
       border: none;
       height: 1px;
       background: #d2d6dc;
       margin-top: 10px;
       margin-bottom: 24px;
   }
   .panel-title {
       font-size: 15px;
       font-weight: 700;
       color: #4b5563;
       margin-bottom: 10px;
   }
   .upload-hint-box {
       background: #dce9fb;
       border: 1px solid #c9daf4;
       border-radius: 12px;
       padding: 14px 16px;
       color: #4177bb;
       font-size: 14px;
       font-weight: 600;
       margin-top: 14px;
       margin-bottom: 18px;
   }
   .section-card {
       background: #ffffff;
       border: 1px solid #e4e7ec;
       border-radius: 18px;
       padding: 20px;
       box-sizing: border-box;
       margin-top: 14px;
   }
   .section-card-title {
       font-size: 20px;
       font-weight: 700;
       color: #111827;
       margin-bottom: 8px;
   }
   .section-card-subtitle {
       font-size: 14px;
       color: #6b7280;
       line-height: 1.5;
       margin-bottom: 14px;
   }
   .empty-state-box {
       background: #f8fafc;
       border: 1px dashed #cbd5e1;
       border-radius: 14px;
       padding: 28px 18px;
       text-align: center;
       color: #64748b;
       font-size: 14px;
   }
   .runs-placeholder {
       background: #ffffff;
       border: 1px solid #e4e7ec;
       border-radius: 18px;
       padding: 24px;
       margin-top: 18px;
   }
   .runs-placeholder-title {
       font-size: 20px;
       font-weight: 700;
       color: #111827;
       margin-bottom: 8px;
   }
   .runs-placeholder-text {
       font-size: 14px;
       color: #6b7280;
       line-height: 1.5;
   }
   .runs-header-cell {
       background: #4b5563;
       color: #ffffff;
       border-radius: 12px;
       padding: 12px 14px;
       font-size: 14px;
       font-weight: 700;
       margin-bottom: 8px;
   }
   .runs-cell {
       padding-top: 10px;
       padding-bottom: 10px;
       font-size: 14px;
       color: #374151;
       word-break: break-word;
   }
   .status-pill {
       display: inline-block;
       padding: 5px 12px;
       border-radius: 999px;
       color: #ffffff;
       font-size: 12px;
       font-weight: 700;
   }
   .status-pill.uploaded {
       background: #64748b;
   }
   .status-pill.submitted {
       background: #f59e0b;
   }
   .status-pill.running {
       background: #2563eb;
   }
   .status-pill.completed {
       background: #16a34a;
   }
   .status-pill.failed {
       background: #dc2626;
   }
   .run-meta-card {
       background: #ffffff;
       border: 1px solid #e4e7ec;
       border-radius: 18px;
       padding: 18px;
       margin-bottom: 18px;
   }
   .run-meta-title {
       font-size: 20px;
       font-weight: 700;
       color: #111827;
       margin-bottom: 12px;
   }
   .run-meta-grid {
       display: grid;
       grid-template-columns: 1fr 1fr 1fr;
       gap: 12px;
   }
   .run-meta-item {
       background: #f8fafc;
       border: 1px solid #e5e7eb;
       border-radius: 12px;
       padding: 12px;
   }
   .run-meta-label {
       font-size: 12px;
       color: #6b7280;
       margin-bottom: 4px;
       font-weight: 600;
   }
   .run-meta-value {
       font-size: 14px;
       color: #111827;
       font-weight: 700;
       word-break: break-word;
   }
   .pagination-summary {
       text-align: center;
       font-size: 16px;
       font-weight: 700;
       color: #374151;
       padding-top: 8px;
   }
   .pagination-right-label {
       font-size: 12px;
       font-weight: 700;
       color: #6b7280;
       margin-bottom: 4px;
   }
   .pagination-table-wrap {
       margin-top: 6px;
   }
   .stFileUploader {
       margin-bottom: 0.25rem;
   }
   @media (max-width: 1200px) {
       .classify-topbar {
           grid-template-columns: 1fr 1fr 1fr;
       }
       .run-meta-grid {
           grid-template-columns: 1fr 1fr;
       }
   }
   @media (max-width: 900px) {
       .classify-topbar {
           grid-template-columns: 1fr 1fr;
       }
       .run-meta-grid {
           grid-template-columns: 1fr;
       }
   }
   @media (max-width: 600px) {
       .classify-topbar {
           grid-template-columns: 1fr;
       }
   }
   """