import streamlit as st
import base64
from utils.styles import load_css, get_global_css, get_home_page_css

def get_base64_image(image_path):
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label, slug, active=False):
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def option_card(label, slug):
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="option-card">{label}</button>
</form>
   """


def render():
   load_css(get_global_css() + get_home_page_css())
   logo_base64 = get_base64_image("/home/dataiku/workspace/code_studio-versioned/streamlit/assets/Alstom_logo.svg.png")
   st.markdown(
       f"""
<div class="home-shell">
<div class="brand-panel">
<div class="brand-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="brand-logo-img"/>
</div>
<div class="brand-title">AI-Parts Classifier</div>
</div>
<div class="content-panel">
<div class="nav-strip">
                   {nav_pill("🏠 Home", "home", True)}
                   {nav_pill("🔒 Admin", "admin")}
                   {nav_pill("🛡️ Super Admin", "super_admin")}
                   {nav_pill("ℹ️ About", "about")}
                   {nav_pill("❓ Help", "help")}
</div>
<hr class="section-divider"/>
<div class="options-title">Options</div>
<div class="options-grid">
                   {option_card("Classify/Create Parts", "classify")}
                   {option_card("Validate Classified Parts", "validation")}
                   {option_card("Model Retraining", "retraining")}
</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
