import streamlit as st
from utils.styles import load_css, get_global_css

def render():
   load_css(get_global_css())
   st.title("Model Retraining")
   st.write("This is a placeholder page for model retraining.")
   if st.button("← Back to Home"):
       st.query_params["page"] = "home"
       st.rerun()