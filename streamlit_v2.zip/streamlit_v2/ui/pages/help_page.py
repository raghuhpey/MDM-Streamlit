import streamlit as st
from utils.styles import load_css, get_global_css


def render():
   load_css(get_global_css())
   st.title("Help")
   st.write("This page will contain user guidance and FAQs.")
   if st.button("← Back to Home"):
       st.query_params["page"] = "home"
       st.rerun()