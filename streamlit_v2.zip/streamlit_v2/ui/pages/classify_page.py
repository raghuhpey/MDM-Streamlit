import base64
import hashlib
from io import BytesIO
import pandas as pd
import streamlit as st
from services.run_storage_service import (
   create_run,
   get_current_user_login,
   list_runs,
   load_input_preview_df,
   load_output_df,
   load_run_metadata,
)
from utils.pagination import get_page_bounds, get_page_df, get_total_pages
from utils.styles import (
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def get_base64_image(image_path):
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label, slug, active=False):
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def left_menu_btn(label, sub_value, active=False):
   css_class = "left-menu-btn active" if active else "left-menu-btn"
   return f"""
<form method="get" class="left-menu-form">
<input type="hidden" name="page" value="classify">
<input type="hidden" name="sub" value="{sub_value}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def read_uploaded_file(file_name, file_bytes):
   lower_name = file_name.lower()
   if lower_name.endswith(".xlsx"):
       return pd.read_excel(BytesIO(file_bytes))
   if lower_name.endswith(".csv"):
       encodings_to_try = ["utf-8", "utf-8-sig", "cp1252", "latin-1", "iso-8859-1"]
       last_error = None
       for enc in encodings_to_try:
           try:
               return pd.read_csv(BytesIO(file_bytes), encoding=enc)
           except Exception as e:
               last_error = e
       raise ValueError(
           f"Could not read CSV with supported encodings. Last error: {last_error}"
       )
   raise ValueError("Unsupported file type. Please upload CSV or XLSX.")

def get_selected_submenu():
   selected = st.query_params.get("sub", "existing_parts")
   if isinstance(selected, list):
       selected = selected[0]
   if selected not in ["existing_parts", "create_new_parts", "runs", "run_detail"]:
       selected = "existing_parts"
   return selected

def get_selected_run_id():
   run_id = st.query_params.get("run_id")
   if isinstance(run_id, list):
       run_id = run_id[0]
   return run_id

def get_menu_config(selected_menu):
   if selected_menu == "existing_parts":
       return {
           "page_title": "Input Preview",
           "upload_title": "Upload file to classify",
           "hint_text": "Upload a supported file to create a prediction run and preview the input data.",
           "run_type": "classify_existing_parts",
           "current_run_key": "current_existing_run_id",
           "signature_key": "existing_parts_upload_signature",
           "action_button_label": "Classify",
           "scenario_id": "RUN_PREDICTION_JOB",
       }
   return {
       "page_title": "Input Preview",
       "upload_title": "Upload file to create new parts",
       "hint_text": "Upload a supported file to create a run and preview the input data.",
       "run_type": "create_new_parts",
       "current_run_key": "current_new_parts_run_id",
       "signature_key": "new_parts_upload_signature",
       "action_button_label": "Create Parts",
       "scenario_id": None,
   }

def create_persisted_run(uploaded_file, selected_menu):
   config = get_menu_config(selected_menu)
   file_bytes = uploaded_file.getvalue()
   signature = f"{uploaded_file.name}:{hashlib.md5(file_bytes).hexdigest()}"
   if st.session_state.get(config["signature_key"]) == signature:
       return
   input_df = read_uploaded_file(uploaded_file.name, file_bytes)
   run_metadata = create_run(
       uploaded_file_name=uploaded_file.name,
       file_bytes=file_bytes,
       input_df=input_df,
       run_type=config["run_type"],
       scenario_id=config["scenario_id"],
   )
   st.session_state[config["current_run_key"]] = run_metadata["prediction_job_id"]
   st.session_state[config["signature_key"]] = signature

def render_paginated_dataframe(df, pager_prefix, default_page_size=10):
   total_rows = len(df)
   if total_rows == 0:
       st.markdown(
           """
<div class="empty-state-box">
               No rows available.
</div>
           """,
           unsafe_allow_html=True
       )
       return
   page_key = f"{pager_prefix}_page"
   if page_key not in st.session_state:
       st.session_state[page_key] = 1
   page_size = default_page_size
   total_pages = get_total_pages(total_rows, page_size)
   current_page = st.session_state[page_key]
   current_page = max(1, min(current_page, total_pages))
   st.session_state[page_key] = current_page
   start_idx, end_idx = get_page_bounds(current_page, page_size, total_rows)
   left_col, center_col, right_col = st.columns([2.2, 4.8, 2.0])
   with left_col:
       prev_col, next_col = st.columns(2)
       with prev_col:
           if st.button(
               "Prev",
               key=f"{pager_prefix}_prev",
               disabled=(current_page == 1),
               use_container_width=True
           ):
               st.session_state[page_key] = current_page - 1
               st.rerun()
       with next_col:
           if st.button(
               "Next",
               key=f"{pager_prefix}_next",
               disabled=(current_page == total_pages),
               use_container_width=True
           ):
               st.session_state[page_key] = current_page + 1
               st.rerun()
   with center_col:
       st.markdown(
           f"""
<div class="pagination-summary">
               Page {current_page} / {total_pages} • Rows {start_idx + 1}-{end_idx} of {total_rows}
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           '<div class="pagination-right-label">Go to page</div>',
           unsafe_allow_html=True
       )
       selected_page = st.number_input(
           "Go to page",
           min_value=1,
           max_value=total_pages,
           value=current_page,
           step=1,
           key=f"{pager_prefix}_page_input",
           label_visibility="collapsed"
       )
       if selected_page != current_page:
           st.session_state[page_key] = int(selected_page)
           st.rerun()
   page_df = get_page_df(df, st.session_state[page_key], page_size)
   st.markdown('<div class="pagination-table-wrap">', unsafe_allow_html=True)
   st.dataframe(page_df, use_container_width=True, hide_index=True)
   st.markdown("</div>", unsafe_allow_html=True)

def render_upload_view(selected_menu):
   config = get_menu_config(selected_menu)
   st.markdown(
       f'<div class="panel-title">{config["upload_title"]}</div>',
       unsafe_allow_html=True
   )
   uploaded_file = st.file_uploader(
       "Upload file",
       type=["csv", "xlsx"],
       label_visibility="collapsed",
       key=f"uploader_{selected_menu}"
   )
   if uploaded_file is not None:
       try:
           create_persisted_run(uploaded_file, selected_menu)
       except Exception as e:
           st.error(f"File upload failed: {e}")
   st.markdown(
       f"""
<div class="upload-hint-box">
           {config["hint_text"]}
</div>
       """,
       unsafe_allow_html=True
   )
   current_run_id = st.session_state.get(config["current_run_key"])
   current_run = load_run_metadata(current_run_id) if current_run_id else None
   if current_run is None:
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Input Preview</div>
<div class="section-card-subtitle">
                   Upload a file to create a run and preview the input data.
</div>
<div class="empty-state-box">
                   No input preview available yet.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       return
   input_df = load_input_preview_df(current_run["prediction_job_id"])
   st.markdown(
       f"""
<div class="section-card">
<div class="section-card-title">{config["page_title"]}</div>
<div class="section-card-subtitle">
<b>Run ID:</b> {current_run["prediction_job_id"]} &nbsp;&nbsp;|&nbsp;&nbsp;
<b>Rows:</b> {current_run["row_count"]} &nbsp;&nbsp;|&nbsp;&nbsp;
<b>Status:</b> {current_run["status"]}
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if input_df is None:
       st.markdown(
           """
<div class="empty-state-box">
               Input preview file not found in managed folder.
</div>
           """,
           unsafe_allow_html=True
       )
       return
   render_paginated_dataframe(
       input_df,
       pager_prefix=f"{current_run['prediction_job_id']}_input"
   )
   action_cols = st.columns([8, 2])
   with action_cols[1]:
       clicked = st.button(
           config["action_button_label"],
           key=f"{selected_menu}_action_btn_{current_run['prediction_job_id']}",
           use_container_width=True
       )
   if clicked:
       st.info("Next step will wire this button to the backend execution flow.")

def render_runs_view():
   run_records = list_runs()
   st.markdown(
       """
<div class="runs-placeholder">
<div class="runs-placeholder-title">Runs</div>
<div class="runs-placeholder-text">
               Persisted runs stored in the managed folder.
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if not run_records:
       st.markdown(
           """
<div class="section-card">
<div class="empty-state-box">
                   No runs available yet.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       return
   header_cols = st.columns([2.8, 2.6, 1.6, 0.9, 1.4, 2.1, 1.2])
   headers = ["Run ID", "File Name", "Created By", "Rows", "Status", "Created", "Actions"]
   for col, header in zip(header_cols, headers):
       with col:
           st.markdown(
               f'<div class="runs-header-cell">{header}</div>',
               unsafe_allow_html=True
           )
   for run in run_records:
       row_cols = st.columns([2.8, 2.6, 1.6, 0.9, 1.4, 2.1, 1.2])
       with row_cols[0]:
           st.markdown(f'<div class="runs-cell">{run["prediction_job_id"]}</div>', unsafe_allow_html=True)
       with row_cols[1]:
           st.markdown(f'<div class="runs-cell">{run["file_name"]}</div>', unsafe_allow_html=True)
       with row_cols[2]:
           st.markdown(f'<div class="runs-cell">{run["created_by"]}</div>', unsafe_allow_html=True)
       with row_cols[3]:
           st.markdown(f'<div class="runs-cell">{run["row_count"]}</div>', unsafe_allow_html=True)
       with row_cols[4]:
           status_class = str(run["status"]).lower()
           st.markdown(
               f'<div class="runs-cell"><span class="status-pill {status_class}">{run["status"]}</span></div>',
               unsafe_allow_html=True
           )
       with row_cols[5]:
           st.markdown(f'<div class="runs-cell">{run["created_at"]}</div>', unsafe_allow_html=True)
       with row_cols[6]:
           if st.button(
               "View",
               key=f'view_run_{run["prediction_job_id"]}',
               use_container_width=True
           ):
               st.query_params["page"] = "classify"
               st.query_params["sub"] = "run_detail"
               st.query_params["run_id"] = run["prediction_job_id"]
               st.rerun()
       st.divider()

def render_run_detail_view():
   run_id = get_selected_run_id()
   run_record = load_run_metadata(run_id) if run_id else None
   if run_record is None:
       st.error("Run not found.")
       return
   top_cols = st.columns([1.5, 6])
   with top_cols[0]:
       if st.button("← Back to Runs", key="back_to_runs_btn", use_container_width=True):
           st.query_params["page"] = "classify"
           st.query_params["sub"] = "runs"
           st.rerun()
   st.markdown(
       f"""
<div class="run-meta-card">
<div class="run-meta-title">Run Detail</div>
<div class="run-meta-grid">
<div class="run-meta-item">
<div class="run-meta-label">Run ID</div>
<div class="run-meta-value">{run_record["prediction_job_id"]}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">File Name</div>
<div class="run-meta-value">{run_record["file_name"]}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Status</div>
<div class="run-meta-value">{run_record["status"]}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Created By</div>
<div class="run-meta-value">{run_record["created_by"]}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Rows</div>
<div class="run-meta-value">{run_record["row_count"]}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Created At</div>
<div class="run-meta-value">{run_record["created_at"]}</div>
</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   input_df = load_input_preview_df(run_record["prediction_job_id"])
   st.markdown(
       """
<div class="section-card">
<div class="section-card-title">Input Preview</div>
<div class="section-card-subtitle">
               Input preview loaded from the managed folder.
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if input_df is None:
       st.markdown(
           """
<div class="empty-state-box">
               Input preview file not found.
</div>
           """,
           unsafe_allow_html=True
       )
   else:
       render_paginated_dataframe(
           input_df,
           pager_prefix=f'{run_record["prediction_job_id"]}_detail_input'
       )
   output_df = load_output_df(run_record["prediction_job_id"])
   if output_df is not None:
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Output Preview</div>
<div class="section-card-subtitle">
                   Output loaded from the managed folder.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       render_paginated_dataframe(
           output_df,
           pager_prefix=f'{run_record["prediction_job_id"]}_detail_output'
       )
   else:
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Output Preview</div>
<div class="section-card-subtitle">
                   Output is not available yet.
</div>
<div class="empty-state-box">
                   No output available yet.
</div>
</div>
           """,
           unsafe_allow_html=True
       )

def render():
   load_css(get_global_css() + get_home_page_css() + get_classify_page_css())
   selected_menu = get_selected_submenu()
   logo_base64 = get_base64_image("/home/dataiku/workspace/code_studio-versioned/streamlit/assets/Alstom_logo.svg.png")
   left_col, right_col = st.columns([1.15, 4.35], gap="medium")
   with left_col:
       st.markdown(
           f"""
<div class="classify-left-panel">
<div class="classify-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="classify-logo-img"/>
</div>
<div class="classify-title">AI-Parts Classifier</div>
<div class="classify-subtitle">Classification Assist Tool</div>
<div class="left-group-title">Choose</div>
               {left_menu_btn("Classify Existing Parts", "existing_parts", selected_menu == "existing_parts")}
               {left_menu_btn("Create New Parts", "create_new_parts", selected_menu == "create_new_parts")}
<hr class="left-divider"/>
<div class="left-group-title">Section</div>
               {left_menu_btn("Runs", "runs", selected_menu == "runs")}
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           f"""
<div class="classify-topbar">
               {nav_pill("🏠 Home", "home")}
               {nav_pill("🔒 Admin", "admin")}
               {nav_pill("🛡️ Super Admin", "super_admin")}
               {nav_pill("ℹ️ About", "about")}
               {nav_pill("❓ Help", "help")}
</div>
<hr class="page-divider"/>
           """,
           unsafe_allow_html=True
       )
       if selected_menu in ["existing_parts", "create_new_parts"]:
           render_upload_view(selected_menu)
       elif selected_menu == "runs":
           render_runs_view()
       else:
           render_run_detail_view()
