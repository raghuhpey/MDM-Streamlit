Files included:
1. services/prediction_resources.py
2. services/prediction_engine.py
3. services/prediction_service.py

What these do:
- prediction_resources.py loads models, folders, and AOAI clients.
- prediction_engine.py exposes predict_dataframe(input_df, resources, max_workers=4).
- prediction_service.py wraps run execution by prediction_job_id and persists output.

Important note:
The current inference still uses a temporary OneHotEncoder().fit_transform(...) path to preserve your present behavior.
For a stricter production model path, load the fitted encoder artifact used during training.
