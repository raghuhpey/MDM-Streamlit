from __future__ import annotations

from services.prediction_engine import predict_dataframe
from services.prediction_resources import load_prediction_resources
from services.run_storage_service import (
    load_input_preview_df,
    load_run_metadata,
    load_output_df,
    update_run_metadata,
    get_managed_folder,
)
from io import BytesIO


def save_prediction_output_df(prediction_job_id, result_df):
    metadata = load_run_metadata(prediction_job_id)
    if metadata is None:
        raise ValueError(f"Run not found: {prediction_job_id}")

    folder = get_managed_folder()
    buffer = BytesIO()
    result_df.to_parquet(buffer, index=False)
    folder.upload_data("/" + metadata["output_file_path"].lstrip("/"), buffer.getvalue())


def update_prediction_job_status(prediction_job_id, status, error_message=None):
    updates = {"status": status}
    if error_message is not None:
        updates["error_message"] = error_message
    return update_run_metadata(prediction_job_id, updates)


def run_prediction_job(prediction_job_id: str, max_workers: int = 4):
    input_df = load_input_preview_df(prediction_job_id)
    if input_df is None:
        raise ValueError(f"Input preview not found for run: {prediction_job_id}")

    resources = load_prediction_resources()

    update_prediction_job_status(prediction_job_id, "running")
    try:
        result_df = predict_dataframe(input_df, resources=resources, max_workers=max_workers)
        save_prediction_output_df(prediction_job_id, result_df)
        update_prediction_job_status(prediction_job_id, "completed")
        return result_df
    except Exception as exc:
        update_prediction_job_status(prediction_job_id, "failed", error_message=str(exc))
        raise
