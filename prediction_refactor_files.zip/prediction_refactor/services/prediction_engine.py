from __future__ import annotations

import io
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Iterable

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import OneHotEncoder

from services.prediction_resources import (
    PredictionResources,
    load_governance_index,
    load_governance_metadata,
)


TEXT_COL = "combined_description"
BINARY_COLS: list[str] = []
CATEGORICAL_COLS = [
    "clamp_commodity_codes",
    "is_related_to_fire&smoke?",
    "repairable_?",
    "perishable_part",
    "hazardous_goods_(s.f.)",
    "unit_of_measure_information",
    "usability",
    "part_rohs",
]

MAX_CHUNK_TOKENS = 7000
MAX_TPM = 320_000
EMBED_BATCH_SIZE = 32
MAX_RETRIES = 3


def compose_description_upper(obj: str, doc: str) -> str:
    obj = obj if isinstance(obj, str) else ""
    doc = doc if isinstance(doc, str) else ""
    if obj and doc and re.search(re.escape(obj), doc, flags=re.IGNORECASE):
        head = doc
    else:
        head = f"{doc} FOR {obj}" if doc and obj else doc or obj
    return (head.strip().upper() + ".") if head.strip() else ""


def count_tokens(text: str) -> int:
    return len(text) // 4


def data_cleaning_pipeline(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out = out.apply(
        lambda col: col.str.strip().str.replace(r"\s+", " ", regex=True)
        if col.dtype == "object" else col
    )
    out = out[~out["short_description_(english)"].isna()].copy()
    out = out[[
        "short_description_(english)", "long_description_(english)",
        "part_manufacturer_list_information", "clamp_commodity_codes",
        "hazardous_goods_(s.f.)", "is_related_to_fire&smoke?", "part_rohs",
        "perishable_part", "repairable_?", "unit_of_measure_information", "usability",
    ]]

    fill_map = {
        "part_manufacturer_list_information": "unknown_manufacturer",
        "clamp_commodity_codes": "Other_Commodity_code",
        "hazardous_goods_(s.f.)": "unknown",
        "is_related_to_fire&smoke?": "unknown",
        "part_rohs": "not_defined",
        "perishable_part": "unknown",
        "repairable_?": "unknown",
        "unit_of_measure_information": "other_measure",
        "usability": "other_usability",
    }
    for col, val in fill_map.items():
        out[col] = out[col].fillna(val)

    out[TEXT_COL] = out.apply(
        lambda r: compose_description_upper(r["short_description_(english)"], r["long_description_(english)"]),
        axis=1,
    )
    out[TEXT_COL] = out[TEXT_COL] + ", manufacturer is " + out["part_manufacturer_list_information"]
    return out


def embed_batch_with_retry(resources: PredictionResources, texts: list[str]):
    for attempt in range(MAX_RETRIES):
        try:
            response = resources.client_aoai.embeddings.create(
                model=resources.embed_model_name,
                input=texts,
            )
            return [r.embedding for r in response.data]
        except Exception as exc:
            retryable = any(word in str(exc).lower() for word in ["rate limit", "timeout", "internal", "429"])
            if (not retryable) or attempt == MAX_RETRIES - 1:
                raise
            time.sleep(2 ** attempt)


def get_embeddings(resources: PredictionResources, df: pd.DataFrame) -> pd.DataFrame:
    missing_texts = list(set(df[TEXT_COL].astype(str)))
    existing_df = pd.DataFrame(columns=[TEXT_COL, "embedding"])

    token_budget = 0
    start_time = time.time()
    new_rows = []
    batch = []

    for text in missing_texts:
        tokens = count_tokens(text)
        if tokens > MAX_CHUNK_TOKENS:
            continue

        if token_budget + tokens > MAX_TPM:
            elapsed = time.time() - start_time
            sleep_time = max(0, 60 - elapsed)
            if sleep_time > 0:
                time.sleep(sleep_time)
            token_budget = 0
            start_time = time.time()

        batch.append(text)
        token_budget += tokens

        if len(batch) >= EMBED_BATCH_SIZE:
            embeddings = embed_batch_with_retry(resources, batch)
            new_rows.append(pd.DataFrame({TEXT_COL: batch, "embedding": embeddings}))
            batch = []

    if batch:
        embeddings = embed_batch_with_retry(resources, batch)
        new_rows.append(pd.DataFrame({TEXT_COL: batch, "embedding": embeddings}))

    if new_rows:
        existing_df = pd.concat([existing_df] + new_rows, ignore_index=True)
    return existing_df


def process_binary(df: pd.DataFrame) -> np.ndarray:
    if not BINARY_COLS:
        return np.empty((len(df), 0))
    return df[BINARY_COLS].replace({"True": 1, "False": 0, True: 1, False: 0}).fillna(0).astype(int).values


def predict_via_neural_network(model, x_test_aligned: pd.DataFrame) -> np.ndarray:
    x_np = x_test_aligned.values.astype("float32")
    logits = model.predict(x_np, verbose=0)
    y_proba = tf.nn.softmax(logits, axis=1).numpy()
    return np.argmax(y_proba, axis=1)


def predict_models(resources: PredictionResources, df_input: pd.DataFrame) -> pd.DataFrame:
    df_cleaned = data_cleaning_pipeline(df_input)
    embedding_df = get_embeddings(resources, df_cleaned)

    df_merged = df_cleaned.merge(embedding_df, on=TEXT_COL, how="left")
    x_test_df = df_merged.copy()

    x_test_emb = np.vstack(x_test_df["embedding"].values)
    x_test_pca = resources.pca_model.transform(x_test_emb)
    df_x_test_pca = x_test_df.join(pd.DataFrame(x_test_pca, index=x_test_df.index).add_prefix("pca_"))
    df_x_test_pca.drop(columns=["embedding"], inplace=True)
    x_test_df = df_x_test_pca.copy()

    x_test_text = x_test_df.drop(columns=[*BINARY_COLS, *CATEGORICAL_COLS], axis=1)
    x_test_bin = process_binary(x_test_df)

    # Temporary: current behavior preserved. Long term, load the fitted encoder artifact used in training.
    ohe = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
    x_test_cat = ohe.fit_transform(x_test_df[CATEGORICAL_COLS])

    x_test_np = np.hstack([x_test_text, x_test_bin, x_test_cat])

    text_feature_names = [f"text_emb_{i}" for i in range(x_test_text.shape[1])]
    categorical_feature_names = ohe.get_feature_names_out(CATEGORICAL_COLS)
    feature_names = text_feature_names + BINARY_COLS + list(categorical_feature_names)

    x_test_aligned = pd.DataFrame(x_test_np, columns=feature_names, index=x_test_df.index)
    x_test_aligned = x_test_aligned.reindex(columns=resources.feature_trained_on, fill_value=0)

    model1_pred = resources.model1_pipeline.predict(x_test_aligned)
    model2_pred = resources.model2_pipeline.predict(x_test_aligned)
    model3_pred = predict_via_neural_network(resources.model3_pipeline, x_test_aligned)

    out = df_cleaned.copy()
    out["Model 1 OP"] = resources.label_encoder_y.inverse_transform(model1_pred)
    out["Model 2 OP"] = resources.label_encoder_y.inverse_transform(model2_pred)
    out["Model 3 OP"] = resources.label_encoder_y.inverse_transform(model3_pred)
    return out


def normalize_unspsc_code(x):
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None
    if isinstance(x, int):
        s = str(x)
        return s.zfill(8) if len(s) <= 8 else None
    if isinstance(x, float):
        if x.is_integer():
            s = str(int(x))
            return s.zfill(8) if len(s) <= 8 else None
        return None
    s = str(x).strip()
    m = re.match(r"^(\d{8})\.0+$", s)
    if m:
        return m.group(1)
    s = re.sub(r"\D", "", s)
    return s if len(s) == 8 else None


def retrieve_governance_context(resources: PredictionResources, query_text: str, k: int = 5):
    response = resources.client_aoai.embeddings.create(
        model=resources.embed_model_name,
        input=[query_text.lower()],
    )
    query_vec = np.array(response.data[0].embedding, dtype="float32").reshape(1, -1)
    gov_index = load_governance_index(resources)
    gov_metadata = load_governance_metadata(resources)
    distances, indices = gov_index.search(query_vec, k)

    retrieved = []
    for idx, dist in zip(indices[0], distances[0]):
        item = gov_metadata[idx].copy()
        item["distance"] = float(dist)
        retrieved.append(item)
    return retrieved


def extract_unspsc_candidates(retrieved_items: list[dict]) -> dict:
    candidates = {}
    for item in retrieved_items:
        code = normalize_unspsc_code(item.get("UNSPSC - UNSPSC"))
        if not code:
            continue
        if code not in candidates:
            candidates[code] = {
                "family": item.get("Family Name English"),
                "parent": item.get("Parent information"),
                "description": item.get("Description of Code"),
            }
    return candidates


def build_rag_prompt(part_description: str, retrieved_items: list[dict], unspsc_candidates: dict, model_preds=None) -> str:
    governance_lines = []
    for item in retrieved_items:
        examples = []
        for i in range(1, 11):
            col_name = f"Part Description Example {i}"
            if col_name in item and item[col_name] is not None:
                examples.append(str(item[col_name]))
        line = (
            f"- Family: {item.get('Family Name English')}, "
            f"Parent: {item.get('Parent information')}, "
            f"Description: {item.get('Description of Code')}, "
            f"UNSPSC: {item.get('UNSPSC - UNSPSC')}, "
            f"Examples: {', '.join(examples)}"
        )
        governance_lines.append(line)

    governance_context = "\n".join(governance_lines)
    candidate_context = "\n".join(
        [
            f"- UNSPSC {code}: Family {info['family']}, Parent {info['parent']}, Description {info['description']}"
            for code, info in unspsc_candidates.items()
        ]
    )

    model_block = ""
    if model_preds:
        model_block = f"""
Model predictions (only consider these if they are supported by the Knowledge Base Context):
- Model 1: {model_preds.get('model1')}
- Model 2: {model_preds.get('model2')}
- Model 3: {model_preds.get('model3')}
"""

    return f"""
You are a UNSPSC classification expert working with Alstom governance rules.
Part description:
\"{part_description}\"
{model_block}
Knowledge Base Context:
{governance_context}
Allowed UNSPSC candidates:
{candidate_context}
Judge rule:
1) First check whether any of the Model 1/Model 2/Model 3 codes is the correct match based ONLY on the Knowledge Base Context above.
2) If one of the model codes is correct, output that exact code.
3) If none of the model codes is correct/supported by the KB context, then choose the best code ONLY from the Allowed UNSPSC candidates list.
4) If no match exists in the KB context/candidates, do not output a UNSPSC code.
5) The explanation should mention if any of the Model outputs are selected as the correct UNSPSC code and why, otherwise provide a reasoning as to why GenAI predicted another one from the KB.
Output rules:
- The first line MUST be exactly: UNSPSC: <8-digit code> OR UNSPSC: NONE
- The second line MUST be: Explanation: <one sentence>
- Do not add extra lines.
"""


def parse_genai_response(text: str):
    match = re.search(r"UNSPSC\s*:\s*(\d{8}|NONE)", text, re.IGNORECASE)
    predicted = match.group(1) if match else None
    if predicted and predicted.upper() == "NONE":
        predicted = None
    if predicted is None:
        fallback = re.search(r"\b(\d{8})\b", text)
        predicted = fallback.group(1) if fallback else None
    expl = re.search(r"Explanation\s*:\s*(.*?)(?:Confidence\s*:|$)", text, re.DOTALL | re.IGNORECASE)
    explanation = expl.group(1).strip() if expl else ""
    return predicted, explanation


def predict_unspsc_with_rag(resources: PredictionResources, part_description: str, model1=None, model2=None, model3=None):
    gov_metadata = load_governance_metadata(resources)
    kb_codes = {normalize_unspsc_code(item.get("UNSPSC - UNSPSC")) for item in gov_metadata}
    kb_codes.discard(None)

    retrieved = retrieve_governance_context(resources, part_description, k=5)
    unspsc_candidates = extract_unspsc_candidates(retrieved)

    m1 = normalize_unspsc_code(model1)
    m2 = normalize_unspsc_code(model2)
    m3 = normalize_unspsc_code(model3)
    m1 = m1 if m1 in kb_codes else None
    m2 = m2 if m2 in kb_codes else None
    m3 = m3 if m3 in kb_codes else None

    prompt = build_rag_prompt(resources=resources, part_description=part_description, retrieved_items=retrieved, unspsc_candidates=unspsc_candidates, model_preds={"model1": m1, "model2": m2, "model3": m3}) if False else build_rag_prompt(part_description, retrieved, unspsc_candidates, {"model1": m1, "model2": m2, "model3": m3})

    response = resources.client_gpt.chat.completions.create(
        model=resources.judge_model_name,
        messages=[
            {"role": "system", "content": "You are a UNSPSC part classification subject matter expert."},
            {"role": "user", "content": prompt},
        ],
        temperature=0,
    )

    raw_text = response.choices[0].message.content
    predicted_unspsc, explanation = parse_genai_response(raw_text)

    if predicted_unspsc is None:
        for candidate in [m1, m2, m3]:
            if candidate and candidate in kb_codes:
                predicted_unspsc = candidate
                if not explanation:
                    explanation = "Chosen from ML model outputs because LLM did not return a valid UNSPSC line."
                break

    if predicted_unspsc is None and unspsc_candidates:
        predicted_unspsc = next(iter(unspsc_candidates.keys()))
        if not explanation:
            explanation = "Chosen from top retrieved KB candidate because no valid model code was accepted."

    predicted_unspsc = normalize_unspsc_code(predicted_unspsc)
    if predicted_unspsc and predicted_unspsc not in kb_codes:
        predicted_unspsc = None

    if predicted_unspsc is None:
        source = "NONE"
    elif predicted_unspsc == m1:
        source = "ML(Model1)"
    elif predicted_unspsc == m2:
        source = "ML(Model2)"
    elif predicted_unspsc == m3:
        source = "ML(Model3)"
    else:
        source = "LLM as a Judge"

    return predicted_unspsc, explanation, source


def _judge_row(resources: PredictionResources, row: pd.Series) -> dict:
    query = row["short_description_(english)"]
    m1 = row.get("Model 1 OP")
    m2 = row.get("Model 2 OP")
    m3 = row.get("Model 3 OP")
    code, explanation, source = predict_unspsc_with_rag(resources, query, model1=m1, model2=m2, model3=m3)
    return {
        "LLM as a Judge OP": code,
        "LLM Decision Source": source,
        "Explanation": explanation,
    }


def run_llm_judge(resources: PredictionResources, df: pd.DataFrame, max_workers: int = 4) -> pd.DataFrame:
    records = [None] * len(df)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_judge_row, resources, row): idx for idx, row in df.iterrows()}
        for future in as_completed(futures):
            idx = futures[future]
            records[idx] = future.result()
    judge_df = pd.DataFrame(records)
    return pd.concat([df.reset_index(drop=True), judge_df], axis=1)


def predict_dataframe(input_df: pd.DataFrame, resources: PredictionResources, max_workers: int = 4) -> pd.DataFrame:
    ml_df = predict_models(resources, input_df)
    final_df = run_llm_judge(resources, ml_df, max_workers=max_workers)
    return final_df
