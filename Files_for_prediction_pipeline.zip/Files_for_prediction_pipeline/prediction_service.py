from __future__ import annotations
from services.classification_table_service import (
   fetch_classification_run_input_df,
   mark_run_completed,
   mark_run_failed,
   mark_run_running,
   persist_prediction_results_to_classification_table,
)
from services.prediction_engine import predict_dataframe
from services.prediction_resources import load_prediction_resources
from services.run_storage_service import save_ignored_records_csv, save_prediction_output_df

def run_prediction_job(run_id: str, max_workers: int = 4):
   input_df = fetch_classification_run_input_df(run_id)
   if input_df is None or input_df.empty:
       raise ValueError(f"No input rows found in MDM_classification_tbl for run: {run_id}")
   mark_run_running(run_id)
   try:
       resources = load_prediction_resources()
       result_df, ignored_df = predict_dataframe(
           input_df,
           resources=resources,
           max_workers=max_workers,
       )
       save_prediction_output_df(run_id, result_df)
       save_ignored_records_csv(run_id, ignored_df)
       persist_prediction_results_to_classification_table(run_id, result_df)
       mark_run_completed(run_id)
       return result_df
   except Exception:
       mark_run_failed(run_id)
       raise
 