import json
from urllib.parse import urlencode
import streamlit as st
import streamlit.components.v1 as components
from services.ui_state_service import load_ui_state, save_ui_state

PERSISTED_STATE_KEYS = {
   "nav_page",
   "nav_sub",
   "nav_run_id",
   "current_page",
   "current_flow",
   "current_existing_run_id",
   "current_new_parts_run_id",
   "existing_parts_upload_signature",
   "new_parts_upload_signature",
}

def restore_persisted_ui_state():
   saved = load_ui_state()
   if not saved:
       return
   for key in PERSISTED_STATE_KEYS:
       if key in saved:
           st.session_state[key] = saved[key]

# def restore_persisted_ui_state():
#    saved = load_ui_state()
#    if not saved:
#        return
#    for key in PERSISTED_STATE_KEYS:
#        if key in saved:
#            st.session_state[key] = saved[key]
#    # If URL already has explicit navigation, prefer URL over saved JSON
#    qp_page = _first(st.query_params.get("page"))
#    qp_sub = _first(st.query_params.get("sub"))
#    qp_run_id = _first(st.query_params.get("run_id"))
#    if qp_page is not None:
#        st.session_state["nav_page"] = qp_page
#    if "sub" in st.query_params:
#        st.session_state["nav_sub"] = qp_sub
#    if "run_id" in st.query_params:
#        st.session_state["nav_run_id"] = qp_run_id

def persist_persisted_ui_state(extra: dict | None = None):
   payload = {key: st.session_state.get(key) for key in PERSISTED_STATE_KEYS}
   if extra:
       payload.update(extra)
   save_ui_state(payload)
   
def _first(value, default=None):
  if isinstance(value, list):
      return value[0] if value else default
  return value if value not in (None, "") else default
  
def init_session_state():
  defaults = {
      "nav_page": "home",
      "nav_sub": None,
      "nav_run_id": None,
      "current_page": "Home",
      "current_flow": None,
      "prediction_output_df": None,
      "validation_df": None,
      "prediction_job_id": None,
      "validation_job_id": None,
      "prediction_status": None,
      "validation_status": None,
      "error_message": None,
      "success_message": None,
      "current_existing_run_id": None,
      "current_new_parts_run_id": None,
      "existing_parts_upload_signature": None,
      "new_parts_upload_signature": None,
  }
  for key, value in defaults.items():
      if key not in st.session_state:
          st.session_state[key] = value

def _build_query_string(page=None, sub=None, run_id=None):
  params = {}
  if page:
      params["page"] = page
  if sub:
      params["sub"] = sub
  if run_id:
      params["run_id"] = run_id
  return urlencode(params)

def _write_navigation_to_query_params(page=None, sub=None, run_id=None):
  params = {}
  if page:
      params["page"] = page
  if sub:
      params["sub"] = sub
  if run_id:
      params["run_id"] = run_id
  for key in list(st.query_params.keys()):
      del st.query_params[key]
  for key, value in params.items():
      st.query_params[key] = value

def bootstrap_navigation_from_browser_storage():
   components.html(
       """
<script>
(function() {
 try {
   const key = "ai_parts_classifier_route_v2";
   const currentUrl = new URL(window.location.href);
   const hasPage = currentUrl.searchParams.get("page");
   if (!hasPage) {
     let saved = null;
     try { saved = window.localStorage.getItem(key); } catch (e) {}
     if (saved && typeof saved === "string" && saved.trim()) {
       const currentQs = (currentUrl.search || "").replace(/^\\?/, "");
       if (currentQs !== saved) {
         const target = currentUrl.pathname + "?" + saved + currentUrl.hash;
         window.location.replace(target);
       }
     }
   }
 } catch (e) {}
})();
</script>
       """,
       height=0,
       width=0,
   )

def persist_navigation_in_browser(page=None, sub=None, run_id=None):
   qs = _build_query_string(page=page, sub=sub, run_id=run_id)
   qs_json = json.dumps(qs)
   components.html(
       f"""
<script>
(function() {{
 try {{
   const key = "ai_parts_classifier_route_v2";
   const qs = {qs_json};
   try {{ window.localStorage.setItem(key, qs); }} catch (e) {{}}
   const currentUrl = new URL(window.location.href);
   const currentQs = (currentUrl.search || "").replace(/^\\?/, "");
   if (qs && currentQs !== qs) {{
     const target = currentUrl.pathname + "?" + qs + currentUrl.hash;
     window.history.replaceState({{}}, "", target);
   }}
 }} catch (e) {{}}
}})();
</script>
       """,
       height=0,
       width=0,
   )

def sync_navigation_state():
   qp_has_page = "page" in st.query_params
   qp_has_sub = "sub" in st.query_params
   qp_has_run_id = "run_id" in st.query_params
   qp_page = _first(st.query_params.get("page")) if qp_has_page else None
   qp_sub = _first(st.query_params.get("sub")) if qp_has_sub else None
   qp_run_id = _first(st.query_params.get("run_id")) if qp_has_run_id else None
   explicit_nav = qp_has_page or qp_has_sub or qp_has_run_id
   if explicit_nav:
       page = qp_page or "home"
       sub = qp_sub if qp_has_sub else None
       run_id = qp_run_id if qp_has_run_id else None
   else:
       page = st.session_state.get("nav_page", "home") or "home"
       sub = st.session_state.get("nav_sub")
       run_id = st.session_state.get("nav_run_id")
   st.session_state["nav_page"] = page
   st.session_state["nav_sub"] = sub
   st.session_state["nav_run_id"] = run_id
   if page == "home":
       st.session_state["current_page"] = "Home"
       st.session_state["current_flow"] = sub
   else:
       st.session_state["current_page"] = page
       st.session_state["current_flow"] = sub
   _write_navigation_to_query_params(page=page, sub=sub, run_id=run_id)
   persist_persisted_ui_state()
   return page, sub, run_id


def set_navigation_state(page, sub=None, run_id=None):
   st.session_state["nav_page"] = page
   st.session_state["nav_sub"] = sub
   st.session_state["nav_run_id"] = run_id
   if page == "home":
       st.session_state["current_page"] = "Home"
       st.session_state["current_flow"] = sub
   else:
       st.session_state["current_page"] = page
       st.session_state["current_flow"] = sub
   _write_navigation_to_query_params(page=page, sub=sub, run_id=run_id)
   persist_persisted_ui_state()