import json
import re
from datetime import datetime, timezone
from services.run_storage_service import get_current_user_login, get_managed_folder
UI_STATE_ROOT = "ui_state"

def _normalize_path(path: str) -> str:
   return path.lstrip("/") if path else path

def _with_leading_slash(path: str) -> str:
   return f"/{_normalize_path(path)}"

def _candidate_paths(path: str):
   normalized = _normalize_path(path)
   return [normalized, f"/{normalized}"]

def _sanitize_user_id(user_id: str) -> str:
   user_id = str(user_id or "unknown_user").strip().lower()
   user_id = re.sub(r"[^a-z0-9._-]+", "_", user_id)
   return user_id or "unknown_user"

def _state_path(user_id: str) -> str:
   return f"{UI_STATE_ROOT}/{_sanitize_user_id(user_id)}.json"

def _utc_now():
   now = datetime.now(timezone.utc)
   return now.strftime("%Y-%m-%d %H:%M:%S UTC")

def load_ui_state(user_id: str | None = None) -> dict:
   folder = get_managed_folder()
   user_id = user_id or get_current_user_login()
   path = _state_path(user_id)
   for candidate in _candidate_paths(path):
       try:
           details = folder.get_path_details(candidate)
           if details.get("exists", False):
               return folder.read_json(candidate)
       except Exception:
           continue
   return {}

def save_ui_state(payload: dict, user_id: str | None = None) -> dict:
   folder = get_managed_folder()
   user_id = user_id or get_current_user_login()
   state = dict(payload or {})
   state["user_id"] = user_id
   state["updated_at"] = _utc_now()
   folder.write_json(_with_leading_slash(_state_path(user_id)), state)
   return state

def clear_ui_state(user_id: str | None = None):
   folder = get_managed_folder()
   user_id = user_id or get_current_user_login()
   path = _state_path(user_id)
   for candidate in _candidate_paths(path):
       try:
           details = folder.get_path_details(candidate)
           if details.get("exists", False):
               folder.delete_path(candidate)
               return
       except Exception:
           continue
