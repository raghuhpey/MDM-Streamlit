import uuid
from datetime import datetime, timezone
import dataiku
from dataiku import SQLExecutor2

PROJECT_KEY = dataiku.default_project_key()
RETRAINING_DATASET_NAME = "mdm_retraining_jobs_tbl"
RETRAINING_SCENARIO_ID = "RUN_MODEL_RETRAINING"

def _utc_now_str():
   return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def _safe_sql(value):
   if value is None:
       return ""
   return str(value).replace("'", "''")

def _get_sql_dataset_location_for_dataset(dataset_name: str):
   dataset = dataiku.Dataset(dataset_name)
   location_info = dataset.get_location_info(True)
   info = location_info["info"]
   schema_name = info.get("schema")
   table_name = info["table"]
   if schema_name:
       quoted_table_name = f'"{schema_name}"."{table_name}"'
   else:
       quoted_table_name = f'"{table_name}"'
   return {
       "schema": schema_name,
       "table": table_name,
       "quoted_table_name": quoted_table_name,
   }

def _run_sql(sql: str):
   executor = SQLExecutor2(dataset=RETRAINING_DATASET_NAME)
   return executor.query_to_df(sql)

def generate_retraining_job_id(job_name: str = ""):
   ts = datetime.now().strftime("%Y%m%d%H%M%S")
   suffix = uuid.uuid4().hex[:4]
   base = "retrain"
   if job_name:
       job_name_clean = "".join(c if c.isalnum() or c in ("_", "-") else "_" for c in str(job_name).strip())
       job_name_clean = "_".join([x for x in job_name_clean.split("_") if x])[:40]
       if job_name_clean:
           return f"{base}_{job_name_clean}_{ts}_{suffix}"
   return f"{base}_{ts}_{suffix}"

def create_retraining_job(job_name: str = "", created_by: str = "", remarks: str = ""):
   retraining_job_id = generate_retraining_job_id(job_name)
   created_ts = _utc_now_str()
   updated_ts = created_ts
   info = _get_sql_dataset_location_for_dataset(RETRAINING_DATASET_NAME)
   sql = f"""
   INSERT INTO {info['quoted_table_name']} (
       retraining_job_id,
       job_name,
       status,
       created_by,
       created_ts,
       updated_ts,
       scenario_id,
       remarks
   )
   VALUES (
       '{_safe_sql(retraining_job_id)}',
       '{_safe_sql(job_name)}',
       'created',
       '{_safe_sql(created_by)}',
       '{_safe_sql(created_ts)}',
       '{_safe_sql(updated_ts)}',
       '{_safe_sql(RETRAINING_SCENARIO_ID)}',
       '{_safe_sql(remarks)}'
   )
   """
   _run_sql(sql)
   return {
       "retraining_job_id": retraining_job_id,
       "job_name": job_name,
       "status": "created",
       "created_by": created_by,
       "created_ts": created_ts,
       "remarks": remarks,
   }


def trigger_retraining_scenario(retraining_job_id: str):
   client = dataiku.api_client()
   project = client.get_project(PROJECT_KEY)
   scenario = project.get_scenario(RETRAINING_SCENARIO_ID)
   scenario_run = scenario.run(params={"retraining_job_id": retraining_job_id})
   scenario_run_id = getattr(scenario_run, "id", "")
   trigger_id = getattr(scenario_run, "trigger_id", "")
   update_retraining_job_after_submit(
       retraining_job_id=retraining_job_id,
       scenario_run_id=scenario_run_id,
       trigger_id=trigger_id,
   )
   return {
       "scenario_id": RETRAINING_SCENARIO_ID,
       "scenario_run_id": scenario_run_id,
       "trigger_id": trigger_id,
   }

def update_retraining_job_after_submit(retraining_job_id: str, scenario_run_id: str = "", trigger_id: str = ""):
   info = _get_sql_dataset_location_for_dataset(RETRAINING_DATASET_NAME)
   now_str = _utc_now_str()
   sql = f"""
   UPDATE {info['quoted_table_name']}
   SET
       status = 'submitted',
       scenario_run_id = '{_safe_sql(scenario_run_id)}',
       trigger_id = '{_safe_sql(trigger_id)}',
       updated_ts = '{_safe_sql(now_str)}'
   WHERE retraining_job_id = '{_safe_sql(retraining_job_id)}'
   """
   _run_sql(sql)

def update_retraining_job_status(
   retraining_job_id: str,
   status: str,
   started_ts: str = None,
   completed_ts: str = None,
   duration_seconds=None,
   model_version: str = None,
   output_artifact_path: str = None,
   error_message: str = None,
   remarks: str = None,
):
   info = _get_sql_dataset_location_for_dataset(RETRAINING_DATASET_NAME)
   now_str = _utc_now_str()
   updates = [
       f"status = '{_safe_sql(status)}'",
       f"updated_ts = '{_safe_sql(now_str)}'",
   ]
   if started_ts is not None:
       updates.append(f"started_ts = '{_safe_sql(started_ts)}'")
   if completed_ts is not None:
       updates.append(f"completed_ts = '{_safe_sql(completed_ts)}'")
   if duration_seconds is not None:
       updates.append(f"duration_seconds = {float(duration_seconds)}")
   if model_version is not None:
       updates.append(f"model_version = '{_safe_sql(model_version)}'")
   if output_artifact_path is not None:
       updates.append(f"output_artifact_path = '{_safe_sql(output_artifact_path)}'")
   if error_message is not None:
       updates.append(f"error_message = '{_safe_sql(error_message)}'")
   if remarks is not None:
       updates.append(f"remarks = '{_safe_sql(remarks)}'")
   sql = f"""
   UPDATE {info['quoted_table_name']}
   SET {", ".join(updates)}
   WHERE retraining_job_id = '{_safe_sql(retraining_job_id)}'
   """
   _run_sql(sql)

def fetch_retraining_job_metadata(retraining_job_id: str):
   info = _get_sql_dataset_location_for_dataset(RETRAINING_DATASET_NAME)
   sql = f"""
   SELECT *
   FROM {info['quoted_table_name']}
   WHERE retraining_job_id = '{_safe_sql(retraining_job_id)}'
   LIMIT 1
   """
   df = _run_sql(sql)
   if df is None or df.empty:
       return None
   return df.iloc[0].to_dict()

def fetch_retraining_jobs_df():
   info = _get_sql_dataset_location_for_dataset(RETRAINING_DATASET_NAME)
   sql = f"""
   SELECT *
   FROM {info['quoted_table_name']}
   ORDER BY created_ts DESC
   """
   df = _run_sql(sql)
   return df if df is not None else None

def run_retraining_job(retraining_job_id: str):
   """
   Called from the Dataiku retraining scenario.
   Replace the dummy section with your real retraining pipeline / recipe execution.
   """
   started_ts = _utc_now_str()
   update_retraining_job_status(
       retraining_job_id=retraining_job_id,
       status="running",
       started_ts=started_ts,
   )
   started_dt = datetime.now(timezone.utc)
   try:
       # ---------------------------------------------------------
       # TODO: Replace this dummy block with real retraining logic
       # Example:
       #   - run recipe / scenario steps
       #   - train model
       #   - save model artifact
       #   - set model version
       # ---------------------------------------------------------
       model_version = f"v_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
       output_artifact_path = f"/models/{retraining_job_id}/model.pkl"
       remarks = "Retraining completed successfully"
       completed_dt = datetime.now(timezone.utc)
       completed_ts = completed_dt.strftime("%Y-%m-%d %H:%M:%S UTC")
       duration_seconds = (completed_dt - started_dt).total_seconds()
       update_retraining_job_status(
           retraining_job_id=retraining_job_id,
           status="completed",
           completed_ts=completed_ts,
           duration_seconds=duration_seconds,
           model_version=model_version,
           output_artifact_path=output_artifact_path,
           remarks=remarks,
       )
   except Exception as e:
       completed_dt = datetime.now(timezone.utc)
       completed_ts = completed_dt.strftime("%Y-%m-%d %H:%M:%S UTC")
       duration_seconds = (completed_dt - started_dt).total_seconds()
       update_retraining_job_status(
           retraining_job_id=retraining_job_id,
           status="failed",
           completed_ts=completed_ts,
           duration_seconds=duration_seconds,
           error_message=str(e),
       )
       raise