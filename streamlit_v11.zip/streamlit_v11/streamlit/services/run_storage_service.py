import re
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
from uuid import uuid4
import dataiku
import pandas as pd
MANAGED_FOLDER_ID = "MDM_application"
RUNS_ROOT = "runs"
def get_managed_folder():
  return dataiku.Folder(MANAGED_FOLDER_ID)

def get_current_user_login():
  try:
      client = dataiku.api_client()
      auth_info = client.get_auth_info()
      return auth_info.get("authIdentifier", "unknown_user")
  except Exception:
      return "unknown_user"
      
def sanitize_filename(filename: str) -> str:
  base_name = Path(filename).stem.strip()
  sanitized = re.sub(r"[^A-Za-z0-9]+", "_", base_name).strip("_")
  if not sanitized:
      sanitized = "file"
  return sanitized[:80]
def generate_prediction_job_id(uploaded_file_name: str) -> str:
  sanitized = sanitize_filename(uploaded_file_name)
  timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
  suffix = uuid4().hex[:4]
  return f"pred_{sanitized}_{timestamp}_{suffix}"
def normalize_folder_path(path: str) -> str:
  return path.lstrip("/") if path else path
def with_leading_slash(path: str) -> str:
  return f"/{normalize_folder_path(path)}"
def candidate_folder_paths(path: str):
  normalized = normalize_folder_path(path)
  return [normalized, f"/{normalized}"]
def _run_dir(run_id: str) -> str:
  return f"{RUNS_ROOT}/{run_id}"
def _metadata_path(run_id: str) -> str:
  return f"{_run_dir(run_id)}/metadata.json"
def _input_dir(run_id: str) -> str:
  return f"{_run_dir(run_id)}/input"
def _output_dir(run_id: str) -> str:
  return f"{_run_dir(run_id)}/output"
def _input_file_path(run_id: str, original_file_name: str) -> str:
  safe_name = Path(original_file_name).name
  return f"{_input_dir(run_id)}/{safe_name}"
def _input_preview_path(run_id: str) -> str:
  return f"{_input_dir(run_id)}/input_preview.parquet"
def _output_file_path(run_id: str) -> str:
  return f"{_output_dir(run_id)}/prediction_output.parquet"
def _ignored_output_file_path(run_id: str) -> str:
  return f"{_output_dir(run_id)}/ignored_records.csv"
def _utc_now_strings():
  now = datetime.now(timezone.utc)
  return {
      "display": now.strftime("%Y-%m-%d %H:%M:%S UTC"),
      "epoch_ms": int(now.timestamp() * 1000),
  }
def dataframe_to_parquet_bytes(df: pd.DataFrame) -> bytes:
  buffer = BytesIO()
  df.to_parquet(buffer, index=False)
  return buffer.getvalue()
def parquet_bytes_to_dataframe(raw_bytes: bytes) -> pd.DataFrame:
  return pd.read_parquet(BytesIO(raw_bytes))
def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
  buffer = BytesIO()
  df.to_csv(buffer, index=False)
  return buffer.getvalue()
def create_run(
  uploaded_file_name: str,
  file_bytes: bytes,
  input_df: pd.DataFrame,
  run_type: str,
  scenario_id: str | None = None,
):
  folder = get_managed_folder()
  run_id = generate_prediction_job_id(uploaded_file_name)
  created = _utc_now_strings()
  metadata = {
      "prediction_job_id": run_id,
      "run_type": run_type,
      "file_name": Path(uploaded_file_name).name,
      "created_by": get_current_user_login(),
      "created_at": created["display"],
      "created_at_epoch_ms": created["epoch_ms"],
      "updated_at": created["display"],
      "row_count": int(len(input_df)),
      "status": "uploaded",
      "scenario_id": scenario_id,
      "scenario_run_id": None,
      "backend_job_id": None,
      "error_message": None,
      "file_size_bytes": int(len(file_bytes)),
      "input_file_path": _input_file_path(run_id, uploaded_file_name),
      "input_preview_path": _input_preview_path(run_id),
      "output_file_path": _output_file_path(run_id),
  }
  folder.upload_data(with_leading_slash(metadata["input_file_path"]), file_bytes)
  folder.upload_data(
      with_leading_slash(metadata["input_preview_path"]),
      dataframe_to_parquet_bytes(input_df)
  )
  folder.write_json(with_leading_slash(_metadata_path(run_id)), metadata)
  return metadata
def load_run_metadata(run_id: str):
  folder = get_managed_folder()
  target_path = _metadata_path(run_id)
  for candidate in candidate_folder_paths(target_path):
      try:
          details = folder.get_path_details(candidate)
          if details.get("exists", False):
              return folder.read_json(candidate)
      except Exception:
          continue
  return None
def update_run_metadata(run_id: str, updates: dict):
  folder = get_managed_folder()
  metadata = load_run_metadata(run_id)
  if metadata is None:
      raise ValueError(f"Run metadata not found for run_id={run_id}")
  metadata.update(updates)
  updated = _utc_now_strings()
  metadata["updated_at"] = updated["display"]
  metadata["updated_at_epoch_ms"] = updated["epoch_ms"]
  folder.write_json(with_leading_slash(_metadata_path(run_id)), metadata)
  return metadata
def list_runs(created_by: str | None = None, run_type: str | None = None):
  folder = get_managed_folder()
  try:
      all_paths = folder.list_paths_in_partition()
  except Exception as e:
      print("ERROR LISTING MANAGED FOLDER PATHS:", e)
      return []
  normalized_paths = [normalize_folder_path(p) for p in all_paths]
  metadata_paths = [
      p for p in normalized_paths
      if p.startswith(f"{RUNS_ROOT}/") and p.endswith("/metadata.json")
  ]
  print("ALL PATHS:", all_paths)
  print("NORMALIZED PATHS:", normalized_paths)
  print("METADATA PATHS:", metadata_paths)
  runs = []
  for path in metadata_paths:
      for candidate in candidate_folder_paths(path):
          try:
              run_meta = folder.read_json(candidate)
              if created_by and run_meta.get("created_by") != created_by:
                  break
              if run_type and run_meta.get("run_type") != run_type:
                  break
              runs.append(run_meta)
              break
          except Exception as e:
              print("FAILED TO READ METADATA:", candidate, e)
  runs.sort(
      key=lambda x: x.get("created_at_epoch_ms", 0),
      reverse=True
  )
  return runs
def load_input_preview_df(run_id: str):
  folder = get_managed_folder()
  metadata = load_run_metadata(run_id)
  if metadata is None:
      return None
  path = metadata.get("input_preview_path")
  if not path:
      return None
  for candidate in candidate_folder_paths(path):
      try:
          details = folder.get_path_details(candidate)
          if details.get("exists", False):
              with folder.get_download_stream(candidate) as stream:
                  return parquet_bytes_to_dataframe(stream.read())
      except Exception:
          continue
  return None
def load_output_df(run_id: str):
  folder = get_managed_folder()
  metadata = load_run_metadata(run_id)
  if metadata is None:
      return None
  path = metadata.get("output_file_path")
  if not path:
      return None
  for candidate in candidate_folder_paths(path):
      try:
          details = folder.get_path_details(candidate)
          if details.get("exists", False):
              with folder.get_download_stream(candidate) as stream:
                  return parquet_bytes_to_dataframe(stream.read())
      except Exception:
          continue
  return None
def delete_run(run_id: str):
  folder = get_managed_folder()
  folder.delete_path(with_leading_slash(_run_dir(run_id)))
def save_prediction_output_df(run_id: str, result_df: pd.DataFrame) -> str:
  folder = get_managed_folder()
  path = _output_file_path(run_id)
  folder.upload_data(with_leading_slash(path), dataframe_to_parquet_bytes(result_df))
  return with_leading_slash(path)

def save_ignored_records_csv(run_id: str, ignored_df: pd.DataFrame | None) -> str:
  folder = get_managed_folder()
  path = _ignored_output_file_path(run_id)
  payload_df = ignored_df.copy() if ignored_df is not None else pd.DataFrame()
  folder.upload_data(with_leading_slash(path), dataframe_to_csv_bytes(payload_df))
  return with_leading_slash(path)