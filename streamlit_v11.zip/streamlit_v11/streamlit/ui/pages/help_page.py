import streamlit as st

from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css


# def render():
#    load_css(get_global_css() + get_app_shell_css())
#    render_sidebar(subtitle="Help")
#    render_top_nav(active_slug="help")
#    st.title("Help")
#    st.write("This page contains user guidance and FAQs.")


from pathlib import Path
import fitz  # PyMuPDF
import streamlit as st

PDF_PATH = Path(__file__).resolve().parents[2] / "assets" / "App_User_Guide.pdf"

@st.cache_data(show_spinner=False)
def _load_pdf_as_images(pdf_path_str: str, zoom: float = 1.4):
   pdf_path = Path(pdf_path_str)
   if not pdf_path.exists():
       return None
   doc = fitz.open(pdf_path)
   pages = []
   for page_num in range(len(doc)):
       page = doc.load_page(page_num)
       mat = fitz.Matrix(zoom, zoom)
       pix = page.get_pixmap(matrix=mat, alpha=False)
       pages.append(pix.tobytes("png"))
   doc.close()
   return pages

def render():
   load_css(get_global_css() + get_app_shell_css())
   render_sidebar(subtitle="Help")
   render_top_nav(active_slug="help")
   st.markdown("## 1. Quick Start")
   st.markdown(
       """
<div class="section-card">
<div style="line-height:1.9; color:#374151; font-size:15px;">
<b>Step 1:</b> Go to <b>Classify Existing Parts</b><br>
<b>Step 2:</b> Enter a run name<br>
<b>Step 3:</b> Upload the input file<br>
<b>Step 4:</b> Click <b>Create Run</b><br>
<b>Step 5:</b> Submit the run for classification<br>
<b>Step 6:</b> Track the run in the <b>Runs</b> page<br>
<b>Step 7:</b> Review and approve records in <b>To Validate</b><br>
<b>Step 8:</b> View approved rows in <b>Validated Parts Data</b>
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("*******************************************")
   st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
   st.markdown("## 2. User Guide")
   with st.expander("Open User Guide document", expanded=False):
       pdf_pages = _load_pdf_as_images(str(PDF_PATH), zoom=1.4)
       if not pdf_pages:
           st.warning(f"Help guide PDF not found at: {PDF_PATH}")
       else:
           for i, page_img in enumerate(pdf_pages, start=1):
               st.markdown(f"**Page {i}**")
               st.image(page_img, use_container_width=True)
               st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   st.markdown("*******************************************") 
   st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)

   st.markdown("## 3. FAQ")
   with st.expander("What file types are supported?", expanded=False):
       st.write("You can upload CSV and Excel files.")
   with st.expander("Why am I getting a mandatory columns error?", expanded=False):
       st.write("The uploaded file is missing one or more required columns needed for classification.")
   with st.expander("Where can I see my run status?", expanded=False):
       st.write("Go to the Runs page to check whether the run is uploaded, submitted, running, completed, or failed.")
   with st.expander("Where do approved rows appear?", expanded=False):
       st.write("Approved rows are available in the Validated Parts Data section.")
   with st.expander("Can I edit an approved row?", expanded=False):
       st.write("Yes. Approved rows can be edited from the validation view if edit is enabled.")
   st.markdown("*******************************************")
   
   st.markdown("## 4. Contact / Support")
   st.markdown(
       """
<div class="section-card">
<div style="line-height:1.9; color:#374151; font-size:15px;">
               For support during UAT, please contact:<br>
<b>EY Team:</b> MDM Parts Classification Team<br>
<b>Alstom Team:</b> kiran.hassan-yogaraja@alstomgroup.com<br>
</div>
</div>
       """,
       unsafe_allow_html=True,
   )