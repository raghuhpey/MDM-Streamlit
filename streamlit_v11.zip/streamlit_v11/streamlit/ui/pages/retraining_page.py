import streamlit as st
from services.retraining_service import (
   create_retraining_job,
   trigger_retraining_scenario,
   fetch_retraining_jobs_df,
)
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def _get_latest_retraining_summary():
   df = fetch_retraining_jobs_df()
   if df is None or df.empty:
       return {
           "total_jobs": 0,
           "running_jobs": 0,
           "last_job_id": "-",
           "last_status": "-",
           "last_created_ts": "-",
       }
   work_df = df.copy()
   if "status" in work_df.columns:
       running_jobs = int(
           work_df["status"]
           .astype(str)
           .str.strip()
           .str.lower()
           .isin(["created", "submitted", "running"])
           .sum()
       )
   else:
       running_jobs = 0
   latest_row = work_df.iloc[0].to_dict()
   return {
       "total_jobs": len(work_df),
       "running_jobs": running_jobs,
       "last_job_id": latest_row.get("retraining_job_id", "-"),
       "last_status": latest_row.get("status", "-"),
       "last_created_ts": latest_row.get("created_ts", "-"),
   }

def render():
   load_css(
       get_global_css()
       + get_app_shell_css()
       + get_home_page_css()
       + get_classify_page_css()
   )
   render_sidebar(subtitle="Admin")
   render_top_nav(active_slug="admin")
   summary = _get_latest_retraining_summary()
   top_cols = st.columns([1, 6, 1])
   with top_cols[0]:
       if st.button("← Back", key="retraining_back_btn", use_container_width=True):
           st.query_params["page"] = "admin"
           st.rerun()
   st.markdown(
       """
<div class="section-card" style="margin-top:18px;">
<div class="section-card-title">Model Retraining</div>
<div class="section-card-subtitle">
               Trigger a new model retraining pipeline using the latest approved records.
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
#    st.markdown(
#        """
# <div class="section-card">
# <div class="section-card-title" style="font-size:18px;">Overview</div>
# <div class="section-card-subtitle" style="line-height:1.9;">
#                This action starts a backend retraining pipeline. The pipeline is expected to use the latest
#                approved / golden data, create a new model version, and update the retraining job status as it runs.
#                You can track progress in the <b>Retraining Jobs</b> page.
# </div>
# </div>
#        """,
#        unsafe_allow_html=True,
#    )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   stat1, stat2, stat3 = st.columns(3, gap="large")
   with stat1:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Total Jobs</div>
<div style="font-size:28px; font-weight:800; color:#0f172a; margin-top:6px;">
                   {summary["total_jobs"]}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   with stat2:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Running Jobs</div>
<div style="font-size:28px; font-weight:800; color:#0f172a; margin-top:6px;">
                   {summary["running_jobs"]}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   with stat3:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Last Job Status</div>
<div style="font-size:20px; font-weight:800; color:#0f172a; margin-top:10px;">
                   {summary["last_status"]}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   with st.container():
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title" style="font-size:18px;">Retraining Inputs</div>
<div class="section-card-subtitle">
                   Provide a job name and optional notes before triggering retraining.
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
       st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
       input_col1, input_col2 = st.columns(2, gap="large")
       with input_col1:
           job_name = st.text_input(
               "Retraining Job Name",
               key="retraining_job_name_input",
               placeholder="Enter a meaningful retraining job name",
           )
           triggered_by = st.text_input(
               "Triggered By",
               key="retraining_triggered_by_input",
               placeholder="Enter user id / email / name",
           )
       with input_col2:
           remarks = st.text_area(
               "Remarks / Notes",
               key="retraining_remarks_input",
               placeholder="Optional notes for this retraining run",
               height=132,
           )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   st.markdown(
       f"""
<div class="section-card">
<div class="section-card-title" style="font-size:18px;">Pre-check Summary</div>
<div class="section-card-subtitle" style="line-height:1.9;">
<b>Latest Retraining Job ID:</b> {summary["last_job_id"]}<br>
<b>Latest Job Created On:</b> {summary["last_created_ts"]}<br>
<b>Currently Active Jobs:</b> {summary["running_jobs"]}
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)
   action_cols = st.columns([1, 1, 4])
   with action_cols[0]:
       start_clicked = st.button(
           "Start Retraining",
           key="start_retraining_pipeline_btn",
           use_container_width=True,
       )
   with action_cols[1]:
       view_jobs_clicked = st.button(
           "View Jobs",
           key="view_retraining_jobs_btn",
           use_container_width=True,
       )
   if view_jobs_clicked:
       st.query_params["page"] = "retraining_jobs"
       st.rerun()
   if start_clicked:
       try:
           clean_job_name = str(job_name or "").strip()
           clean_triggered_by = str(triggered_by or "").strip()
           clean_remarks = str(remarks or "").strip()
           if not clean_job_name:
               st.warning("Please enter a retraining job name.")
               return
           if summary["running_jobs"] > 0:
               st.warning("Another retraining job is already active. Please wait for it to finish before starting a new one.")
               return
           created_job = create_retraining_job(
               job_name=clean_job_name,
               created_by=clean_triggered_by,
               remarks=clean_remarks,
           )
           trigger_result = trigger_retraining_scenario(created_job["retraining_job_id"])
           st.success(
               f"Retraining job started successfully. "
               f"Job ID: {created_job['retraining_job_id']}"
           )
           st.session_state["latest_retraining_job_id"] = created_job["retraining_job_id"]
           st.session_state["latest_retraining_scenario_run_id"] = trigger_result.get("scenario_run_id", "")
           st.query_params["page"] = "retraining_jobs"
           st.rerun()
       except Exception as e:
           st.error(f"Failed to start retraining: {e}")