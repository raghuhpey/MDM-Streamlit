import base64
import math
import streamlit as st
import pandas as pd
from services.run_report_service import fetch_run_report_df
from services.user_access_admin_service import (
   fetch_user_access_audit_df,
   fetch_user_access_df,
   upsert_user_access_role_record,
)
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def get_base64_image(image_path: str) -> str:
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label: str, slug: str, active: bool = False) -> str:
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def left_menu_btn(label: str, sub_value: str, active: bool = False) -> str:
   css_class = "left-menu-btn active" if active else "left-menu-btn"
   return f"""
<form method="get" class="left-menu-form">
<input type="hidden" name="page" value="super_admin">
<input type="hidden" name="sub" value="{sub_value}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def get_selected_submenu():
   selected = st.query_params.get("sub", "user_access")
   if isinstance(selected, list):
       selected = selected[0]
   if selected not in {"user_access", "audit_log", "run_report"}:
       selected = "user_access"
   return selected

def _super_admin_css():
   return """
<style>
   .sa-metrics-grid {
   display: grid;
   grid-template-columns: repeat(5, minmax(0, 1fr));
   gap: 14px;
   margin: 18px 0 22px 0;
    }
   .sa-metric-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    padding: 16px 18px;
    box-shadow: 0 4px 14px rgba(15, 23, 42, 0.04);
    }
   .sa-metric-label {
    font-size: 12px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    color: #64748b;
    margin-bottom: 8px;
    }
   .sa-metric-value {
    font-size: 24px;
    font-weight: 800;
    color: #111827;
    }
   .sa-report-filter-card {
    background: #ffffff;
    border: 1px solid #e5e7eb;
    border-radius: 18px;
    padding: 18px 20px;
    margin-bottom: 18px;
    }

   .sa-shell-card {
       background: #ffffff;
       border: 1px solid #e6e8ef;
       border-radius: 22px;
       padding: 0;
       overflow: hidden;
       box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
   }
   .sa-hero {
       background: #0f4f70;
       border-radius: 22px;
       padding: 8px 34px;
       display: flex;
       justify-content: space-between;
       align-items: center;
       margin-bottom: 22px;
       color: #ffffff;
   }
   .sa-hero-kicker {
       font-size: 12px;
       font-weight: 800;
       letter-spacing: 0.16em;
       color: #f7a7a7;
       text-transform: uppercase;
       margin-bottom: 10px;
   }
   .sa-hero-title {
       font-size: 28px;
       font-weight: 800;
       line-height: 1.2;
       margin-bottom: 8px;
   }
   .sa-hero-subtitle {
       font-size: 15px;
       color: rgba(255,255,255,0.82);
   }
   .sa-hero-count {
       text-align: center;
       min-width: 110px;
   }
   .sa-hero-count-number {
       font-size: 38px;
       font-weight: 800;
       line-height: 1;
       margin-bottom: 6px;
   }
   .sa-hero-count-label {
       font-size: 14px;
       color: rgba(255,255,255,0.76);
   }
   .sa-toolbar {
       display: grid;
       grid-template-columns: 1fr 180px;
       gap: 18px;
       margin-bottom: 26px;
   }
   .sa-search-card {
       background: #f8f8fc;
       border: 1px solid #ececf4;
       border-radius: 16px;
       padding: 14px 18px;
   }
   .sa-add-card {
       background: #ffffff;
       border: 1px solid #ffffff;
       border-radius: 16px;
       padding: 10px 12px;
   }
   .sa-grid-header {
       display: grid;
       grid-template-columns: 2.4fr 1.3fr 1.3fr 1.3fr 1.7fr 1.1fr;
       gap: 14px;
       padding: 10px 6px 12px 6px;
       margin-bottom: 8px;
   }
   .sa-grid-header div {
       font-size: 12px;
       font-weight: 800;
       letter-spacing: 0.12em;
       text-transform: uppercase;
       color: #111827;
   }
   .sa-row {
       display: grid;
       grid-template-columns: 2.4fr 1.3fr 1.3fr 1.3fr 1.7fr 1.1fr;
       gap: 14px;
       align-items: center;
       padding: 16px 6px;
       border-bottom: 1px solid #eef1f6;
   }
   .sa-user-cell {
       display: flex;
       align-items: center;
       gap: 14px;
       min-width: 0;
   }
   .sa-avatar {
       width: 42px;
       height: 42px;
       border-radius: 999px;
       display: flex;
       align-items: center;
       justify-content: center;
       font-size: 13px;
       font-weight: 800;
       color: #ffffff;
       flex-shrink: 0;
   }
   .sa-user-meta {
       min-width: 0;
   }
   .sa-user-name {
       font-size: 18px;
       font-weight: 700;
       color: #111827;
       line-height: 1.2;
       white-space: nowrap;
       overflow: hidden;
       text-overflow: ellipsis;
   }
   .sa-user-sub {
       font-size: 13px;
       color: #6b7280;
       margin-top: 4px;
       white-space: nowrap;
       overflow: hidden;
       text-overflow: ellipsis;
   }
   .sa-muted-text {
       font-size: 15px;
       color: #4b5563;
       line-height: 1.4;
   }
   .sa-empty {
       background: #ffffff;
       border: 1px dashed #d1d5db;
       border-radius: 18px;
       padding: 36px 24px;
       text-align: center;
       color: #6b7280;
       font-size: 15px;
   }
   .sa-pagination {
       display: grid;
       grid-template-columns: 220px 1fr 220px;
       gap: 18px;
       align-items: center;
       margin-top: 26px;
   }
   .sa-pagination-center {
       text-align: center;
       color: #6b7280;
       font-size: 14px;
       font-weight: 600;
   }
   .sa-form-note {
       background: #fff7ed;
       border: 1px solid #fed7aa;
       color: #9a3412;
       border-radius: 14px;
       padding: 12px 14px;
       font-size: 13px;
       line-height: 1.6;
       margin-bottom: 18px;
   }
   .sa-audit-card {
       background: #ffffff;
       border: 1px solid #e5e7eb;
       border-radius: 18px;
       padding: 18px 20px;
   }
   .sa-audit-title {
       font-size: 24px;
       font-weight: 800;
       color: #111827;
       margin-bottom: 6px;
   }
   .sa-audit-subtitle {
       font-size: 14px;
       color: #64748b;
       margin-bottom: 14px;
   }
   .stButton > button {
       border-radius: 14px !important;
       min-height: 46px !important;
       font-weight: 700 !important;
   }
   div[data-testid="stTextInput"] input {
       font-size: 15px !important;
   }
   div[data-testid="stSelectbox"] > div {
       border-radius: 12px !important;
   }
</style>
   """

def _avatar_color(index: int) -> str:
   colors = ["#ef4444", "#1e3a5f", "#2563eb", "#9333ea", "#0f766e", "#f59e0b"]
   return colors[index % len(colors)]

def _initials(user_id: str) -> str:
   cleaned = "".join([c for c in str(user_id).strip() if c.isalnum()])
   if not cleaned:
       return "NA"
   return cleaned[:2].upper()

def render_user_access_view():
   access_df = fetch_user_access_df()
   search_term = st.session_state.get("sa_search_term", "")
   show_add_form = st.session_state.get("sa_show_add_form", False)
   total_members = 0 if access_df.empty else len(access_df)
   st.markdown(
       f"""
<div class="sa-hero">
<div>
<div class="sa-hero-title">Team Configuration</div>
<div class="sa-hero-subtitle">Manage team members, roles, and access.</div>
</div>
<div class="sa-hero-count">
<div class="sa-hero-count-number">{total_members}</div>
<div class="sa-hero-count-label">Members</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   toolbar_cols = st.columns([5.2, 1.2], gap="medium")
   with toolbar_cols[0]:
    #    st.markdown('<div class="sa-search-card">', unsafe_allow_html=True)
       search_value = st.text_input(
           "Search",
           value=search_term,
           key="sa_search_term",
           placeholder="🔍  Search by user id..."
       )
       st.markdown('</div>', unsafe_allow_html=True)
   with toolbar_cols[1]:
       st.markdown('<div class="sa-add-card">', unsafe_allow_html=True)
       if st.button("+ Add", key="sa_add_member_btn", use_container_width=True):
           st.session_state["sa_show_add_form"] = not show_add_form
           st.rerun()
       st.markdown('</div>', unsafe_allow_html=True)
   st.markdown("***")
   if st.session_state.get("sa_show_add_form", False):
       st.markdown('<div class="sa-form-note">Add a new user by assigning one role and a status. Role rules are fixed: User → only classify, Admin → all except super admin, Super Admin → full access.</div>', unsafe_allow_html=True)
       with st.form("sa_add_user_form", clear_on_submit=True):
           form_cols = st.columns([2.4, 1.6, 1.4, 1.2], gap="medium")
           with form_cols[0]:
               new_user_id = st.text_input("User ID", placeholder="Enter Dataiku user ID")
           with form_cols[1]:
               new_role = st.selectbox("Role", ["user", "admin", "super_admin"])
           with form_cols[2]:
               new_status = st.selectbox("Status", ["Active", "Inactive"])
           with form_cols[3]:
               st.markdown("<div style='height:29px;'></div>", unsafe_allow_html=True)
               submitted = st.form_submit_button("Save", use_container_width=True)
           if submitted:
               try:
                   upsert_user_access_role_record(
                       user_id=new_user_id,
                       role=new_role,
                       is_active=(new_status == "Active"),
                   )
                   st.success(f"User saved: {new_user_id}")
                   st.session_state["sa_show_add_form"] = False
                   st.rerun()
               except Exception as e:
                   st.error(f"Failed to save user: {e}")
   display_df = access_df.copy()
   if search_value:
       search_norm = str(search_value).strip().lower()
       display_df = display_df[
           display_df["user_id"].astype(str).str.lower().str.contains(search_norm, na=False)
       ].copy()
   page_size = 5
   page_key = "sa_user_page"
   if page_key not in st.session_state:
       st.session_state[page_key] = 1
   total_rows = len(display_df)
   total_pages = max(1, math.ceil(total_rows / page_size))
   current_page = max(1, min(st.session_state[page_key], total_pages))
   st.session_state[page_key] = current_page
   start_idx = (current_page - 1) * page_size
   end_idx = min(start_idx + page_size, total_rows)
   page_df = display_df.iloc[start_idx:end_idx].copy().reset_index(drop=True)
   if page_df.empty:
       st.markdown(
           '<div class="sa-empty">No team members found for the current search.</div>',
           unsafe_allow_html=True
       )
   else:
       st.markdown(
           """
<div class="sa-grid-header">
<div>User</div>
<div>Role</div>
<div>Status</div>
<div>Updated By</div>
<div>Updated At</div>
<div>Action</div>
</div>
           """,
           unsafe_allow_html=True
       )
       for idx, row in page_df.iterrows():
           user_id = str(row["user_id"]).strip()
           role_key = f"sa_role_{user_id}"
           status_key = f"sa_status_{user_id}"
           row_cols = st.columns([2.4, 1.3, 1.3, 1.3, 1.7, 1.1], gap="medium")
           with row_cols[0]:
               avatar_color = _avatar_color(start_idx + idx)
               st.markdown(
                   f"""
<div class="sa-user-cell">
<div class="sa-avatar" style="background:{avatar_color};">{_initials(user_id)}</div>
<div class="sa-user-meta">
<div class="sa-user-name">{user_id}</div>
<div class="sa-user-sub">Team member access configuration</div>
</div>
</div>
                   """,
                   unsafe_allow_html=True
               )
           with row_cols[1]:
               role_value = st.selectbox(
                   "Role",
                   ["user", "admin", "super_admin"],
                   index=["user", "admin", "super_admin"].index(str(row["role"]).strip().lower()),
                   key=role_key,
                   label_visibility="collapsed"
               )
           with row_cols[2]:
               status_value = st.selectbox(
                   "Status",
                   ["Active", "Inactive"],
                   index=0 if bool(row["is_active"]) else 1,
                   key=status_key,
                   label_visibility="collapsed"
               )
           with row_cols[3]:
               st.markdown(
                   f'<div class="sa-muted-text">{str(row.get("updated_by", "") or "-")}</div>',
                   unsafe_allow_html=True
               )
           with row_cols[4]:
               st.markdown(
                   f'<div class="sa-muted-text">{str(row.get("updated_at", "") or "-")}</div>',
                   unsafe_allow_html=True
               )
           with row_cols[5]:
               if st.button("Save", key=f"sa_save_{user_id}", use_container_width=True):
                   try:
                       upsert_user_access_role_record(
                           user_id=user_id,
                           role=role_value,
                           is_active=(status_value == "Active"),
                       )
                       st.success(f"Updated: {user_id}")
                       st.rerun()
                   except Exception as e:
                       st.error(f"Failed to update {user_id}: {e}")
   st.markdown("***")                    
   pag_cols = st.columns([1.4, 2.0, 1.4], gap="medium")
   with pag_cols[0]:
       if st.button("← Prev", key="sa_prev_page", disabled=(current_page == 1), use_container_width=True):
           st.session_state[page_key] = current_page - 1
           st.rerun()
   with pag_cols[1]:
       st.markdown(
           f'<div class="sa-pagination-center">Showing {0 if total_rows == 0 else start_idx + 1}-{end_idx} of {total_rows} members &nbsp;&nbsp; Page {current_page} / {total_pages}</div>',
           unsafe_allow_html=True
       )
   with pag_cols[2]:
       if st.button("Next →", key="sa_next_page", disabled=(current_page == total_pages), use_container_width=True):
           st.session_state[page_key] = current_page + 1
           st.rerun()

def render_audit_log_view():
   audit_df = fetch_user_access_audit_df()
   st.markdown(
       f"""
<div class="sa-hero">
<div>
<div class="sa-hero-kicker">Administration</div>
<div class="sa-hero-title">Access Audit Log</div>
<div class="sa-hero-subtitle">History of role and status changes made by Super Admin users.</div>
</div>
<div class="sa-hero-count">
<div class="sa-hero-count-number">{len(audit_df)}</div>
<div class="sa-hero-count-label">Events</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if audit_df.empty:
       st.markdown(
           '<div class="sa-empty">No audit records available.</div>',
           unsafe_allow_html=True
       )
       return
   page_size = 8
   page_key = "sa_audit_page"
   if page_key not in st.session_state:
       st.session_state[page_key] = 1
   total_rows = len(audit_df)
   total_pages = max(1, math.ceil(total_rows / page_size))
   current_page = max(1, min(st.session_state[page_key], total_pages))
   st.session_state[page_key] = current_page
   start_idx = (current_page - 1) * page_size
   end_idx = min(start_idx + page_size, total_rows)
   page_df = audit_df.iloc[start_idx:end_idx].copy().reset_index(drop=True)
   st.markdown(
       """
<div class="sa-grid-header" style="grid-template-columns: 1.4fr 1.1fr 1.1fr 1.1fr 1fr 1.4fr;">
<div>User</div>
<div>Action</div>
<div>Old Role</div>
<div>New Role</div>
<div>Changed By</div>
<div>Changed At</div>
</div>
       """,
       unsafe_allow_html=True
   )
   for _, row in page_df.iterrows():
       row_cols = st.columns([1.4, 1.1, 1.1, 1.1, 1.0, 1.4], gap="medium")
       with row_cols[0]:
           st.markdown(
               f'<div class="sa-muted-text">{row["user_id"]}</div>',
               unsafe_allow_html=True
           )
       with row_cols[1]:
           st.markdown(
               f'<div class="sa-muted-text">{row["action_type"]}</div>',
               unsafe_allow_html=True
           )
       with row_cols[2]:
           st.markdown(
               f'<div class="sa-muted-text">{row["old_role"]}</div>',
               unsafe_allow_html=True
           )
       with row_cols[3]:
           st.markdown(
               f'<div class="sa-muted-text">{row["new_role"]}</div>',
               unsafe_allow_html=True
           )
       with row_cols[4]:
           st.markdown(
               f'<div class="sa-muted-text">{row["changed_by"]}</div>',
               unsafe_allow_html=True
           )
       with row_cols[5]:
           st.markdown(
               f'<div class="sa-muted-text">{row["changed_at"]}</div>',
               unsafe_allow_html=True
           )
       st.markdown("<hr style='border:none; border-top:1px solid #eef1f6; margin:10px 0 6px 0;'>", unsafe_allow_html=True)
   pag_cols = st.columns([1.4, 2.0, 1.4], gap="medium")
   with pag_cols[0]:
       if st.button("← Prev", key="sa_audit_prev_page", disabled=(current_page == 1), use_container_width=True):
           st.session_state[page_key] = current_page - 1
           st.rerun()
   with pag_cols[1]:
       st.markdown(
           f'<div class="sa-pagination-center">Showing {start_idx + 1}-{end_idx} of {total_rows} audit events &nbsp;&nbsp; Page {current_page} / {total_pages}</div>',
           unsafe_allow_html=True
       )
   with pag_cols[2]:
       if st.button("Next →", key="sa_audit_next_page", disabled=(current_page == total_pages), use_container_width=True):
           st.session_state[page_key] = current_page + 1
           st.rerun()

def render_run_report_view():
   report_df = fetch_run_report_df()
   total_runs = report_df["Run ID"].nunique() if not report_df.empty else 0
   total_records = len(report_df)
   approved_rows = int((report_df["Validation Status"] == "approved").sum()) if not report_df.empty else 0
   pending_rows = total_records - approved_rows
   unique_validators = (
       report_df["Validated By"]
       .replace("", pd.NA)
       .dropna()
       .nunique()
       if not report_df.empty else 0
   )
   approval_rate = round((approved_rows / total_records) * 100, 1) if total_records else 0.0
   st.markdown(
       f"""
<div class="sa-hero">
<div>
<div class="sa-hero-kicker">Administration</div>
<div class="sa-hero-title">Run Report</div>
<div class="sa-hero-subtitle">Detailed row-level validation reporting across all classification runs.</div>
</div>
<div class="sa-hero-count">
<div class="sa-hero-count-number">{total_runs}</div>
<div class="sa-hero-count-label">Runs</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   st.markdown(
       f"""
<div class="sa-metrics-grid">
<div class="sa-metric-card">
<div class="sa-metric-label">Total Runs</div>
<div class="sa-metric-value">{total_runs}</div>
</div>
<div class="sa-metric-card">
<div class="sa-metric-label">Total Records</div>
<div class="sa-metric-value">{total_records}</div>
</div>
<div class="sa-metric-card">
<div class="sa-metric-label">Approved Rows</div>
<div class="sa-metric-value">{approved_rows}</div>
</div>
<div class="sa-metric-card">
<div class="sa-metric-label">Pending Rows</div>
<div class="sa-metric-value">{pending_rows}</div>
</div>
<div class="sa-metric-card">
<div class="sa-metric-label">Approval Rate</div>
<div class="sa-metric-value">{approval_rate}%</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if report_df.empty:
       st.markdown(
           '<div class="sa-empty">No run report data available.</div>',
           unsafe_allow_html=True
       )
       return
#    st.markdown('<div class="sa-report-filter-card">', unsafe_allow_html=True)
   filter_cols = st.columns([1.3, 1.3, 1.4, 1.2, 1.2], gap="medium")
#    st.markdown('<div class="sa-report-filter-card">', unsafe_allow_html=True)
   st.divider()
   filter_cols = st.columns([1.4, 1.4, 1.2, 1.2], gap="medium")
   run_id_options = ["All"] + sorted(
    [v for v in report_df["Run ID"].dropna().astype(str).unique().tolist() if v.strip()]
    )
   file_name_options = ["All"] + sorted(
    [v for v in report_df["File Name"].dropna().astype(str).unique().tolist() if v.strip()]
    )
   status_options = sorted(
    [v for v in report_df["Validation Status"].dropna().astype(str).unique().tolist() if v.strip()]
    )
   validator_options = sorted(
    [v for v in report_df["Validated By"].dropna().astype(str).unique().tolist() if v.strip()]
    )
   with filter_cols[0]:
    run_filter = st.selectbox(
        "Run ID",
        options=run_id_options,
        index=0,
        key="run_report_run_id_filter"
        )
   with filter_cols[1]:
    file_filter = st.selectbox(
        "File Name",
        options=file_name_options,
        index=0,
        key="run_report_file_filter"
        )
   with filter_cols[2]:
    status_filter = st.multiselect(
        "Validation Status",
        status_options,
        key="run_report_status_filter"
        )
   with filter_cols[3]:
    validator_filter = st.multiselect(
        "Validated By",
        validator_options,
        key="run_report_validator_filter"
        )
   st.markdown('</div>', unsafe_allow_html=True)
   filtered_df = report_df.copy()
   if run_filter != "All":
    filtered_df = filtered_df[
        filtered_df["Run ID"].astype(str) == str(run_filter)
        ]
   if file_filter != "All":
    filtered_df = filtered_df[
        filtered_df["File Name"].astype(str) == str(file_filter)
        ]
   if status_filter:
    filtered_df = filtered_df[filtered_df["Validation Status"].isin(status_filter)]
   if validator_filter:
    filtered_df = filtered_df[filtered_df["Validated By"].isin(validator_filter)]
   st.dataframe(filtered_df, use_container_width=True, hide_index=True)

# def render():
#    load_css(get_global_css() + get_app_shell_css() + get_home_page_css() + get_classify_page_css() + _super_admin_css())
#    selected_menu = get_selected_submenu()

#    render_sidebar(
#        subtitle="Governance Console",
#        section_label="Section",
#        menu_items=[
#            {"label": "User Access", "page": "super_admin", "sub": "user_access", "active": selected_menu == "user_access"},
#            {"label": "Audit Log", "page": "super_admin", "sub": "audit_log", "active": selected_menu == "audit_log"},
#            {"label": "Run Report", "page": "super_admin", "sub": "run_report", "active": selected_menu == "run_report"},
#        ],
#    )
#    render_top_nav(active_slug="super_admin")

#    if selected_menu == "audit_log":
#        render_audit_log_view()
#    elif selected_menu == "run_report":
#        render_run_report_view()
#    else:
#        render_user_access_view()


def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css() + get_classify_page_css() + _super_admin_css())
   selected_menu = get_selected_submenu()

#    render_sidebar(
#        subtitle="Governance Console",
#        section_label="Section",
#        menu_items=[
#            {"label": "User Access", "page": "super_admin", "sub": "user_access", "active": selected_menu == "user_access"},
#            {"label": "Audit Log", "page": "super_admin", "sub": "audit_log", "active": selected_menu == "audit_log"},
#            {"label": "Run Report", "page": "super_admin", "sub": "run_report", "active": selected_menu == "run_report"},
#        ],
#    )
   render_top_nav(active_slug="super_admin")

   if selected_menu == "audit_log":
       st.markdown(
       """
<div class="empty-state-box">
       ************************************* Access to super Admin is restricted ************************************************
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   elif selected_menu == "run_report":
       st.markdown(
       """
<div class="empty-state-box">
       ************************************* Access to super Admin is restricted ************************************************
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   else:
       st.markdown(
       """
<div class="empty-state-box">
       ************************************* Access to super Admin is restricted ************************************************
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
