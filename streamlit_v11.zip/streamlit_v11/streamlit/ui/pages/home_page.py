from html import escape
from urllib.parse import urlencode
import streamlit as st
from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css, get_home_page_css

def _home_option_card(title, subtitle, page, sub=None, icon="📦"):
   params = {"page": page}
   if sub is not None:
       params["sub"] = sub
   href = f"?{urlencode(params)}"
   return f"""
<a href="{href}" target="_self" class="home-v2-card">
<div class="home-v2-card-left">
<div class="home-v2-card-icon">{escape(icon)}</div>
<div class="home-v2-card-copy">
<div class="home-v2-card-title">{escape(title)}</div>
<div class="home-v2-card-subtitle">{escape(subtitle)}</div>
</div>
</div>
<div class="home-v2-card-arrow">➜</div>
</a>
   """

def _build_home_cards(permissions):
   cards = []
   if permissions.get("can_classify"):
       cards.extend(
           [
               _home_option_card(
                   "Classify Existing Parts",
                   "Upload and classify existing part records",
                   "classify_existing",
                   "existing_parts_new",
                   "📦",
               ),
               _home_option_card(
                   "Validate Classified Parts",
                   "Review predictions and approve final UNSPSC",
                   "validation",
                   icon="✅",
               ),
               _home_option_card(
                   "Runs",
                   "Monitor submitted jobs, status, and outputs",
                   "classify_existing",
                   "runs",
                   "📋",
               ),
               _home_option_card(
                   "Create New Parts",
                   "Create and classify new part entries",
                   "create_new_parts",
                   icon="🆕",
               ),
           ]
       )
   elif permissions.get("can_validate"):
       cards.append(
           _home_option_card(
               "Validate Classified Parts",
               "Review predictions and approve final UNSPSC",
               "validation",
               icon="✅",
           )
       )
   return cards

def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css())
   permissions = get_current_user_permissions()
   render_sidebar(subtitle="Home")
   render_top_nav(active_slug="home")
   cards = _build_home_cards(permissions)
   if cards:
       cards_html = "".join(cards)
   else:
       cards_html = """
<div class="home-v2-empty">
           No actions are available for your current access level.
</div>
       """
   st.markdown(
       f"""
<div class="home-v2-root">
<section class="home-v2-hero">
<div class="home-v2-badge">🚆 AI PARTS WORKSPACE</div>
<p class="home-v2-subtitle">Choose the activity you want to perform.</p>
</section>
<div style="height:30px;"></div>
<section class="home-v2-grid-wrap">
<div class="home-v2-grid">
                   {cards_html}
</div>
</section>
</div>
       """,
       unsafe_allow_html=True,
   )
   