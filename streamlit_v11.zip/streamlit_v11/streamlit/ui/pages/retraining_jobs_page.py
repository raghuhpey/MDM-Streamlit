import pandas as pd
import streamlit as st
from services.retraining_service import (
   fetch_retraining_jobs_df,
   fetch_retraining_job_metadata,
)
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def _go_admin_home():
   st.query_params["page"] = "admin"
   st.rerun()

def _go_retraining_trigger():
   st.query_params["page"] = "retraining"
   st.rerun()

def _open_job_detail(job_id: str):
   st.session_state["retraining_detail_job_id"] = job_id
   st.session_state["nav_page"] = "retraining_jobs"
   st.session_state["nav_run_id"] = job_id
   st.query_params["page"] = "retraining_jobs"
   st.query_params["run_id"] = job_id
   st.rerun()

def _render_jobs_table(df: pd.DataFrame):
   preferred_cols = [
       "retraining_job_id",
       "job_name",
       "status",
       "created_by",
       "created_ts",
       "started_ts",
       "completed_ts",
       "duration_seconds",
       "scenario_run_id",
       "model_version",
       "remarks",
       "error_message",
   ]
   display_cols = [c for c in preferred_cols if c in df.columns]
   display_df = df[display_cols].copy() if display_cols else df.copy()
   st.dataframe(display_df, use_container_width=True, hide_index=True)

def _render_job_detail(job_id: str):
   meta = fetch_retraining_job_metadata(job_id)
   detail_top = st.columns([1, 1, 6])
   with detail_top[0]:
       if st.button("← Jobs", key="retraining_detail_back_btn", use_container_width=True):
        st.session_state.pop("retraining_detail_job_id", None)
        st.session_state["nav_page"] = "retraining_jobs"
        st.session_state["nav_run_id"] = None
        st.query_params["page"] = "retraining_jobs"
        if "run_id" in st.query_params:
            del st.query_params["run_id"]
        st.rerun()
   with detail_top[1]:
       if st.button("Refresh", key="retraining_detail_refresh_btn", use_container_width=True):
           st.rerun()
   if meta is None:
       st.error(f"Retraining job not found: {job_id}")
       return
   st.markdown(
       f"""
<div class="section-card" style="margin-top:18px;">
<div class="section-card-title">Retraining Job Detail</div>
<div class="section-card-subtitle">
<b>Retraining Job ID:</b> {job_id}
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   c1, c2, c3 = st.columns(3, gap="large")
   with c1:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Status</div>
<div style="font-size:24px; font-weight:800; color:#0f172a; margin-top:8px;">
                   {meta.get("status", "-")}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   with c2:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Scenario Run ID</div>
<div style="font-size:16px; font-weight:700; color:#0f172a; margin-top:10px; word-break:break-word;">
                   {meta.get("scenario_run_id", "-") or "-"}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   with c3:
       st.markdown(
           f"""
<div class="section-card">
<div class="section-card-title" style="font-size:16px;">Model Version</div>
<div style="font-size:18px; font-weight:700; color:#0f172a; margin-top:10px; word-break:break-word;">
                   {meta.get("model_version", "-") or "-"}
</div>
</div>
           """,
           unsafe_allow_html=True,
       )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   detail_df = pd.DataFrame([meta]).T.reset_index()
   detail_df.columns = ["Field", "Value"]
   st.dataframe(detail_df, use_container_width=True, hide_index=True)
   error_message = str(meta.get("error_message", "") or "").strip()
   if error_message:
       st.markdown("<div style='height:10px;'></div>", unsafe_allow_html=True)
       st.error(error_message)

def render():
   load_css(
       get_global_css()
       + get_app_shell_css()
       + get_home_page_css()
       + get_classify_page_css()
   )
   render_sidebar(subtitle="Admin")
   render_top_nav(active_slug="admin")
   job_id = st.query_params.get("run_id", st.session_state.get("retraining_detail_job_id"))
   if job_id:
       _render_job_detail(str(job_id))
       return
   top_cols = st.columns([1, 1, 6, 1])
   with top_cols[0]:
       if st.button("← Back", key="retraining_jobs_back_btn", use_container_width=True):
           _go_admin_home()
   with top_cols[1]:
       if st.button("New Job", key="retraining_jobs_new_btn", use_container_width=True):
           _go_retraining_trigger()
   with top_cols[3]:
       if st.button("Refresh", key="retraining_jobs_refresh_btn", use_container_width=True):
           st.rerun()
   st.markdown(
       """
<div class="section-card" style="margin-top:18px;">
<div class="section-card-title">Retraining Jobs</div>
<div class="section-card-subtitle">
               Track retraining jobs and open a job to view details.
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("<div style='height:14px;'></div>", unsafe_allow_html=True)
   df = fetch_retraining_jobs_df()
   if df is None or df.empty:
    st.info("No retraining jobs found.")
    return
   _render_jobs_table(df)
   st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)
   job_ids = df["retraining_job_id"].dropna().astype(str).tolist() if "retraining_job_id" in df.columns else []
   selected_job = st.selectbox(
       "Select Retraining Job",
       options=[""] + job_ids,
       index=0,
       key="retraining_jobs_selected_job",
   )
   if selected_job:
       open_cols = st.columns([1, 5])
       with open_cols[0]:
           if st.button("View", key="retraining_jobs_view_btn", use_container_width=True):
               _open_job_detail(selected_job)
