import streamlit as st
from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   get_admin_cards_css,
   load_css,
)

def option_card(
   title: str,
   subtitle: str,
   icon: str,
   target_page: str,
   disabled: bool = False,
):
   if disabled:
       return f"""
<div class="home-option-card disabled">
<div class="home-option-card-left">
<div class="home-option-icon">{icon}</div>
<div class="home-option-text">
<div class="home-option-title">{title}</div>
<div class="home-option-subtitle">{subtitle}</div>
</div>
</div>
<div class="home-option-arrow">→</div>
</div>
       """
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{target_page}">
<button type="submit" class="home-option-card-btn">
<div class="home-option-card">
<div class="home-option-card-left">
<div class="home-option-icon">{icon}</div>
<div class="home-option-text">
<div class="home-option-title">{title}</div>
<div class="home-option-subtitle">{subtitle}</div>
</div>
</div>
<div class="home-option-arrow">→</div>
</div>
</button>
</form>
   """

def render():
   load_css(
   get_global_css()
   + get_app_shell_css()
   + get_home_page_css()
   + get_classify_page_css()
   + get_admin_cards_css()
)
   permissions = get_current_user_permissions()
   render_sidebar(subtitle="Admin")
   render_top_nav(active_slug="admin")
   st.markdown(
       """
<div class="section-card" style="margin-top:18px;">
<div class="section-card-title">Admin</div>
<div class="section-card-subtitle">
               Choose the activity you want to perform.
</div>
</div>
       """,
       unsafe_allow_html=True,
   )
   st.markdown("<div style='height:18px;'></div>", unsafe_allow_html=True)
   can_retrain = bool(permissions.get("can_retrain", False))
   col1, col2 = st.columns(2, gap="large")
   with col1:
       st.markdown(
           option_card(
               title="Model Retraining",
               subtitle="Trigger model retraining jobs",
               icon="🔁",
               target_page="retraining",
               disabled=not can_retrain,
           ),
           unsafe_allow_html=True,
       )
   with col2:
       st.markdown(
           option_card(
               title="Retraining Jobs",
               subtitle="Track retraining jobs",
               icon="📑",
               target_page="retraining_jobs",
               disabled=False,
           ),
           unsafe_allow_html=True,
       )