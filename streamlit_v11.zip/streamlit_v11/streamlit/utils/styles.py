import streamlit as st
def load_css(css: str):
  st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
  
def get_global_css():
  return """
  .stApp {
      background-color: #ffffff;
  }
  header[data-testid="stHeader"] {
     height: 0rem !important;
     min-height: 0rem !important;
     background: transparent !important;
     pointer-events: none !important;
 }
  [data-testid="stToolbar"] {
      right: 10px;
      top: 10px;
  }
  #MainMenu {
      visibility: hidden;
  }
  footer {
      visibility: hidden;
  }
  .block-container {
      padding-top: 0rem;
      padding-left: 0.7rem;
      padding-right: 0.7rem;
      padding-bottom: 0.5rem;
      max-width: 100%;
  }
  """
def get_app_shell_css():
  return """
  
  section[data-testid="stSidebar"] {
      width: 270px !important;
      min-width: 270px !important;
      border-right: none !important;
  }
  section[data-testid="stSidebar"] > div {
      width: 270px !important;
      background: #0f4f70 !important;
  }
  section[data-testid="stSidebar"] [data-testid="stSidebarContent"] {
      background: #0f4f70 !important;
      min-height: 100vh;
      padding: 0rem 0rem 0rem 0rem;
  }
  section[data-testid="stSidebar"] .block-container {
      padding: 0 !important;
  }
  [data-testid="stSidebarCollapseButton"] {
      display: none;
  }
  .app-sidebar-inner {
      min-height: calc(100vh - 1.7rem);
      background: #0f4f70;
      border-radius: 18px;
      padding: 14px 10px 20px 10px;
      color: #ffffff;
      box-sizing: border-box;
  }
  .app-sidebar-page-name {
      font-size: 13px;
      font-weight: 700;
      color: #dbe8ff;
      margin-top: 8px;
      line-height: 1.35;
  }
  .left-menu-btn {
   display: flex;
   align-items: center;
   justify-content: center;
   text-align: center;
   text-decoration: none !important;
   line-height: 1.2;
   }
  .left-menu-btn:visited,
  .left-menu-btn:hover,
  .left-menu-btn:focus,
  .left-menu-btn:active {
   text-decoration: none !important;
  }
  .classify-logo-wrap {
      margin-bottom: 22px;
  }
  .classify-logo-img {
      width: 100%;
      max-width: 245px;
      display: block;
      border-radius: 3px;
  }
  .classify-title {
      font-size: 18px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 8px;
      line-height: 1.3;
  }
  .left-group-title {
      font-size: 13px;
      font-weight: 700;
      color: #dbe8ff;
      margin-top: 10px;
      margin-bottom: 14px;
  }
  .left-divider {
      border: none;
      height: 1px;
      background: rgba(255,255,255,0.18);
      margin-top: 18px;
      margin-bottom: 16px;
  }
  .left-menu-form {
      margin: 0 0 10px 0;
  }
  .left-menu-btn {
      width: 100%;
      border: 1px solid #d7d9dd;
      border-radius: 10px;
      padding: 11px 12px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      background: #f7f7f8;
      color: #4b5563;
      box-sizing: border-box;
      font-family: inherit;
      appearance: none;
      -webkit-appearance: none;
  }
  .left-menu-btn.active {
      background: #f44747;
      color: #ffffff;
      border-color: #f44747;
  }
  .app-topbar-wrap {
      position: sticky;
      top: 0;
      z-index: 10;
      background: #ffffff;
      padding-top: 0rem;
  }
  .classify-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 18px;
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 5fr));
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 10px;
  }
  .nav-pill {
     display: flex !important;
     align-items: center;
     justify-content: center;
     width: 100%;
     min-height: 56px;
     height: 100%;
     margin: 0;
     padding: 12px 10px;
     background: #f7f7f8;
     border: 1px solid #d6d8dd;
     border-radius: 12px;
     text-align: center;
     font-size: 14px;
     font-weight: 600;
     color: #6b7280 !important;
     line-height: 1.2;
     box-sizing: border-box;
     white-space: nowrap;
     overflow: hidden;
     text-overflow: ellipsis;
     text-decoration: none !important;
     transition: 0.1s ease;
     cursor: pointer;
     appearance: none;
     -webkit-appearance: none;
     font-family: inherit;
     position: relative;
     z-index: 2;
  }
  .nav-pill:hover {
      transform: translateY(-1px);
  }
  .nav-pill.active {
      background: #f44747;
      color: #ffffff !important;
      border-color: #f44747;
  }
  .page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  @media (max-width: 1200px) {
      .classify-topbar {
          grid-template-columns: repeat(3, minmax(0, 1fr));
      }
  }
  @media (max-width: 900px) {
      section[data-testid="stSidebar"] {
          width: 100% !important;
          min-width: 100% !important;
      }
      section[data-testid="stSidebar"] > div {
          width: 100% !important;
      }
      .app-sidebar-inner {
          min-height: auto;
      }
      .classify-topbar {
          grid-template-columns: repeat(2, minmax(0, 1fr));
      }
  }
  @media (max-width: 600px) {
      .classify-topbar {
          grid-template-columns: 1fr;
      }
  }
  """

def get_home_page_css():
 return """
 .home-v2-root {
     width: 100%;
     box-sizing: border-box;
 }
 .home-v2-hero {
     background: #f7f9fc;
     border: 1px solid #e2e8f0;
     border-radius: 26px;
     padding: 28px 30px 24px 30px;
     box-sizing: border-box;
     margin-bottom: 22px;
     text-align: center;
 }
 .home-v2-badge {
     display: inline-flex;
     align-items: center;
     justify-content: center;
     padding: 8px 14px;
     border-radius: 999px;
     background: #e7effa;
     color: #55739a;
     font-size: 16px;
     font-weight: 800;
     letter-spacing: 0.04em;
     text-transform: uppercase;
     margin-bottom: 14px;
 }
 .home-v2-title {
     margin: 0;
     font-size: 34px;
     font-weight: 800;
     line-height: 1.15;
     color: #0f172a;
 }
 .home-v2-subtitle {
     margin: 10px 0 0 0;
     font-size: 16px;
     line-height: 1.45;
     color: #64748b;
 }
 .home-v2-grid-wrap {
     width: 100%;
     box-sizing: border-box;
 }
 .home-v2-grid {
     display: grid;
     grid-template-columns: repeat(3, minmax(0, 1fr));
     gap: 20px;
     width: 100%;
     box-sizing: border-box;
 }
 .home-v2-card {
     display: flex;
     align-items: center;
     justify-content: space-between;
     gap: 16px;
     min-height: 108px;
     padding: 20px 18px;
     border-radius: 20px;
     background: #ffffff;
     border: 1px solid #e2e8f0;
     box-shadow: 0 1px 2px rgba(15, 23, 42, 0.05);
     box-sizing: border-box;
     text-decoration: none !important;
     transition: transform 0.16s ease, box-shadow 0.16s ease, border-color 0.16s ease;
 }
 .home-v2-card:hover {
     transform: translateY(-2px);
     border-color: #c7d6e5;
     box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
     text-decoration: none !important;
 }
 .home-v2-card:visited,
 .home-v2-card:focus,
 .home-v2-card:active {
     text-decoration: none !important;
 }
 .home-v2-card-left {
     display: flex;
     align-items: center;
     gap: 14px;
     min-width: 0;
     flex: 1;
 }
 .home-v2-card-icon {
     width: 52px;
     min-width: 52px;
     height: 52px;
     border-radius: 14px;
     background: linear-gradient(180deg, #0f6b98 0%, #0f4f70 100%);
     color: #ffffff;
     display: flex;
     align-items: center;
     justify-content: center;
     font-size: 24px;
     box-shadow: inset 0 0 0 1px rgba(255,255,255,0.10);
 }
 .home-v2-card-copy {
     min-width: 0;
     flex: 1;
 }
 .home-v2-card-title {
     font-size: 16px;
     font-weight: 800;
     line-height: 1.25;
     color: #0f172a;
     margin: 0 0 6px 0;
     word-break: break-word;
 }
 .home-v2-card-subtitle {
     font-size: 13px;
     line-height: 1.45;
     color: #64748b;
     margin: 0;
     word-break: break-word;
 }
 .home-v2-card-arrow {
     color: #0f6b98;
     font-size: 20px;
     font-weight: 700;
     line-height: 1;
     flex-shrink: 0;
     margin-left: 8px;
 }
 .home-v2-empty {
     background: #ffffff;
     border: 1px solid #e2e8f0;
     border-radius: 18px;
     padding: 24px;
     color: #64748b;
     font-size: 15px;
 }
 @media (max-width: 1200px) {
     .home-v2-grid {
         grid-template-columns: repeat(2, minmax(0, 1fr));
     }
 }
 @media (max-width: 760px) {
     .home-v2-hero {
         padding: 22px 20px;
     }
     .home-v2-title {
         font-size: 28px;
     }
     .home-v2-grid {
         grid-template-columns: 1fr;
     }
     .home-v2-card {
         min-height: 96px;
     }
 }
 """

def get_workflow_page_css():
  return """
  .workflow-shell {
      display: flex;
      gap: 18px;
      align-items: flex-start;
      width: 100%;
      box-sizing: border-box;
  }
  .workflow-left {
      width: 320px;
      background: #0d47a1;
      border-radius: 22px;
      padding: 24px 20px;
      box-sizing: border-box;
      flex-shrink: 0;
      color: white;
      min-height: 640px;
  }
  .workflow-left-title {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 10px;
      line-height: 1.25;
      color: #ffffff;
  }
  .workflow-left-subtitle {
      font-size: 14px;
      line-height: 1.5;
      color: #dbe8ff;
      margin-bottom: 24px;
  }
  .section-label {
      font-size: 14px;
      font-weight: 700;
      color: #ffffff;
      margin-top: 18px;
      margin-bottom: 8px;
  }
  .upload-box {
      border: 2px dashed rgba(255,255,255,0.45);
      border-radius: 16px;
      padding: 22px 16px;
      text-align: center;
      color: #dbe8ff;
      background: rgba(255,255,255,0.06);
      margin-bottom: 18px;
  }
  .upload-box-title {
      font-size: 15px;
      font-weight: 700;
      margin-bottom: 6px;
      color: #ffffff;
  }
  .upload-box-subtext {
      font-size: 13px;
      color: #dbe8ff;
      line-height: 1.4;
  }
  .workflow-right {
      flex: 1;
      min-width: 0;
      box-sizing: border-box;
  }
  .workflow-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 24px;
  }
  .content-card {
      background: #ffffff;
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 22px;
      box-sizing: border-box;
      margin-bottom: 18px;
  }
  .content-card-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .content-card-subtitle {
      font-size: 14px;
      color: #6b7280;
      margin-bottom: 18px;
      line-height: 1.5;
  }
  .status-box {
      background: #fff4db;
      border: 1px solid #f4d58d;
      color: #8a6514;
      border-radius: 14px;
      padding: 14px 16px;
      font-size: 14px;
      font-weight: 600;
  }
  .preview-box {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 14px;
      padding: 26px 18px;
      text-align: center;
      color: #64748b;
      font-size: 14px;
  }
  .stFileUploader {
      background: transparent;
  }
  .stSelectbox > div > div {
      border-radius: 12px;
  }
  .stButton > button {
      width: 100%;
      border-radius: 12px;
      min-height: 42px;
      font-weight: 700;
  }
  @media (max-width: 1200px) {
      .workflow-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .workflow-shell {
          flex-direction: column;
      }
      .workflow-left {
          width: 100%;
          min-height: auto;
      }
      .workflow-topbar {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 600px) {
      .workflow-topbar {
          grid-template-columns: 1fr;
      }
  }
  """

def get_classify_page_css():
  return """
  .classify-left-panel {
      background: #0f4f70;
      border-radius: 22px;
      padding: 20px 10px 400px 20px;
      min-height: 620px;
      box-sizing: border-box;
      color: #ffffff;
  }
  .classify-logo-wrap {
      margin-bottom: 22px;
  }
  .classify-logo-img {
      width: 250px;
      max-width: 100%;
      display: block;
  }
  .classify-title {
      font-size: 18px;
      font-weight: 700;
      color: #ffd8cc;
      margin-bottom: 8px;
      line-height: 1.3;
  }
  .classify-subtitle {
      font-size: 13px;
      font-weight: 600;
      color: #dbe8ff;
      line-height: 1.35;
      margin-bottom: 28px;
  }
  .left-group-title {
       font-size: 13px;
       font-weight: 700;
       color: #dbe8ff;
       margin-top: 10px;
       margin-bottom: 14px;
   }
  .left-divider {
      border: none;
      height: 1px;
      background: rgba(255,255,255,0.18);
      margin-top: 18px;
      margin-bottom: 18px;
  }
  .left-menu-form {
      margin: 0 0 10px 0;
  }
  .left-menu-btn {
      width: 100%;
      border: 1px solid #d7d9dd;
      border-radius: 14px;
      padding: 13px 14px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      background: #f7f7f8;
      color: #4b5563;
      box-sizing: border-box;
      font-family: inherit;
      appearance: none;
      -webkit-appearance: none;
      margin-bottom: 20px;
  }
  .left-menu-btn.active {
      background: #f44747;
      color: #ffffff;
      border: 1px solid #f44747;
  }
  .classify-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 22px;
  }
  .page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  .panel-title {
      font-size: 15px;
      font-weight: 700;
      color: #4b5563;
      margin-bottom: 10px;
  }
  .upload-hint-box {
      background: #dce9fb;
      border: 1px solid #c9daf4;
      border-radius: 12px;
      padding: 14px 16px;
      color: #4177bb;
      font-size: 14px;
      font-weight: 600;
      margin-top: 14px;
      margin-bottom: 18px;
  }
  .section-card {
      background: linear-gradient(135deg, #163454 0%, #264a6d 100%);
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 8px;
      box-sizing: border-box;
      margin-top: 0.2px;
  }
  .section-card-title {
      font-size: 18px;
      font-weight: 800;
      color: #ffffff;
      margin-bottom: 8px;
  }
  .section-card-subtitle {
      font-size: 12px;
      color: rgba(255,255,255,0.82);
      line-height: 0.5;
      margin-bottom: 14px;
  }
  .empty-state-box {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 14px;
      padding: 28px 18px;
      text-align: center;
      color: #64748b;
      font-size: 14px;
  }
  .runs-placeholder {
      background: linear-gradient(135deg, #163454 0%, #264a6d 100%);
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 8px;
      margin-top: 0.2px;
  }

  .runs-placeholder-title {
      font-size: 18px;
      font-weight: 800;
      color: #ffffff;
      margin-bottom: 8px;
  }
  .runs-placeholder-text {
      font-size: 14px;
      color: #ffffff;
      line-height: 1.5;
  }
  .runs-header-cell {
      background: #4b5563;
      color: #ffffff;
      border-radius: 12px;
      padding: 20px 10px;
      padding-top: 5px;
      padding-bottom: 5px;
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 8px;
      text-align: center;
  }
  .runs-cell {
      padding-top: 10px;
      padding-bottom: 10px;
      font-size: 14px;
      text-align: center;
      color: #374151;
      word-break: break-word;
  }
  .status-pill {
   display: inline-block;
   padding: 5px 12px;
   border-radius: 999px;
   color: #ffffff;
   font-size: 12px;
   font-weight: 700;
   }
  .status-pill.uploaded {
   background: #64748b;
   }
  .status-pill.submitted {
   background: #f59e0b;
   }
  .status-pill.running {
   background: #2563eb;
   }
  .status-pill.completed {
   background: #16a34a;
   }
  .status-pill.failed {
   background: #dc2626;
   }
  .status-pill.stopped {
   background: #64748b;
   }
  .status-pill.aborted {
   background: #64748b;
   }
  .status-pill.pending {
   background: #f59e0b;
   }
  .status-pill.in_progress {
   background: #2563eb;
   }
  .run-meta-card {
      background: #ffffff;
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 18px;
      margin-bottom: 18px;
  }
  .run-meta-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .run-meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 12px;
  }
  .run-meta-item {
      background: #f8fafc;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 12px;
  }
  .run-meta-label {
      font-size: 12px;
      color: #6b7280;
      margin-bottom: 4px;
      font-weight: 600;
  }
  .run-meta-value {
      font-size: 14px;
      color: #111827;
      font-weight: 700;
      word-break: break-word;
  }
  .pagination-summary {
      text-align: center;
      font-size: 16px;
      font-weight: 700;
      color: #374151;
      padding-top: 6px;
  }
  .pagination-right-label {
      font-size: 12px;
      font-weight: 700;
      color: #6b7280;
      margin-bottom: 4px;
  }
  .pagination-table-wrap {
      margin-top: 6px;
  }
  .stFileUploader {
      margin-bottom: 0.25rem;
  }
  @media (max-width: 1200px) {
      .classify-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
      .run-meta-grid {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .classify-topbar {
          grid-template-columns: 1fr 1fr;
      }
      .run-meta-grid {
          grid-template-columns: 1fr;
      }
  }
  @media (max-width: 600px) {
      .classify-topbar {
          grid-template-columns: 1fr;
      }
  }
  """
######################## Validation CSS ###################################################
def get_validation_page_css():
  return """
  .validation-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 22px;
  }
  .validation-page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  .validation-summary-chip {
      display: inline-block;
      background: #eef2ff;
      border: 1px solid #c7d2fe;
      border-radius: 999px;
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 700;
      color: #4338ca;
      margin-right: 8px;
      margin-bottom: 8px;
  }
  .validation-help-box {
      background: #dce9fb;
      border: 1px solid #c9daf4;
      border-radius: 12px;
      padding: 14px 16px;
      color: #4177bb;
      font-size: 14px;
      font-weight: 600;
      margin-top: 14px;
      margin-bottom: 18px;
  }
  .validation-record-header {
      font-size: 22px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .validation-subtitle {
      font-size: 14px;
      color: #6b7280;
      line-height: 1.5;
      margin-bottom: 14px;
  }
  .validation-label {
      font-size: 13px;
      font-weight: 700;
      color: #374151;
      margin-bottom: 8px;
  }
  .validation-display-box {
      background: #ffffff;
      border: 1px solid #dfe3ea;
      border-radius: 16px;
      padding: 16px 18px;
      min-height: 150px;
      color: #111827;
      line-height: 1.6;
      font-size: 15px;
      box-sizing: border-box;
      overflow-wrap: anywhere;
      white-space: pre-wrap;
  }
  .validation-display-box.compact {
      min-height: 120px;
  }
  .validation-display-box.description-box {
      min-height: 150px;
  }
  .validation-shortdesc {
      font-size: 16px;
      font-weight: 700;
      color: #111827;
      line-height: 1.5;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .validation-explanation {
      font-size: 15px;
      font-weight: 500;
      color: #1f2937;
      line-height: 1.7;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .validation-review-header-bar {
  display: grid;
  grid-template-columns: 1.8fr 2.8fr 2.2fr 2.8fr 1.4fr 1.1fr;
  gap: 18px;
  background: #dce9fb;
  border: 1px solid #c9daf4;
  border-radius: 16px;
  padding: 14px 18px;
  margin-bottom: 14px;
  align-items: center;
  }
  .validation-review-header-cell {
  font-size: 14px;
  font-weight: 800;
  color: #334155;
  }  
  .pred-desc-entry {
      margin-bottom: 18px;
  }
  .pred-desc-code {
      font-size: 16px;
      font-weight: 800;
      color: #111827;
      margin-bottom: 6px;
  }
  .pred-desc-text {
      font-size: 15px;
      color: #4b5563;
      line-height: 1.6;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .pred-desc-missing {
      font-size: 14px;
      color: #9ca3af;
      font-style: italic;
  }
  @media (max-width: 1200px) {
      .validation-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .validation-topbar {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 600px) {
      .validation-topbar {
          grid-template-columns: 1fr;
      }
  }
  """


def get_admin_cards_css():
   return """
   .home-option-card-btn {
       width: 100%;
       border: none;
       background: transparent;
       padding: 0;
       cursor: pointer;
       text-align: left;
   }
   .home-option-card {
       width: 100%;
       min-height: 104px;
       background: #ffffff;
       border: 1px solid #dfe3ea;
       border-radius: 18px;
       padding: 18px 20px;
       display: flex;
       align-items: center;
       justify-content: space-between;
       box-sizing: border-box;
       box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05);
       transition: all 0.2s ease;
   }
   .home-option-card-btn:hover .home-option-card {
       border-color: #c7d7ea;
       box-shadow: 0 4px 14px rgba(15, 23, 42, 0.08);
       transform: translateY(-1px);
   }
   .home-option-card.disabled {
       opacity: 0.55;
       cursor: not-allowed;
   }
   .home-option-card-left {
       display: flex;
       align-items: center;
       gap: 16px;
   }
   .home-option-icon {
       width: 46px;
       height: 46px;
       border-radius: 12px;
       background: #0f6c8d;
       color: #ffffff;
       display: flex;
       align-items: center;
       justify-content: center;
       font-size: 22px;
       flex-shrink: 0;
   }
   .home-option-text {
       display: flex;
       flex-direction: column;
       gap: 4px;
   }
   .home-option-title {
       font-size: 16px;
       font-weight: 700;
       color: #111827;
       line-height: 1.25;
   }
   .home-option-subtitle {
       font-size: 13px;
       color: #6b7280;
       line-height: 1.35;
   }
   .home-option-arrow {
       font-size: 20px;
       font-weight: 700;
       color: #0f6c8d;
       flex-shrink: 0;
   }
   """