from __future__ import annotations
from datetime import datetime, timezone
from typing import Any
import dataiku
import pandas as pd
from dataiku import SQLExecutor2
from services.run_storage_service import get_current_user_login
CLASSIFICATION_DATASET_NAME = "MDM_classification_tbl"
GOLDEN_DATASET_NAME = "mdm_golden_dataset_tbl"   # change only if your Dataiku dataset object name differs
VALIDATION_STATUS_PENDING = "pending"
VALIDATION_STATUS_IN_PROGRESS = "in_progress"
VALIDATION_STATUS_APPROVED = "approved"
SQL_INSERT_BATCH_SIZE = 200
DB_TO_UI_RENAME = {
   "model_1_op": "Model 1 OP",
   "model_2_op": "Model 2 OP",
   "model_3_op": "Model 3 OP",
   "llm_judge_op": "LLM as a Judge OP",
   "llm_decision_source": "LLM Decision Source",
   "explanation": "Explanation",
   "validated_unspsc": "Validated UNSPSC",
   "validation_decision_source": "Validation Decision Source",
   "validation_comment": "Validation Comment",
   "validation_status": "Validation Status",
   "validated_by": "Validated By",
   "validated_at": "Validated At",
   "run_id": "Prediction Job ID",
   "uploaded_by": "Prediction Created By",
}
TECHNICAL_DROP_COLS_GOLDEN = {
   "backend_run_id",
   "backend_trigger_id",
   "prediction_started_ts",
   "prediction_completed_ts",
   "row_hash",
   "created_ts",
   "updated_ts",
   "is_golden_record",
}

def _utc_now_string() -> str:
   return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def _quote_identifier(identifier: str) -> str:
   return f'"{identifier}"'

def _sql_escape(value: Any) -> str:
   if pd.isna(value) or value is None:
       return "NULL"
   if isinstance(value, bool):
       return "TRUE" if value else "FALSE"
   if isinstance(value, pd.Timestamp):
       value = value.isoformat()
   s = str(value).replace("'", "''")
   return f"'{s}'"

def _to_bool(value: Any) -> bool:
   if pd.isna(value) or value is None:
       return False
   if isinstance(value, bool):
       return value
   if isinstance(value, (int, float)):
       return value == 1
   return str(value).strip().lower() in {"1", "true", "yes", "y", "t"}

def _dataset(dataset_name: str):
   return dataiku.Dataset(dataset_name)

def _dataset_df(dataset_name: str) -> pd.DataFrame:
   return _dataset(dataset_name).get_dataframe()

def _schema_columns(dataset_name: str) -> list[str]:
   schema = _dataset(dataset_name).read_schema()
   return [c["name"] for c in schema]

def _dataset_sql_info(dataset_name: str) -> dict:
   ds = _dataset(dataset_name)
   loc = ds.get_location_info()
   info = loc.get("info", {})
   connection_name = info.get("connectionName")
   quoted_table_name = info.get("quotedResolvedTableName")
   if not connection_name or not quoted_table_name:
       raise ValueError(f"Could not resolve SQL info for dataset: {dataset_name}")
   return {
       "dataset": ds,
       "connection_name": connection_name,
       "quoted_table_name": quoted_table_name,
       "project_key": ds.project_key,
   }

def _run_sql(dataset_name: str, sql: str):
   info = _dataset_sql_info(dataset_name)
   client = dataiku.api_client()
   query = client.sql_query(
       sql,
       connection=info["connection_name"],
       type="sql",
       project_key=info["project_key"],
       post_queries=["COMMIT"],
   )
   query.verify()

def _query_to_df(dataset_name: str, sql: str) -> pd.DataFrame:
   ds = _dataset(dataset_name)
   executor = SQLExecutor2(dataset=ds)
   return executor.query_to_df(sql)

def _align_to_schema(df: pd.DataFrame, dataset_name: str) -> pd.DataFrame:
   schema_cols = _schema_columns(dataset_name)
   out_df = df.copy()
   for col in schema_cols:
       if col not in out_df.columns:
           out_df[col] = None
   return out_df[schema_cols]

def _insert_rows_via_sql(dataset_name: str, df_to_insert: pd.DataFrame):
   if df_to_insert.empty:
       return
   info = _dataset_sql_info(dataset_name)
   columns = list(df_to_insert.columns)
   quoted_cols = ", ".join(_quote_identifier(c) for c in columns)
   for start in range(0, len(df_to_insert), SQL_INSERT_BATCH_SIZE):
       batch_df = df_to_insert.iloc[start:start + SQL_INSERT_BATCH_SIZE]
       value_rows = []
       for _, row in batch_df.iterrows():
           values_sql = ", ".join(_sql_escape(row[c]) for c in columns)
           value_rows.append(f"({values_sql})")
       sql = f"""
       INSERT INTO {info['quoted_table_name']} ({quoted_cols})
       VALUES
       {", ".join(value_rows)}
       """
       _run_sql(dataset_name, sql)

def _normalized_validation_status(series: pd.Series) -> pd.Series:
   return (
       series.fillna(VALIDATION_STATUS_PENDING)
       .astype(str)
       .str.strip()
       .str.lower()
   )

def _prepare_classification_work_df() -> pd.DataFrame:
   full_df = _dataset_df(CLASSIFICATION_DATASET_NAME)
   if full_df.empty:
       return full_df
   if "run_status" not in full_df.columns:
       return pd.DataFrame()
   work_df = full_df[
       full_df["run_status"].astype(str).str.strip().str.lower() == "completed"
   ].copy()
   if work_df.empty:
       return work_df
   if "validation_status" not in work_df.columns:
       work_df["validation_status"] = VALIDATION_STATUS_PENDING
   if "validated_unspsc" not in work_df.columns:
       work_df["validated_unspsc"] = None
   if "validation_decision_source" not in work_df.columns:
       work_df["validation_decision_source"] = None
   if "validated_by" not in work_df.columns:
       work_df["validated_by"] = None
   if "validated_at" not in work_df.columns:
       work_df["validated_at"] = None
   if "validation_comment" not in work_df.columns:
       work_df["validation_comment"] = None
   if "is_golden_record" not in work_df.columns:
       work_df["is_golden_record"] = False
   work_df["_validation_status_norm"] = _normalized_validation_status(work_df["validation_status"])
   work_df["_is_approved"] = (
       (work_df["_validation_status_norm"] == VALIDATION_STATUS_APPROVED)
       | work_df["is_golden_record"].apply(_to_bool)
   )
   return work_df

def _build_run_summary_df() -> pd.DataFrame:
   work_df = _prepare_classification_work_df()
   if work_df.empty:
       return pd.DataFrame(
           columns=[
               "run_id",
               "file_name",
               "created_by",
               "approved_rows",
               "total_rows",
               "remaining_rows",
               "status",
               "updated_at",
               "updated_by",
           ]
       )
   work_df["_sort_ts"] = pd.to_datetime(
       work_df.get("validated_at", pd.Series([None] * len(work_df)))
       .fillna(work_df.get("updated_ts", pd.Series([None] * len(work_df))))
       .fillna(work_df.get("uploaded_ts", pd.Series([None] * len(work_df)))),
       errors="coerce",
       utc=True
   )
   records = []
   for run_id, grp in work_df.groupby("run_id", dropna=False):
       grp = grp.sort_values(by="_sort_ts", ascending=True)
       total_rows = int(len(grp))
       approved_rows = int(grp["_is_approved"].sum())
       remaining_rows = total_rows - approved_rows
       if remaining_rows <= 0:
           status = VALIDATION_STATUS_APPROVED
       elif approved_rows == 0:
           status = VALIDATION_STATUS_PENDING
       else:
           status = VALIDATION_STATUS_IN_PROGRESS
       validated_by_series = grp["validated_by"].dropna() if "validated_by" in grp.columns else pd.Series(dtype=object)
       updated_by = (
           str(validated_by_series.iloc[-1]).strip()
           if not validated_by_series.empty
           else str(grp["uploaded_by"].iloc[0]).strip()
       )
       updated_at = None
       if "validated_at" in grp.columns:
           validated_at_series = grp["validated_at"].dropna()
           if not validated_at_series.empty:
               updated_at = str(validated_at_series.iloc[-1]).strip()
       if not updated_at and "updated_ts" in grp.columns:
           updated_ts_series = grp["updated_ts"].dropna()
           if not updated_ts_series.empty:
               updated_at = str(updated_ts_series.iloc[-1]).strip()
       if not updated_at and "uploaded_ts" in grp.columns:
           uploaded_ts_series = grp["uploaded_ts"].dropna()
           if not uploaded_ts_series.empty:
               updated_at = str(uploaded_ts_series.iloc[0]).strip()
       records.append(
           {
               "run_id": str(run_id),
               "file_name": str(grp["file_name"].iloc[0]) if "file_name" in grp.columns else "",
               "created_by": str(grp["uploaded_by"].iloc[0]) if "uploaded_by" in grp.columns else "",
               "approved_rows": approved_rows,
               "total_rows": total_rows,
               "remaining_rows": remaining_rows,
               "status": status,
               "updated_at": updated_at or "",
               "updated_by": updated_by or "",
           }
       )
   if not records:
       return pd.DataFrame(
           columns=[
               "run_id",
               "file_name",
               "created_by",
               "approved_rows",
               "total_rows",
               "remaining_rows",
               "status",
               "updated_at",
               "updated_by",
           ]
       )
   out_df = pd.DataFrame(records)
   out_df["_sort_ts"] = pd.to_datetime(out_df["updated_at"], errors="coerce", utc=True)
   out_df = out_df.sort_values(by="_sort_ts", ascending=False).drop(columns=["_sort_ts"]).reset_index(drop=True)
   return out_df

def _pending_rows_internal(run_id: str) -> pd.DataFrame:
   work_df = _prepare_classification_work_df()
   if work_df.empty:
       return pd.DataFrame()
   run_df = work_df[work_df["run_id"].astype(str) == str(run_id)].copy()
   if run_df.empty:
       return pd.DataFrame()
   pending_df = run_df[~run_df["_is_approved"]].copy()
   if pending_df.empty:
       return pd.DataFrame()
   sort_series = pending_df.get("created_ts", pending_df.get("uploaded_ts", pd.Series([None] * len(pending_df))))
   pending_df["_sort_ts"] = pd.to_datetime(sort_series, errors="coerce", utc=True)
   pending_df = pending_df.sort_values(by="_sort_ts", ascending=True).drop(columns=["_sort_ts"]).reset_index(drop=True)
   pending_df["_validation_row_id"] = range(1, len(pending_df) + 1)
   return pending_df

def _rename_db_to_ui(df: pd.DataFrame) -> pd.DataFrame:
   out_df = df.copy()
   out_df = out_df.drop("validation_comment", axis = 1)
   rename_map = {k: v for k, v in DB_TO_UI_RENAME.items() if k in out_df.columns}
   out_df = out_df.rename(columns=rename_map)
   return out_df

# ---------------------------------------------------------------------
# Public API matching the old validation_storage_service contract
# ---------------------------------------------------------------------
def list_runs_to_validate():
   summary_df = _build_run_summary_df()
   if summary_df.empty:
       return []
   summary_df = summary_df[summary_df["remaining_rows"] > 0].copy()
   if summary_df.empty:
       return []
   records = []
   for _, row in summary_df.iterrows():
       records.append(
           {
               "Prediction Job": row["run_id"],
               "Prediction Created By": row["created_by"],
               "Approved Rows": f'{int(row["approved_rows"])}/{int(row["total_rows"])}',
               "Status": row["status"],
               "Last Updated": row["updated_at"],
               "Updated By": row["updated_by"],
               "prediction_job_id": row["run_id"],
           }
       )
   return records

def ensure_validation_run(run_id: str):
   summary_df = _build_run_summary_df()
   if summary_df.empty:
       return {
           "approved_rows": 0,
           "total_rows": 0,
           "remaining_rows": 0,
           "status": VALIDATION_STATUS_PENDING,
           "updated_at": "",
           "updated_by": "",
       }
   match = summary_df[summary_df["run_id"].astype(str) == str(run_id)]
   if match.empty:
       return {
           "approved_rows": 0,
           "total_rows": 0,
           "remaining_rows": 0,
           "status": VALIDATION_STATUS_PENDING,
           "updated_at": "",
           "updated_by": "",
       }
   row = match.iloc[0]
   return {
       "approved_rows": int(row["approved_rows"]),
       "total_rows": int(row["total_rows"]),
       "remaining_rows": int(row["remaining_rows"]),
       "status": row["status"],
       "updated_at": row["updated_at"],
       "updated_by": row["updated_by"],
   }

def load_validation_queue_df(run_id: str):
   pending_df = _pending_rows_internal(run_id)
   if pending_df.empty:
       return pd.DataFrame()
   drop_cols = [c for c in ["_validation_status_norm", "_is_approved"] if c in pending_df.columns]
   pending_df = pending_df.drop(columns=drop_cols, errors="ignore")
   pending_df = _rename_db_to_ui(pending_df)
   return pending_df.reset_index(drop=True)

def approve_validation_row(
   run_id: str,
   validation_row_id: int,
   validated_unspsc: str,
   validation_source: str,
   validation_comment: str = "",
):
   pending_internal_df = _pending_rows_internal(run_id)
   if pending_internal_df.empty:
       raise ValueError(f"No pending validation rows found for run_id={run_id}")
   match = pending_internal_df[
       pending_internal_df["_validation_row_id"].astype(int) == int(validation_row_id)
   ]
   if match.empty:
       raise ValueError(
           f"Could not find validation row id {validation_row_id} for run_id={run_id}"
       )
   selected_row = match.iloc[0]
   row_hash = str(selected_row["row_hash"])
   user_id = get_current_user_login()
   now_ts = _utc_now_string()
   # 1) Update row in MDM_classification_tbl
   info_cls = _dataset_sql_info(CLASSIFICATION_DATASET_NAME)
   update_sql = f"""
   UPDATE {info_cls['quoted_table_name']}
   SET
       "validation_status" = {_sql_escape(VALIDATION_STATUS_APPROVED)},
       "validated_unspsc" = {_sql_escape(validated_unspsc)},
       "validation_decision_source" = {_sql_escape(validation_source)},
       "validated_by" = {_sql_escape(user_id)},
       "validated_at" = {_sql_escape(now_ts)},
       "validation_comment" = {_sql_escape(validation_comment)},
       "is_golden_record" = TRUE,
       "updated_ts" = {_sql_escape(now_ts)}
   WHERE "run_id" = {_sql_escape(str(run_id))}
     AND "row_hash" = {_sql_escape(row_hash)}
   """
   _run_sql(CLASSIFICATION_DATASET_NAME, update_sql)
   # 2) Fetch updated row back
   fetch_sql = f"""
   SELECT *
   FROM {info_cls['quoted_table_name']}
   WHERE "run_id" = {_sql_escape(str(run_id))}
     AND "row_hash" = {_sql_escape(row_hash)}
   """
   updated_row_df = _query_to_df(CLASSIFICATION_DATASET_NAME, fetch_sql)
   if updated_row_df.empty:
       raise ValueError(
           f"Approved row not found after update for run_id={run_id}, validation_row_id={validation_row_id}"
       )
   updated_row_df = _align_to_schema(updated_row_df, GOLDEN_DATASET_NAME)
   # 3) Delete existing row from golden table if already present
   info_golden = _dataset_sql_info(GOLDEN_DATASET_NAME)
   delete_sql = f"""
   DELETE FROM {info_golden['quoted_table_name']}
   WHERE "row_hash" = {_sql_escape(row_hash)}
   """
   _run_sql(GOLDEN_DATASET_NAME, delete_sql)
   # 4) Insert into golden table
   _insert_rows_via_sql(GOLDEN_DATASET_NAME, updated_row_df)

def load_golden_dataset_df():
   golden_df = _dataset_df(GOLDEN_DATASET_NAME)
   if golden_df.empty:
       return pd.DataFrame()
   golden_df = golden_df.drop(columns=[c for c in TECHNICAL_DROP_COLS_GOLDEN if c in golden_df.columns], errors="ignore")
   golden_df = _rename_db_to_ui(golden_df)
   if "Validated At" in golden_df.columns:
       golden_df["_sort_ts"] = pd.to_datetime(golden_df["Validated At"], errors="coerce", utc=True)
       golden_df = golden_df.sort_values(by="_sort_ts", ascending=False).drop(columns=["_sort_ts"])
   return golden_df.reset_index(drop=True)