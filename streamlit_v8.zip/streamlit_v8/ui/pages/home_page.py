from urllib.parse import urlencode
import streamlit as st
from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css, get_home_page_css

def home_action_card(label, page, sub=None):
   params = {"page": page}
   if sub is not None:
       params["sub"] = sub
   href = f"?{urlencode(params)}"
   return f'<a href="{href}" target="_self" class="home-action-card">{label}</a>'

def _safe_card_html(items):
   cleaned = []
   for item in items:
       if item is None:
           continue
       if isinstance(item, tuple):
           if len(item) > 0:
               cleaned.append(str(item[0]))
       else:
           cleaned.append(str(item))
   return "".join(cleaned)

def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css())
   permissions = get_current_user_permissions()
   render_sidebar(subtitle="Home")
   render_top_nav(active_slug="home")
   left_cards = []
   right_cards = []
   if permissions["can_classify"]:
    #    left_cards.append(home_action_card("Classify Existing Parts", "classify_existing", "existing_parts"))
       left_cards.append(home_action_card("Classify Existing Parts", "classify_existing", "existing_parts_new"))
       left_cards.append(home_action_card("Validate Classified Parts", "validation"))
       left_cards.append(home_action_card("Runs", "classify_existing", "runs"))
       right_cards.append(home_action_card("Create New Parts", "create_new_parts"))
   elif permissions["can_validate"]:
       left_cards.append(home_action_card("Validate Classified Parts", "validation"))
   st.markdown(
       f"""
<div class="options-title">Options</div>
<div class="home-custom-layout">
<div class="home-custom-left">
       {_safe_card_html(left_cards)}
</div>
<div class="home-custom-divider"></div>
<div class="home-custom-right">
       {_safe_card_html(right_cards)}
</div>
</div>
       """,
       unsafe_allow_html=True,
   )