from state.session import set_navigation_state
from urllib.parse import urlencode
import streamlit as st
from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css, get_home_page_css

def home_action_card(label, page, sub=None):
  params = {"page": page}
  if sub is not None:
      params["sub"] = sub
  href = f"?{urlencode(params)}"
  return f'<a href="{href}" target="_self" class="home-action-card">{label}</a>'

def render():
  set_navigation_state(page="home", sub=None, run_id=None)
  load_css(get_global_css() + get_app_shell_css() + get_home_page_css())
  permissions = get_current_user_permissions()
  render_sidebar(subtitle="Home")
  render_top_nav(active_slug="home")
  left_cards = []
  right_cards = []
  if permissions["can_classify"]:
      left_cards.append(home_action_card("Classify Existing Parts", "classify_existing", "existing_parts"))
      st.markdown("************************")
      left_cards.append(home_action_card("Runs", "classify_existing", "runs"))
      right_cards.append(home_action_card("Create New Parts", "create_new_parts"))
  if permissions["can_validate"]:
      left_cards.insert(1, home_action_card("Validate Classified Parts", "validation"))
  st.markdown(
      f"""
<div class="options-title">Options</div>
<div class="home-custom-layout">
<div class="home-custom-left">
   {''.join(left_cards)}
</div>
<div class="home-custom-divider"></div>
<div class="home-custom-right">
   {''.join(right_cards)}
</div>
</div>
      """,
      unsafe_allow_html=True,
  )