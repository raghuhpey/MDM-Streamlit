import streamlit as st
from services.access_control_service import (
  has_admin_access,
  has_classify_access,
  has_retrain_access,
  has_super_admin_access,
  has_validate_access,
)
from state.session import (
  ensure_navigation_bootstrap,
  init_session_state,
  persist_navigation_in_browser,
  sync_navigation_state,
)
from ui.pages.home_page import render as render_home
from ui.pages.admin_page import render as render_admin
from ui.pages.classify_page import render as render_classify
from ui.pages.validation_page import render as render_validation
from ui.pages.retraining_page import render as render_retraining
from ui.pages.validation_report_page import render as render_validation_report
from ui.pages.about_page import render as render_about
from ui.pages.help_page import render as render_help
from ui.pages.super_admin_page import render as render_super_admin

st.set_page_config(
  page_title="AI-Parts Classifier",
  layout="wide"
)


def render_access_denied(message: str):
  st.markdown(
      f"""
<div style="
          max-width:900px;
          margin:80px auto;
          background:#ffffff;
          border:1px solid #e5e7eb;
          border-radius:18px;
          padding:28px 32px;
          box-shadow:0 10px 30px rgba(15,23,42,0.06);
      ">
<div style="font-size:24px; font-weight:800; color:#111827; margin-bottom:10px;">
              Access Denied
</div>
<div style="font-size:15px; color:#4b5563; line-height:1.7;">
              {message}
</div>
</div>
      """,
      unsafe_allow_html=True
  )


init_session_state()
ensure_navigation_bootstrap()
page, sub, run_id = sync_navigation_state()
persist_navigation_in_browser(page=page, sub=sub, run_id=run_id)

if page == "home":
  render_home()
elif page == "admin":
  if has_admin_access() or has_super_admin_access():
      render_admin()
  else:
      render_access_denied("You do not have access to Admin.")
elif page == "classify_existing":
  if has_classify_access():
      render_classify()
  else:
      render_access_denied("You do not have access to Classify Existing Parts.")
elif page == "create_new_parts":
  if has_classify_access():
      render_classify()
  else:
      render_access_denied("You do not have access to Create New Parts.")
elif page == "validation":
  if has_validate_access():
      render_validation()
  else:
      render_access_denied("You do not have access to Validate Classified Parts.")
elif page == "validation_report":
  render_access_denied("Validation Report has been moved to Super Admin → Run Report.")
elif page == "retraining":
  if has_retrain_access():
      render_retraining()
  else:
      render_access_denied("You do not have access to Model Retraining.")
elif page == "super_admin":
  if has_super_admin_access():
      render_super_admin()
  else:
      render_access_denied("You do not have access to Super Admin.")
elif page == "about":
  render_about()
elif page == "help":
  render_help()
else:
  render_home()
