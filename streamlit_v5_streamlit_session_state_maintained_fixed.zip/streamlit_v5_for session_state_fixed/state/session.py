import json
from urllib.parse import urlencode
import streamlit as st
import streamlit.components.v1 as components

ROUTE_STORAGE_KEY = "ai_parts_classifier_route_v3"


def _first(value, default=None):
    if isinstance(value, list):
        return value[0] if value else default
    return value if value not in (None, "") else default


def init_session_state():
    defaults = {
        "nav_page": "home",
        "nav_sub": None,
        "nav_run_id": None,
        "current_page": "Home",
        "current_flow": None,
        "prediction_output_df": None,
        "validation_df": None,
        "prediction_job_id": None,
        "validation_job_id": None,
        "prediction_status": None,
        "validation_status": None,
        "error_message": None,
        "success_message": None,
        "current_existing_run_id": None,
        "current_new_parts_run_id": None,
        "existing_parts_upload_signature": None,
        "new_parts_upload_signature": None,
        "route_bootstrap_complete": False,
        "route_last_synced": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _build_query_string(page=None, sub=None, run_id=None):
    params = {}
    if page:
        params["page"] = page
    if sub:
        params["sub"] = sub
    if run_id:
        params["run_id"] = run_id
    return urlencode(params)


def _write_navigation_to_query_params(page=None, sub=None, run_id=None):
    params = {}
    if page:
        params["page"] = page
    if sub:
        params["sub"] = sub
    if run_id:
        params["run_id"] = run_id

    for key in list(st.query_params.keys()):
        del st.query_params[key]
    for key, value in params.items():
        st.query_params[key] = value


def ensure_navigation_bootstrap():
    """On a hard browser refresh, restore the last route before the app renders Home.

    This intentionally stops the Streamlit script when there is no page query param,
    gives the browser a tiny bootstrap script, and lets the browser reload with the
    restored query string. That prevents the Home route from overwriting the saved
    route in localStorage on first load.
    """
    page = _first(st.query_params.get("page"))
    if page:
        st.session_state["route_bootstrap_complete"] = True
        return

    components.html(
        f"""
<script>
(function() {{
  try {{
    const key = {json.dumps(ROUTE_STORAGE_KEY)};
    const win = window.parent || window;
    const currentUrl = new URL(win.location.href);
    const currentQs = (currentUrl.search || '').replace(/^\?/, '');
    let saved = '';
    try {{ saved = win.localStorage.getItem(key) || ''; }} catch (e) {{}}
    if (!saved || !saved.includes('page=')) {{
      saved = 'page=home';
    }}
    if (currentQs !== saved) {{
      const target = currentUrl.pathname + '?' + saved + currentUrl.hash;
      win.location.replace(target);
      return;
    }}
  }} catch (e) {{}}
}})();
</script>
        """,
        height=0,
        width=0,
    )
    st.markdown(
        """
        <div style="padding:2rem 0; color:#4b5563; font-size:14px;">
            Restoring your last page...
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.stop()


def persist_navigation_in_browser(page=None, sub=None, run_id=None):
    qs = _build_query_string(page=page, sub=sub, run_id=run_id)
    qs_json = json.dumps(qs)
    components.html(
        f"""
<script>
(function() {{
  try {{
    const key = {json.dumps(ROUTE_STORAGE_KEY)};
    const qs = {qs_json};
    const win = window.parent || window;
    try {{ win.localStorage.setItem(key, qs); }} catch (e) {{}}
    const currentUrl = new URL(win.location.href);
    const currentQs = (currentUrl.search || '').replace(/^\?/, '');
    if (qs && currentQs !== qs) {{
      const target = currentUrl.pathname + '?' + qs + currentUrl.hash;
      win.history.replaceState({{}}, '', target);
    }}
  }} catch (e) {{}}
}})();
</script>
        """,
        height=0,
        width=0,
    )


def _hydrate_page_context(page, sub=None, run_id=None):
    page_map = {
        "home": "Home",
        "admin": "Admin",
        "classify_existing": "Classify Existing Parts",
        "create_new_parts": "Create New Parts",
        "validation": "Validate Classified Parts",
        "super_admin": "Super Admin",
        "about": "About",
        "help": "Help",
        "retraining": "Model Retraining",
    }
    st.session_state["current_page"] = page_map.get(page, "Home")
    st.session_state["current_flow"] = sub
    if page == "classify_existing":
        st.session_state["current_existing_run_id"] = run_id
    elif page == "create_new_parts":
        st.session_state["current_new_parts_run_id"] = run_id
    elif page == "validation":
        st.session_state["validation_job_id"] = run_id


def sync_navigation_state():
    page = _first(st.query_params.get("page"), st.session_state.get("nav_page", "home"))
    sub = _first(st.query_params.get("sub"), st.session_state.get("nav_sub"))
    run_id = _first(st.query_params.get("run_id"), st.session_state.get("nav_run_id"))

    st.session_state["nav_page"] = page or "home"
    st.session_state["nav_sub"] = sub
    st.session_state["nav_run_id"] = run_id
    _hydrate_page_context(st.session_state["nav_page"], st.session_state["nav_sub"], st.session_state["nav_run_id"])
    _write_navigation_to_query_params(
        page=st.session_state["nav_page"],
        sub=st.session_state["nav_sub"],
        run_id=st.session_state["nav_run_id"],
    )
    st.session_state["route_last_synced"] = _build_query_string(
        page=st.session_state["nav_page"],
        sub=st.session_state["nav_sub"],
        run_id=st.session_state["nav_run_id"],
    )
    return (
        st.session_state["nav_page"],
        st.session_state["nav_sub"],
        st.session_state["nav_run_id"],
    )


def set_navigation_state(page, sub=None, run_id=None):
    st.session_state["nav_page"] = page
    st.session_state["nav_sub"] = sub
    st.session_state["nav_run_id"] = run_id
    _hydrate_page_context(page, sub, run_id)
    _write_navigation_to_query_params(page=page, sub=sub, run_id=run_id)
    st.session_state["route_last_synced"] = _build_query_string(page=page, sub=sub, run_id=run_id)
