import streamlit as st

def init_session_state():
   defaults = {
       "current_page": "Home",
       "current_flow": None,
       "prediction_output_df": None,
       "validation_df": None,
       "prediction_job_id": None,
       "validation_job_id": None,
       "prediction_status": None,
       "validation_status": None,
       "error_message": None,
       "success_message": None,
       "current_existing_run_id": None,
       "current_new_parts_run_id": None,
       "existing_parts_upload_signature": None,
       "new_parts_upload_signature": None,
   }
   for key, value in defaults.items():
       if key not in st.session_state:
           st.session_state[key] = value