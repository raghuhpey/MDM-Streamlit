import dataiku
from services.classification_table_service import mark_run_submitted
PROJECT_KEY = "MDM_PARTS_CLASSIFICATION"
SCENARIO_ID = "RUN_PREDICTION_JOB"

def trigger_prediction_scenario(run_id: str):
   client = dataiku.api_client()
   project = client.get_project(PROJECT_KEY)
   scenario = project.get_scenario(SCENARIO_ID)
   trigger_fire = scenario.run(params={
       "run_id": run_id
   })
   raw = trigger_fire.get_raw()
   trigger_fire_id = raw.get("runId")
   mark_run_submitted(
       run_id,
       backend_trigger_id=trigger_fire_id,
   )
   return {
       "trigger_fire_id": trigger_fire_id,
       "raw": raw,
   }