import dataiku
import pandas as pd
CLASSIFICATION_DATASET_NAME = "MDM_classification_tbl"
OUTPUT_COLUMNS = [
   "model_1_op",
   "model_2_op",
   "model_3_op",
   "llm_judge_op",
   "llm_decision_source",
   "explanation",
]

def _safe_text(value, default=""):
   if pd.isna(value) or value is None:
       return default
   value = str(value).strip()
   return value if value else default

def _normalize_code(value):
   if pd.isna(value) or value is None:
       return ""
   return str(value).strip().replace(".0", "")

def _first_non_empty(row, candidates):
   for col in candidates:
       if col in row.index:
           val = row.get(col)
           if pd.notna(val) and str(val).strip():
               return str(val).strip()
   return ""

def _normalize_validation_status(value):
   if pd.isna(value) or value is None or str(value).strip() == "":
       return "pending"
   return str(value).strip().lower()

def fetch_run_report_df() -> pd.DataFrame:
   ds = dataiku.Dataset(CLASSIFICATION_DATASET_NAME)
   df = ds.get_dataframe()
   expected_columns = [
       "Run ID",
       "File Name",
       "Short Description",
       "Model 1 OP",
       "Model 2 OP",
       "Model 3 OP",
       "LLM Judge OP",
       "LLM Decision Source",
       "Explanation",
       "Validated UNSPSC",
       "Validated By",
       "Validated At",
       "Validation Status",
   ]
   if df.empty:
       return pd.DataFrame(columns=expected_columns)
   for col in OUTPUT_COLUMNS:
       if col not in df.columns:
           df[col] = None
   if "validation_status" not in df.columns:
       df["validation_status"] = "pending"
   if "validated_unspsc" not in df.columns:
       df["validated_unspsc"] = None
   if "validated_by" not in df.columns:
       df["validated_by"] = None
   if "validated_at" not in df.columns:
       df["validated_at"] = None
   report_records = []
   for _, row in df.iterrows():
       short_desc = _first_non_empty(
           row,
           [
               "short_descrition_(english)",
               "short_description_(english)",
               "Short Description (English)",
               "Short Description",
           ],
       )
       report_records.append(
           {
               "Run ID": _safe_text(row.get("run_id")),
               "File Name": _safe_text(row.get("file_name")),
               "Short Description": short_desc,
               "Model 1 OP": _normalize_code(row.get("model_1_op")),
               "Model 2 OP": _normalize_code(row.get("model_2_op")),
               "Model 3 OP": _normalize_code(row.get("model_3_op")),
               "LLM Judge OP": _normalize_code(row.get("llm_judge_op")),
               "LLM Decision Source": _safe_text(row.get("llm_decision_source")),
               "Explanation": _safe_text(row.get("explanation")),
               "Validated UNSPSC": _normalize_code(row.get("validated_unspsc")),
               "Validated By": _safe_text(row.get("validated_by")),
               "Validated At": _safe_text(row.get("validated_at")),
               "Validation Status": _normalize_validation_status(row.get("validation_status")),
           }
       )
   report_df = pd.DataFrame(report_records)
   if not report_df.empty:
       report_df["_sort_ts"] = pd.to_datetime(
           report_df["Validated At"].replace("", None),
           errors="coerce",
           utc=True
       )
       report_df = (
           report_df.sort_values(by=["_sort_ts", "Run ID"], ascending=[False, False])
           .drop(columns=["_sort_ts"])
           .reset_index(drop=True)
       )
   return report_df