import dataiku
import pandas as pd

CLASSIFICATION_DATASET_NAME = "MDM_classification_tbl"

def _to_bool(value):
   if pd.isna(value) or value is None:
       return False
   if isinstance(value, bool):
       return value
   if isinstance(value, (int, float)):
       return value == 1
   return str(value).strip().lower() in {"1", "true", "yes", "y", "t"}

def fetch_validation_report_df():
   ds = dataiku.Dataset(CLASSIFICATION_DATASET_NAME)
   df = ds.get_dataframe()
   if df.empty or "run_id" not in df.columns:
       return pd.DataFrame(
           columns=[
               "Run ID",
               "Pending Records",
               "Total Records",
               "Approved Records",
               "Classified By",
               "Current Status",
               "Last Updated",
               "Updated By",
           ]
       )
   work_df = df.copy()
   if "validation_status" not in work_df.columns:
       work_df["validation_status"] = "pending"
   if "is_golden_record" not in work_df.columns:
       work_df["is_golden_record"] = False
   work_df["_validation_status_norm"] = (
       work_df["validation_status"]
       .fillna("pending")
       .astype(str)
       .str.strip()
       .str.lower()
   )
   work_df["_is_approved"] = (
       (work_df["_validation_status_norm"] == "approved")
       | work_df["is_golden_record"].apply(_to_bool)
   )
   records = []
   for run_id, grp in work_df.groupby("run_id", dropna=False):
       total_records = int(len(grp))
       approved_records = int(grp["_is_approved"].sum())
       pending_records = total_records - approved_records
       if pending_records == 0:
           current_status = "completed"
       elif approved_records == 0:
           current_status = "pending"
       else:
           current_status = "in_progress"
       classified_by = str(grp["uploaded_by"].iloc[0]).strip() if "uploaded_by" in grp.columns else ""
       updated_by = ""
       if "validated_by" in grp.columns:
           validated_by_series = grp["validated_by"].dropna()
           if not validated_by_series.empty:
               updated_by = str(validated_by_series.iloc[-1]).strip()
       if not updated_by and "uploaded_by" in grp.columns:
           updated_by = str(grp["uploaded_by"].iloc[0]).strip()
       last_updated = ""
       for col in ["validated_at", "updated_ts", "uploaded_ts"]:
           if col in grp.columns:
               series = grp[col].dropna()
               if not series.empty:
                   last_updated = str(series.iloc[-1]).strip()
                   break
       records.append(
           {
               "Run ID": str(run_id),
               "Pending Records": pending_records,
               "Total Records": total_records,
               "Approved Records": approved_records,
               "Classified By": classified_by,
               "Current Status": current_status,
               "Last Updated": last_updated,
               "Updated By": updated_by,
           }
       )
   out_df = pd.DataFrame(records)
   if not out_df.empty:
       out_df = out_df.sort_values(by="Last Updated", ascending=False).reset_index(drop=True)
   return out_df