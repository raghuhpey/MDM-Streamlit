import uuid
from datetime import datetime, timezone
from typing import Any
import dataiku
import pandas as pd
from dataiku import SQLExecutor2
from services.run_storage_service import get_current_user_login
USER_ACCESS_DATASET_NAME = "MDM_user_access_tbl"
USER_ACCESS_AUDIT_DATASET_NAME = "MDM_user_access_audit_tbl"

def _utc_now_string() -> str:
   return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

def _quote_identifier(identifier: str) -> str:
   return f'"{identifier}"'

def _sql_escape(value: Any) -> str:
   if pd.isna(value) or value is None:
       return "NULL"
   if isinstance(value, bool):
       return "TRUE" if value else "FALSE"
   s = str(value).replace("'", "''")
   return f"'{s}'"

def _dataset(dataset_name: str):
   return dataiku.Dataset(dataset_name)

def _dataset_df(dataset_name: str) -> pd.DataFrame:
   return _dataset(dataset_name).get_dataframe()

def _dataset_sql_info(dataset_name: str) -> dict:
   ds = _dataset(dataset_name)
   loc = ds.get_location_info()
   info = loc.get("info", {})
   connection_name = info.get("connectionName")
   quoted_table_name = info.get("quotedResolvedTableName")
   if not connection_name or not quoted_table_name:
       raise ValueError(f"Could not resolve SQL info for dataset: {dataset_name}")
   return {
       "dataset": ds,
       "connection_name": connection_name,
       "quoted_table_name": quoted_table_name,
       "project_key": ds.project_key,
   }

def _run_sql(dataset_name: str, sql: str):
   info = _dataset_sql_info(dataset_name)
   client = dataiku.api_client()
   query = client.sql_query(
       sql,
       connection=info["connection_name"],
       type="sql",
       project_key=info["project_key"],
       post_queries=["COMMIT"],
   )
   query.verify()

def _query_to_df(dataset_name: str, sql: str) -> pd.DataFrame:
   ds = _dataset(dataset_name)
   executor = SQLExecutor2(dataset=ds)
   return executor.query_to_df(sql)

def _normalize_role(value: Any) -> str:
   if pd.isna(value) or value is None:
       return "user"
   role = str(value).strip().lower()
   if role not in {"user", "admin", "super_admin"}:
       return "user"
   return role

def _to_bool(value: Any) -> bool:
   if pd.isna(value) or value is None:
       return False
   if isinstance(value, bool):
       return value
   if isinstance(value, (int, float)):
       return value == 1
   return str(value).strip().lower() in {"1", "true", "yes", "y", "t"}

def fetch_user_access_df() -> pd.DataFrame:
   df = _dataset_df(USER_ACCESS_DATASET_NAME)
   if df.empty:
       return pd.DataFrame(
           columns=[
               "user_id",
               "role",
               "is_active",
               "updated_by",
               "updated_at",
           ]
       )
   df.columns = [str(c).strip() for c in df.columns]
   if "role" not in df.columns:
       df["role"] = "user"
   else:
       df["role"] = df["role"].apply(_normalize_role)
   if "is_active" not in df.columns:
       df["is_active"] = True
   else:
       df["is_active"] = df["is_active"].apply(_to_bool)
   if "updated_by" not in df.columns:
       df["updated_by"] = None
   if "updated_at" not in df.columns:
       df["updated_at"] = None
   df["user_id"] = df["user_id"].astype(str).str.strip()
   df = df.sort_values(by="user_id", ascending=True).reset_index(drop=True)
   return df[["user_id", "role", "is_active", "updated_by", "updated_at"]]

def fetch_user_access_audit_df() -> pd.DataFrame:
   info = _dataset_sql_info(USER_ACCESS_AUDIT_DATASET_NAME)
   sql = f"""
   SELECT
       "audit_id",
       "user_id",
       "action_type",
       "old_role",
       "new_role",
       "old_is_active",
       "new_is_active",
       "changed_by",
       "changed_at"
   FROM {info['quoted_table_name']}
   """
   df = _query_to_df(USER_ACCESS_AUDIT_DATASET_NAME, sql)
   expected_cols = [
       "audit_id",
       "user_id",
       "action_type",
       "old_role",
       "new_role",
       "old_is_active",
       "new_is_active",
       "changed_by",
       "changed_at",
   ]
   if df.empty:
       return pd.DataFrame(columns=expected_cols)
   df.columns = [str(c).strip() for c in df.columns]
   for col in expected_cols:
       if col not in df.columns:
           df[col] = None
   for col in ["old_is_active", "new_is_active"]:
       df[col] = df[col].apply(_to_bool)
   df["old_role"] = df["old_role"].fillna("-").astype(str).str.strip()
   df["new_role"] = df["new_role"].fillna("-").astype(str).str.strip()
   df["action_type"] = df["action_type"].fillna("-").astype(str).str.strip()
   df["user_id"] = df["user_id"].fillna("-").astype(str).str.strip()
   df["changed_by"] = df["changed_by"].fillna("-").astype(str).str.strip()
   df["changed_at"] = df["changed_at"].fillna("-").astype(str).str.strip()
   sort_ts = pd.to_datetime(
       df["changed_at"].replace("-", None),
       errors="coerce",
       utc=True
   )
   df["_sort_ts"] = sort_ts
   df = df.sort_values(by="_sort_ts", ascending=False).drop(columns=["_sort_ts"])
   return df[expected_cols].reset_index(drop=True)

def fetch_user_access_record(user_id: str) -> dict | None:
   df = fetch_user_access_df()
   if df.empty:
       return None
   match = df[df["user_id"].astype(str).str.strip().str.lower() == str(user_id).strip().lower()]
   if match.empty:
       return None
   row = match.iloc[0]
   return {
       "user_id": str(row["user_id"]).strip(),
       "role": _normalize_role(row["role"]),
       "is_active": _to_bool(row["is_active"]),
       "updated_by": row.get("updated_by"),
       "updated_at": row.get("updated_at"),
   }

def _insert_user_access_audit_row(
   user_id: str,
   action_type: str,
   old_row: dict | None,
   new_row: dict,
   changed_by: str,
   changed_at: str,
):
   audit_id = str(uuid.uuid4())
   old_row = old_row or {}
   sql = f"""
   INSERT INTO {_dataset_sql_info(USER_ACCESS_AUDIT_DATASET_NAME)['quoted_table_name']} (
       "audit_id",
       "user_id",
       "action_type",
       "old_role",
       "new_role",
       "old_is_active",
       "new_is_active",
       "changed_by",
       "changed_at"
   )
   VALUES (
       {_sql_escape(audit_id)},
       {_sql_escape(user_id)},
       {_sql_escape(action_type)},
       {_sql_escape(old_row.get("role"))},
       {_sql_escape(new_row.get("role"))},
       {_sql_escape(old_row.get("is_active"))},
       {_sql_escape(new_row.get("is_active"))},
       {_sql_escape(changed_by)},
       {_sql_escape(changed_at)}
   )
   """
   _run_sql(USER_ACCESS_AUDIT_DATASET_NAME, sql)

def upsert_user_access_role_record(user_id: str, role: str, is_active: bool):
   user_id = str(user_id).strip()
   if not user_id:
       raise ValueError("User ID is required.")
   role = _normalize_role(role)
   changed_by = get_current_user_login()
   changed_at = _utc_now_string()
   existing = fetch_user_access_record(user_id)
   info = _dataset_sql_info(USER_ACCESS_DATASET_NAME)
   new_row = {
       "user_id": user_id,
       "role": role,
       "is_active": bool(is_active),
       "updated_by": changed_by,
       "updated_at": changed_at,
   }
   if existing is None:
       sql = f"""
       INSERT INTO {info['quoted_table_name']} (
           "user_id",
           "role",
           "is_active",
           "updated_by",
           "updated_at"
       )
       VALUES (
           {_sql_escape(user_id)},
           {_sql_escape(role)},
           {_sql_escape(bool(is_active))},
           {_sql_escape(changed_by)},
           {_sql_escape(changed_at)}
       )
       """
       _run_sql(USER_ACCESS_DATASET_NAME, sql)
       _insert_user_access_audit_row(user_id, "CREATE", None, new_row, changed_by, changed_at)
   else:
       sql = f"""
       UPDATE {info['quoted_table_name']}
       SET
           "role" = {_sql_escape(role)},
           "is_active" = {_sql_escape(bool(is_active))},
           "updated_by" = {_sql_escape(changed_by)},
           "updated_at" = {_sql_escape(changed_at)}
       WHERE LOWER(TRIM("user_id")) = LOWER(TRIM({_sql_escape(user_id)}))
       """
       _run_sql(USER_ACCESS_DATASET_NAME, sql)
       _insert_user_access_audit_row(user_id, "UPDATE", existing, new_row, changed_by, changed_at)
