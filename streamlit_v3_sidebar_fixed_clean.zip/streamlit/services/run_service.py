from datetime import datetime
from uuid import uuid4

def generate_prediction_run_id(prefix="pred"):
   timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
   return f"{prefix}_{timestamp}_{uuid4().hex[:8]}"

def build_run_record(prediction_run_id, run_type, file_name, input_df, created_by):
   return {
       "prediction_run_id": prediction_run_id,
       "run_type": run_type,
       "file_name": file_name,
       "input_df": input_df.copy(),
       "output_df": None,
       "status": "uploaded",
       "created_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
       "created_by": created_by,
       "row_count": len(input_df),
       "backend_job_id": None,
       "error_message": None,
   }