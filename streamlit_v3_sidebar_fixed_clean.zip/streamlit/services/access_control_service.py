import dataiku
import pandas as pd
from services.run_storage_service import get_current_user_login
ACCESS_DATASET_NAME = "MDM_user_access_tbl"
DEFAULT_ACCESS = {
   "role": "user",
   "is_active": False,
}

def get_access_dataset():
   return dataiku.Dataset(ACCESS_DATASET_NAME)

def _normalize_user_id(value) -> str:
   if pd.isna(value) or value is None:
       return ""
   s = str(value).strip()
   if s.endswith(".0"):
       s = s[:-2]
   return s.lower()

def _normalize_role(value) -> str:
   if pd.isna(value) or value is None:
       return "user"
   s = str(value).strip().lower()
   if s in {"super_admin", "admin", "user"}:
       return s
   return "user"

def _to_bool(value) -> bool:
   if pd.isna(value) or value is None:
       return False
   if isinstance(value, bool):
       return value
   if isinstance(value, (int, float)):
       return value == 1
   return str(value).strip().lower() in {"1", "true", "yes", "y", "t"}

def get_user_access_record(user_id: str | None = None) -> dict:
   user_id = user_id or get_current_user_login()
   try:
       ds = get_access_dataset()
       df = ds.get_dataframe()
   except Exception:
       return DEFAULT_ACCESS.copy()
   if df.empty:
       return DEFAULT_ACCESS.copy()
   df.columns = [str(c).strip() for c in df.columns]
   if "user_id" not in df.columns:
       return DEFAULT_ACCESS.copy()
   current_user_norm = _normalize_user_id(user_id)
   if not current_user_norm:
       return DEFAULT_ACCESS.copy()
   work_df = df.copy()
   work_df["user_id"] = work_df["user_id"].apply(_normalize_user_id)
   match = work_df[work_df["user_id"] == current_user_norm]
   if match.empty:
       return DEFAULT_ACCESS.copy()
   row = match.iloc[0]
   return {
       "role": _normalize_role(row.get("role")),
       "is_active": _to_bool(row.get("is_active")),
   }

def get_current_user_role(user_id: str | None = None) -> str:
   record = get_user_access_record(user_id)
   return record["role"] if record["is_active"] else "inactive"

def get_current_user_permissions(user_id: str | None = None) -> dict:
   role = get_current_user_role(user_id)
   permissions = {
       "role": role,
       "is_active": role != "inactive",
       "can_classify": False,
       "can_validate": False,
       "can_retrain": False,
       "can_admin": False,
       "can_super_admin": False,
   }
   if role == "user":
       permissions["can_classify"] = True
   elif role == "admin":
       permissions["can_classify"] = True
       permissions["can_validate"] = True
       permissions["can_retrain"] = True
       permissions["can_admin"] = True
   elif role == "super_admin":
       permissions["can_classify"] = True
       permissions["can_validate"] = True
       permissions["can_retrain"] = True
       permissions["can_admin"] = True
       permissions["can_super_admin"] = True
   return permissions

def has_classify_access(user_id: str | None = None) -> bool:
   return get_current_user_permissions(user_id)["can_classify"]

def has_validate_access(user_id: str | None = None) -> bool:
   return get_current_user_permissions(user_id)["can_validate"]

def has_retrain_access(user_id: str | None = None) -> bool:
   return get_current_user_permissions(user_id)["can_retrain"]

def has_admin_access(user_id: str | None = None) -> bool:
   return get_current_user_permissions(user_id)["can_admin"]

def has_super_admin_access(user_id: str | None = None) -> bool:
   return get_current_user_permissions(user_id)["can_super_admin"]

def get_current_user_access_debug() -> dict:
   current_user = get_current_user_login()
   return {
       "current_user_login": current_user,
       "normalized_current_user": _normalize_user_id(current_user),
       "access_record": get_user_access_record(current_user),
       "permissions": get_current_user_permissions(current_user),
   }