from __future__ import annotations
import json
from io import BytesIO
from typing import Optional
import pandas as pd
from services.run_storage_service import (
   dataframe_to_parquet_bytes,
   get_current_user_login,
   get_managed_folder,
   list_runs,
   load_output_df,
   load_run_metadata,
   parquet_bytes_to_dataframe,
)
VALIDATION_DIR_NAME = "validation"
GOLDEN_DATASET_PATH = "golden_dataset/golden_dataset.parquet"

def _normalize_path(path: str) -> str:
   return path.lstrip("/") if path else path

def _with_leading_slash(path: str) -> str:
   return f"/{_normalize_path(path)}"

def _candidate_paths(path: str):
   normalized = _normalize_path(path)
   return [normalized, f"/{normalized}"]

def _path_exists(folder, path: str) -> bool:
   for candidate in _candidate_paths(path):
       try:
           details = folder.get_path_details(candidate)
           if details.get("exists", False):
               return True
       except Exception:
           continue
   return False

def _read_json(folder, path: str):
   for candidate in _candidate_paths(path):
       try:
           details = folder.get_path_details(candidate)
           if details.get("exists", False):
               return folder.read_json(candidate)
       except Exception:
           continue
   return None

def _write_json(folder, path: str, payload: dict):
   folder.write_json(_with_leading_slash(path), payload)

def _read_parquet_df(folder, path: str) -> Optional[pd.DataFrame]:
   for candidate in _candidate_paths(path):
       try:
           details = folder.get_path_details(candidate)
           if details.get("exists", False):
               with folder.get_download_stream(candidate) as stream:
                   return parquet_bytes_to_dataframe(stream.read())
       except Exception:
           continue
   return None

def _write_parquet_df(folder, path: str, df: pd.DataFrame):
   folder.upload_data(_with_leading_slash(path), dataframe_to_parquet_bytes(df))

def _run_validation_dir(run_id: str) -> str:
   return f"runs/{run_id}/{VALIDATION_DIR_NAME}"

def _validation_queue_path(run_id: str) -> str:
   return f"{_run_validation_dir(run_id)}/validation_queue.parquet"

def _validation_metadata_path(run_id: str) -> str:
   return f"{_run_validation_dir(run_id)}/validation_metadata.json"

def _approved_archive_path(run_id: str) -> str:
   return f"{_run_validation_dir(run_id)}/approved_archive.parquet"

def _utc_now_strings():
   from datetime import datetime, timezone
   now = datetime.now(timezone.utc)
   return {
       "display": now.strftime("%Y-%m-%d %H:%M:%S UTC"),
       "epoch_ms": int(now.timestamp() * 1000),
   }

def _derive_validation_status(approved_rows: int, total_rows: int) -> str:
   if total_rows <= 0:
       return "completed"
   if approved_rows <= 0:
       return "pending"
   if approved_rows >= total_rows:
       return "completed"
   return "in_progress"

def load_validation_metadata(run_id: str):
   folder = get_managed_folder()
   return _read_json(folder, _validation_metadata_path(run_id))

def load_validation_queue_df(run_id: str) -> Optional[pd.DataFrame]:
   folder = get_managed_folder()
   return _read_parquet_df(folder, _validation_queue_path(run_id))

def load_approved_archive_df(run_id: str) -> pd.DataFrame:
   folder = get_managed_folder()
   df = _read_parquet_df(folder, _approved_archive_path(run_id))
   if df is None:
       return pd.DataFrame()
   return df

def load_golden_dataset_df() -> pd.DataFrame:
   folder = get_managed_folder()
   df = _read_parquet_df(folder, GOLDEN_DATASET_PATH)
   if df is None:
       return pd.DataFrame()
   return df

def save_validation_queue_df(run_id: str, df: pd.DataFrame):
   folder = get_managed_folder()
   _write_parquet_df(folder, _validation_queue_path(run_id), df)

def save_approved_archive_df(run_id: str, df: pd.DataFrame):
   folder = get_managed_folder()
   _write_parquet_df(folder, _approved_archive_path(run_id), df)

def save_golden_dataset_df(df: pd.DataFrame):
   folder = get_managed_folder()
   _write_parquet_df(folder, GOLDEN_DATASET_PATH, df)

def upsert_validation_metadata(run_id: str, updates: dict):
   folder = get_managed_folder()
   existing = load_validation_metadata(run_id) or {}
   payload = {**existing, **updates}
   now = _utc_now_strings()
   payload["updated_at"] = now["display"]
   payload["updated_at_epoch_ms"] = now["epoch_ms"]
   _write_json(folder, _validation_metadata_path(run_id), payload)
   return payload

def ensure_validation_run(run_id: str):
   run_meta = load_run_metadata(run_id)
   if run_meta is None:
       raise ValueError(f"Prediction run not found: {run_id}")
   if str(run_meta.get("status", "")).lower() != "completed":
       raise ValueError("Validation is allowed only for prediction runs with status='completed'.")
   existing_meta = load_validation_metadata(run_id)
   if existing_meta is not None:
       return existing_meta
   prediction_output_df = load_output_df(run_id)
   if prediction_output_df is None or prediction_output_df.empty:
       raise ValueError(f"Prediction output not found for run: {run_id}")
   queue_df = prediction_output_df.copy().reset_index(drop=True)
   queue_df["_validation_row_id"] = range(1, len(queue_df) + 1)
   queue_df["Validated UNSPSC"] = queue_df.get("LLM as a Judge OP", None)
   queue_df["Validation Decision Source"] = "LLM Judge"
   queue_df["Validation Comment"] = ""
   queue_df["Validation Status"] = "Pending"
   queue_df["Validated By"] = ""
   queue_df["Validated At"] = ""
   save_validation_queue_df(run_id, queue_df)
   save_approved_archive_df(run_id, pd.DataFrame())
   created = _utc_now_strings()
   metadata = {
       "prediction_job_id": run_id,
       "prediction_created_by": run_meta.get("created_by"),
       "file_name": run_meta.get("file_name"),
       "total_rows": int(len(queue_df)),
       "approved_rows": 0,
       "remaining_rows": int(len(queue_df)),
       "status": "pending",
       "created_at": created["display"],
       "created_at_epoch_ms": created["epoch_ms"],
       "updated_at": created["display"],
       "updated_at_epoch_ms": created["epoch_ms"],
       "updated_by": run_meta.get("created_by"),
   }
   return upsert_validation_metadata(run_id, metadata)

def list_runs_to_validate():
   prediction_runs = list_runs()
   rows = []
   for run in prediction_runs:
       if str(run.get("run_type", "")) != "classify_existing_parts":
           continue
       if str(run.get("status", "")).lower() != "completed":
           continue
       run_id = run["prediction_job_id"]
       vmeta = load_validation_metadata(run_id)
       total_rows = int(run.get("row_count", 0))
       approved_rows = int(vmeta.get("approved_rows", 0)) if vmeta else 0
       status = vmeta.get("status", "pending") if vmeta else "pending"
       last_updated = vmeta.get("updated_at", run.get("updated_at", run.get("created_at"))) if vmeta else run.get("updated_at", run.get("created_at"))
       updated_by = vmeta.get("updated_by", run.get("created_by")) if vmeta else run.get("created_by")
       if approved_rows >= total_rows and total_rows > 0:
           continue
       rows.append(
           {
               "Prediction Job": run_id,
               "Prediction Created By": run.get("created_by"),
               "Approved Rows": f"{approved_rows}/{total_rows}",
               "Status": status,
               "Last Updated": last_updated,
               "Updated By": updated_by,
               "prediction_job_id": run_id,
           }
       )
   rows.sort(key=lambda x: x["Last Updated"] or "", reverse=True)
   return rows

def approve_validation_row(
   run_id: str,
   validation_row_id: int,
   validated_unspsc: str,
   validation_source: str,
   validation_comment: str = "",
):
   queue_df = load_validation_queue_df(run_id)
   if queue_df is None or queue_df.empty:
       raise ValueError("No validation queue available for this run.")
   row_mask = queue_df["_validation_row_id"] == validation_row_id
   if not row_mask.any():
       raise ValueError(f"Validation row not found: {validation_row_id}")
   now = _utc_now_strings()
   current_user = get_current_user_login()
   run_meta = load_run_metadata(run_id)
   approved_row = queue_df.loc[row_mask].copy()
   approved_row["Validated UNSPSC"] = validated_unspsc
   approved_row["Validation Decision Source"] = validation_source
   approved_row["Validation Comment"] = validation_comment or ""
   approved_row["Validation Status"] = "Approved"
   approved_row["Validated By"] = current_user
   approved_row["Validated At"] = now["display"]
   approved_row["Prediction Job ID"] = run_id
   approved_row["Prediction Created By"] = run_meta.get("created_by") if run_meta else None
   remaining_queue_df = queue_df.loc[~row_mask].copy().reset_index(drop=True)
   save_validation_queue_df(run_id, remaining_queue_df)
   archive_df = load_approved_archive_df(run_id)
   if archive_df.empty:
       updated_archive_df = approved_row.reset_index(drop=True)
   else:
       updated_archive_df = pd.concat(
           [archive_df, approved_row.reset_index(drop=True)],
           ignore_index=True,
           sort=False,
       )
   save_approved_archive_df(run_id, updated_archive_df)
   golden_df = load_golden_dataset_df()
   if golden_df.empty:
       updated_golden_df = approved_row.reset_index(drop=True)
   else:
       updated_golden_df = pd.concat(
           [golden_df, approved_row.reset_index(drop=True)],
           ignore_index=True,
           sort=False,
       )
   save_golden_dataset_df(updated_golden_df)
   total_rows = int(load_validation_metadata(run_id).get("total_rows", len(updated_archive_df)))
   approved_rows = int(len(updated_archive_df))
   remaining_rows = int(len(remaining_queue_df))
   status = _derive_validation_status(approved_rows, total_rows)
   vmeta = upsert_validation_metadata(
       run_id,
       {
           "approved_rows": approved_rows,
           "remaining_rows": remaining_rows,
           "status": status,
           "updated_by": current_user,
           "last_approved_at": now["display"],
       },
   )
   return vmeta