# import pandas as pd
# from services.prediction_resources import load_prediction_resources
# from services.prediction_engine import predict_dataframe
# # use a very small sample first
# df = pd.read_csv("/home/dataiku/workspace/code_studio-versioned/streamlit/Predict_test.csv", encoding='cp1252').head(5)
# print("Columns: ", df.columns)
# resources = load_prediction_resources()
# out_df = predict_dataframe(df, resources, max_workers=2)
# print("Input shape:", df.shape)
# print("Output shape:", out_df.shape)
# print(out_df.head())
# print(out_df.columns.tolist())


# from services.prediction_service import run_prediction_job
# from services.run_storage_service import load_run_metadata, load_output_df
# prediction_job_id = "pred_Predict_test_20260322160011_870a"
# print("Before:")
# print(load_run_metadata(prediction_job_id))
# run_prediction_job(prediction_job_id, max_workers=2)
# print("After:")
# print(load_run_metadata(prediction_job_id))
# out_df = load_output_df(prediction_job_id)
# print(out_df.shape)
# print(out_df.columns.tolist())
# print(out_df.head())

import dataiku
DATASET_NAME = "mdm_user_access_tbl"   # replace only if your DSS dataset name differs
ds = dataiku.Dataset(DATASET_NAME)
df = ds.get_dataframe(limit=5)
print("Rows fetched:", len(df))
print("Columns:", list(df.columns))
print(df.head())

# import dataiku
# import pandas as pd
# DATASET_NAME = "MDM_classification_tbl_test_write"
# ds = dataiku.Dataset(DATASET_NAME)
# test_df = pd.DataFrame([
#    {
#        "run_id": "test_run_001",
#        "file_name": "test_file.csv",
#        "uploaded_by": "test_user",
#        "run_status": "uploaded"
#    }
# ])
# ds.write_with_schema(test_df)
# print("Write test completed")