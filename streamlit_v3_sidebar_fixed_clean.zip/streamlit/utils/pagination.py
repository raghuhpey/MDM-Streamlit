import math

def get_total_pages(total_rows, page_size):
   if page_size <= 0:
       return 1
   return max(1, math.ceil(total_rows / page_size))

def get_page_bounds(current_page, page_size, total_rows):
   start_idx = (current_page - 1) * page_size
   end_idx = min(start_idx + page_size, total_rows)
   return start_idx, end_idx

def get_page_df(df, current_page, page_size):
   start_idx, end_idx = get_page_bounds(current_page, page_size, len(df))
   return df.iloc[start_idx:end_idx].reset_index(drop=True)

def get_visible_page_numbers(current_page, total_pages, window=5):
   if total_pages <= window:
       return list(range(1, total_pages + 1))
   half = window // 2
   start = max(1, current_page - half)
   end = min(total_pages, start + window - 1)
   start = max(1, end - window + 1)
   return list(range(start, end + 1))