from services.access_control_service import get_current_user_permissions

def get_visible_top_nav_items():
   permissions = get_current_user_permissions()
   items = [("🏠 Home", "home")]
   if permissions["can_admin"]:
       items.append(("🔒 Admin", "admin"))
   if permissions["can_super_admin"]:
       items.append(("🛡️ Super Admin", "super_admin"))
   items.extend([
       ("ℹ️ About", "about"),
       ("❓ Help", "help"),
   ])
   return items

def get_visible_home_options():
   permissions = get_current_user_permissions()
   items = []
   if permissions["can_classify"]:
       items.append(("Classify Existing Parts", "classify_existing"))
       items.append(("Create New Parts", "create_new_parts"))
   if permissions["can_validate"]:
       items.append(("Validate Classified Parts", "validation"))
   return items

def get_visible_admin_options():
   permissions = get_current_user_permissions()
   items = []
   if permissions["can_retrain"]:
       items.append(("Model Retraining", "retraining"))
   return items
