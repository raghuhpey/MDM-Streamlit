import streamlit as st

from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)


def option_card(label: str, target_page: str, disabled: bool = False) -> str:
   if disabled:
       return f"""
<div class="option-card-wrap-disabled">
<div class="option-card disabled">{label}</div>
</div>
       """
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{target_page}">
<button type="submit" class="option-card">{label}</button>
</form>
   """


def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css() + get_classify_page_css())
   permissions = get_current_user_permissions()

   render_sidebar(subtitle="Admin")
   render_top_nav(active_slug="admin")

   st.markdown(
       """
<div class="section-card">
<div class="section-card-title">Admin</div>
<div class="section-card-subtitle">
   Choose an administrative function.
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   st.markdown(
       f"""
<div style="margin-top:18px; max-width:460px;">
   {option_card("Model Retraining", "retraining", disabled=not permissions["can_retrain"])}
</div>
       """,
       unsafe_allow_html=True
   )
