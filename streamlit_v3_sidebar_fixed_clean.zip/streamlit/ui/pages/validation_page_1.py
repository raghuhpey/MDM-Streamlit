import dataiku
import io
import base64
import pandas as pd
import streamlit as st
from services.validation_storage_service import (
   approve_validation_row,
   ensure_validation_run,
   list_runs_to_validate,
   load_golden_dataset_df,
   load_validation_metadata,
   load_validation_queue_df,
)
from utils.pagination import get_page_bounds, get_page_df, get_total_pages
from utils.styles import (
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   get_validation_page_css,
   load_css,
)

FOLDER_ID = "MDM_application"
UNSPSC_LOOKUP_PATH = "reference/unspsc_code_description.csv"
UNSPSC_CODE_COL = "unspsc_code"
UNSPSC_DESC_COL = "unspsc_description"
folder = dataiku.Folder(FOLDER_ID)

TOP_REVIEW_COLUMNS = {
   "Short Description (English)",
   "Short Description",
   "Explanation",
   "Model 1 OP",
   "Model 2 OP",
   "Model 3 OP",
   "LLM as a Judge OP",
   "LLM Decision Source",
   "Validated UNSPSC",
   "Validation Decision Source",
   "Validation Comment",
   "Validation Status",
   "Validated By",
   "Validated At",
   "_validation_row_id",
   "Prediction Job ID",
   "Prediction Created By",
}

def get_base64_image(image_path):
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label, slug, active=False):
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def left_menu_btn(label, sub_value, active=False):
   css_class = "left-menu-btn active" if active else "left-menu-btn"
   return f"""
<form method="get" class="left-menu-form">
<input type="hidden" name="page" value="validation">
<input type="hidden" name="sub" value="{sub_value}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """


def safe_html_text(value):
   if pd.isna(value) or value is None:
       return "-"
   value = str(value).strip()
   return value if value else "-"

# def _pick_short_description(row: pd.Series):
#    candidate_cols = [
#        "Short Description (English)",
#        "Short Description",
#        "short_description",
#        "SHORT_DESCRIPTION",
#        "Description",
#    ]
#    for col in candidate_cols:
#        if col in row.index:
#            val = row.get(col)
#            if pd.notna(val) and str(val).strip():
#                return str(val).strip()
# # fallback: first non-empty string-like field if nothing matched
#    for col in row.index:
#        val = row.get(col)
#        if pd.notna(val) and isinstance(val, str) and val.strip():
#            return val.strip()
#    return "-"

def build_predicted_description_html(row, desc_map):
   entries = []
   candidates = [
       ("Model 1", normalize_unspsc_display(row.get("Model 1 OP"))),
       ("Model 2", normalize_unspsc_display(row.get("Model 2 OP"))),
       ("Model 3", normalize_unspsc_display(row.get("Model 3 OP"))),
       ("LLM Judge", normalize_unspsc_display(row.get("LLM as a Judge OP"))),
   ]
   for label, code in candidates:
       if not code:
           continue
       desc = get_unspsc_description(code, desc_map)
       desc = safe_html_text(desc)
       entries.append(
           f"""
<div class="pred-desc-entry">
<div class="pred-desc-code">{label}: {code}</div>
<div class="pred-desc-text">{desc}</div>
</div>
           """
       )
   if not entries:
       return '<div class="pred-desc-missing">No predicted code descriptions available.</div>'
   return "".join(entries)



def get_selected_submenu():
   selected = st.query_params.get("sub", "to_validate")
   if isinstance(selected, list):
       selected = selected[0]
   if selected not in ["to_validate", "golden_dataset", "validate_detail"]:
       selected = "to_validate"
   return selected

def get_selected_run_id():
   run_id = st.query_params.get("run_id")
   if isinstance(run_id, list):
       run_id = run_id[0]
   return run_id

# def _pick_description_block(row: pd.Series):
#    short_candidates = [
#        "short_descrition_(english)",
#        "short_description_(english)",
#        "Short Description (English)",
#        "Short Description",
#    ]
#    long_candidates = [
#        "long_descritpion_(english)",
#        "long_description_(english)",
#        "Long Description (English)",
#        "Long Description",
#    ]
#    short_value = ""
#    long_value = ""
#    for col in short_candidates:
#        if col in row.index and pd.notna(row.get(col)) and str(row.get(col)).strip():
#            short_value = str(row.get(col)).strip()
#            break
#    for col in long_candidates:
#        if col in row.index and pd.notna(row.get(col)) and str(row.get(col)).strip():
#            long_value = str(row.get(col)).strip()
#            break
#    short_value = safe_html_text(short_value)
#    long_value = safe_html_text(long_value)
#    return f"""
# <div class="validation-shortdesc"><b>Short description:</b> {short_value}</div>
# <div class="validation-shortdesc" style="margin-top:12px;"><b>Long description:</b> {long_value}</div>
#    """

########################################################################################################
@st.cache_data(show_spinner=False)
def get_unspsc_description_map():
   lookup_df = load_unspsc_lookup_df(UNSPSC_LOOKUP_PATH)
   return build_unspsc_description_map(lookup_df, UNSPSC_CODE_COL, UNSPSC_DESC_COL)

def load_unspsc_lookup_df(path_in_folder: str) -> pd.DataFrame:
   data = folder.get_download_stream(path_in_folder).read()
   lower_path = path_in_folder.lower()
   if lower_path.endswith(".csv"):
       encodings_to_try = ["utf-8", "utf-8-sig", "cp1252", "latin-1", "iso-8859-1"]
       last_error = None
       for enc in encodings_to_try:
           try:
               return pd.read_csv(io.BytesIO(data), dtype=str, encoding=enc)
           except UnicodeDecodeError as e:
               last_error = e
       raise ValueError(
           f"Unable to decode CSV lookup file '{path_in_folder}' with supported encodings. "
           f"Last error: {last_error}"
       )
   elif lower_path.endswith(".xlsx") or lower_path.endswith(".xls"):
       return pd.read_excel(io.BytesIO(data), dtype=str)
   elif lower_path.endswith(".json"):
       return pd.read_json(io.BytesIO(data), dtype=str)
   else:
       raise ValueError(f"Unsupported lookup file type: {path_in_folder}")

def build_unspsc_description_map(df: pd.DataFrame, code_col: str, desc_col: str) -> dict:
   temp = df[[code_col, desc_col]].copy()
   temp[code_col] = temp[code_col].fillna("").astype(str).str.replace("\xa0", " ", regex=False).str.strip()
   temp[desc_col] = temp[desc_col].fillna("").astype(str).str.replace("\xa0", " ", regex=False).str.strip()
   temp = temp[temp[code_col] != ""]
   return dict(zip(temp[code_col], temp[desc_col]))

############################################################################

@st.cache_data(show_spinner=False)
def load_unspsc_description_map():
   import dataiku
   folder = dataiku.Folder("MDM_application")
   candidate_paths = [
       "reference/unspsc_code_description.csv",
       "/reference/unspsc_code_description.csv",
   ]
   ref_df = None
   for path in candidate_paths:
       try:
           details = folder.get_path_details(path)
           if details.get("exists", False):
               with folder.get_download_stream(path) as stream:
                   ref_df = pd.read_csv(stream)
               break
       except Exception:
           continue
   if ref_df is None or ref_df.empty:
       return {}
   ref_df.columns = [str(c).strip() for c in ref_df.columns]
# Replace these 2 names with the exact names from your CSV
   code_col = "unspsc_code"
   desc_col = "unspsc_description"
   ref_df[code_col] = (
       ref_df[code_col]
       .astype(str)
       .str.strip()
       .str.replace(".0", "", regex=False)
   )
   ref_df[desc_col] = ref_df[desc_col].fillna("").astype(str).str.strip()
   return dict(zip(ref_df[code_col], ref_df[desc_col]))


def normalize_unspsc_display(value):
   if pd.isna(value) or value is None:
       return ""
   return str(value).strip().replace(".0", "")


def get_unspsc_description(code, desc_map):
   code = normalize_unspsc_display(code)
   if not code:
       return ""
   return desc_map.get(code, "")

def format_preview_dataframe(df):
   preview_df = df.copy()
   for col in preview_df.columns:
       series = preview_df[col]
       if str(series.dtype) in ["bool", "boolean"]:
           preview_df[col] = series.map(lambda x: "Yes" if x else "No")
   return preview_df

def render_paginated_dataframe(df, pager_prefix, default_page_size=10):
   total_rows = len(df)
   if total_rows == 0:
       st.markdown(
           """
<div class="empty-state-box">
   No rows available.
</div>
           """,
           unsafe_allow_html=True
       )
       return
   page_key = f"{pager_prefix}_page"
   if page_key not in st.session_state:
       st.session_state[page_key] = 1
   page_size = default_page_size
   total_pages = get_total_pages(total_rows, page_size)
   current_page = st.session_state[page_key]
   current_page = max(1, min(current_page, total_pages))
   st.session_state[page_key] = current_page
   start_idx, end_idx = get_page_bounds(current_page, page_size, total_rows)
   left_col, center_col, right_col = st.columns([2.2, 4.8, 2.0])
   with left_col:
       prev_col, next_col = st.columns(2)
       with prev_col:
           if st.button(
               "Prev",
               key=f"{pager_prefix}_prev",
               disabled=(current_page == 1),
               use_container_width=True
           ):
               st.session_state[page_key] = current_page - 1
               st.rerun()
       with next_col:
           if st.button(
               "Next",
               key=f"{pager_prefix}_next",
               disabled=(current_page == total_pages),
               use_container_width=True
           ):
               st.session_state[page_key] = current_page + 1
               st.rerun()
   with center_col:
       st.markdown(
           f"""
<div class="pagination-summary">
   Page {current_page} / {total_pages} • Rows {start_idx + 1}-{end_idx} of {total_rows}
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           '<div class="pagination-right-label">Go to page</div>',
           unsafe_allow_html=True
       )
       selected_page = st.number_input(
           "Go to page",
           min_value=1,
           max_value=total_pages,
           value=current_page,
           step=1,
           key=f"{pager_prefix}_page_input",
           label_visibility="collapsed"
       )
       if selected_page != current_page:
           st.session_state[page_key] = int(selected_page)
           st.rerun()
   page_df = get_page_df(df, st.session_state[page_key], page_size)
   page_df = format_preview_dataframe(page_df)
   st.dataframe(page_df, use_container_width=True, hide_index=True)

def render_to_validate_view():
   runs = list_runs_to_validate()
   st.markdown(
       """
<div class="section-card">
<div class="section-card-title">To Validate</div>
<div class="section-card-subtitle">
       Prediction runs that still have rows pending approval.
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if not runs:
       st.markdown(
           """
<div class="section-card">
<div class="empty-state-box">
       No runs pending validation.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       return
   header_cols = st.columns([1.8, 2.8, 2.2, 2.8, 1.4, 1.1])
   headers = [
       "S. No",
       "Prediction Job",
       "Prediction Created By",
       "Approved Rows",
       "Status",
       "Last Updated",
       "Updated By",
       "Action",
   ]
   for col, header in zip(header_cols, headers):
       with col:
           st.markdown(
               f'<div class="runs-header-cell">{header}</div>',
               unsafe_allow_html=True
           )
   for idx, run in enumerate(runs, start=1):
       row_cols = st.columns([0.7, 2.8, 1.8, 1.4, 1.3, 2.0, 1.6, 1.2])
       with row_cols[0]:
           st.markdown(f'<div class="runs-cell">{idx}</div>', unsafe_allow_html=True)
       with row_cols[1]:
           st.markdown(f'<div class="runs-cell">{run["Prediction Job"]}</div>', unsafe_allow_html=True)
       with row_cols[2]:
           st.markdown(f'<div class="runs-cell">{run["Prediction Created By"]}</div>', unsafe_allow_html=True)
       with row_cols[3]:
           st.markdown(f'<div class="runs-cell">{run["Approved Rows"]}</div>', unsafe_allow_html=True)
       with row_cols[4]:
           status_class = str(run["Status"]).lower()
           st.markdown(
               f'<div class="runs-cell"><span class="status-pill {status_class}">{run["Status"]}</span></div>',
               unsafe_allow_html=True
           )
       with row_cols[5]:
           st.markdown(f'<div class="runs-cell">{run["Last Updated"]}</div>', unsafe_allow_html=True)
       with row_cols[6]:
           st.markdown(f'<div class="runs-cell">{run["Updated By"]}</div>', unsafe_allow_html=True)
       with row_cols[7]:
           if st.button(
               "Continue",
               key=f'continue_validation_{run["prediction_job_id"]}',
               use_container_width=True
           ):
               st.query_params["page"] = "validation"
               st.query_params["sub"] = "validate_detail"
               st.query_params["run_id"] = run["prediction_job_id"]
               st.rerun()
       st.divider()

# def _pick_short_description(row: pd.Series):
#    for col in ["Short Description (English)", "Short Description"]:
#        if col in row.index:
#            return row.get(col)
#    return ""

def _build_radio_options(row: pd.Series):
   options = []
   if pd.notna(row.get("Model 1 OP")) and str(row.get("Model 1 OP")).strip():
       options.append(("Model 1", str(row.get("Model 1 OP"))))
   if pd.notna(row.get("Model 2 OP")) and str(row.get("Model 2 OP")).strip():
       options.append(("Model 2", str(row.get("Model 2 OP"))))
   if pd.notna(row.get("Model 3 OP")) and str(row.get("Model 3 OP")).strip():
       options.append(("Model 3", str(row.get("Model 3 OP"))))
   if pd.notna(row.get("LLM as a Judge OP")) and str(row.get("LLM as a Judge OP")).strip():
       options.append(("LLM Judge", str(row.get("LLM as a Judge OP"))))
   options.append(("Edit", ""))
   return options

def render_info_box(title, body, height=170):
   st.markdown(f"**{title}**")
   st.markdown(
       f"""
<div style="
           background:#ffffff;
           border:1px solid #dfe3ea;
           border-radius:16px;
           padding:16px 18px;
           min-height:{height}px;
           color:#111827;
           line-height:1.6;
           font-size:15px;
           box-sizing:border-box;
           white-space:pre-wrap;
           overflow-wrap:anywhere;
       ">
           {body}
</div>
       """,
       unsafe_allow_html=True
   )

# def build_description_block(row):
#    short_val = safe_html_text(row.get("short_description_(english)", ""))
#    short_val = short_val if norm(short_val) is notna else "Null"
#    long_val = safe_html_text(row.get("long_descritpion_(english)", ""))
#    long_val = long_val if norm(long_val) is not notna else "Null"

#    return f"""
# <div style="font-weight:700; margin-bottom:10px;">Short description: {short_val}</div>
# <div style="font-weight:700;">Long description: {long_val if long_val is not None else "Null"}</div>
#    """


def build_predicted_description_block(row, desc_map):
   entries = []
   for label, col in [
       ("Model 1", "Model 1 OP"),
       ("Model 2", "Model 2 OP"),
       ("Model 3", "Model 3 OP"),
       ("LLM Judge", "LLM as a Judge OP"),
   ]:
       code = normalize_unspsc_display(row.get(col))
       if not code:
           continue
       desc = desc_map.get(code, "")
       desc = safe_html_text(desc)
       entries.append(
           f"""
<div style="margin-bottom:16px;">
<div style="font-weight:800; color:#111827; margin-bottom:4px;">{label}: {code}</div>
<div style="color:#4b5563; line-height:1.6;">{desc}</div>
</div>
           """
       )
   return "".join(entries) if entries else "<div style='color:#9ca3af;'>No descriptions found.</div>"




def render_validation_detail_view():
   import html
   run_id = get_selected_run_id()
   if not run_id:
       st.error("Missing run_id.")
       return
   vmeta = ensure_validation_run(run_id)
   queue_df = load_validation_queue_df(run_id)
   top_cols = st.columns([1.6, 6.4])
   with top_cols[0]:
       if st.button("← Back to To Validate", key="back_to_to_validate", use_container_width=True):
           st.query_params["page"] = "validation"
           st.query_params["sub"] = "to_validate"
           st.rerun()
   st.markdown(
       f"""
<div class="run-meta-card">
<div class="run-meta-title">Validation Detail</div>
<div class="run-meta-grid">
<div class="run-meta-item">
<div class="run-meta-label">Prediction Job</div>
<div class="run-meta-value">{html.escape(str(run_id))}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Approved Rows</div>
<div class="run-meta-value">{vmeta.get("approved_rows", 0)}/{vmeta.get("total_rows", 0)}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Status</div>
<div class="run-meta-value">{html.escape(str(vmeta.get("status", "pending")))}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Updated At</div>
<div class="run-meta-value">{html.escape(str(vmeta.get("updated_at", "")))}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Updated By</div>
<div class="run-meta-value">{html.escape(str(vmeta.get("updated_by", "")))}</div>
</div>
<div class="run-meta-item">
<div class="run-meta-label">Remaining Rows</div>
<div class="run-meta-value">{vmeta.get("remaining_rows", 0)}</div>
</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if queue_df is None or queue_df.empty:
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Validation Queue</div>
<div class="section-card-subtitle">
                   All rows for this prediction run have been approved.
</div>
<div class="empty-state-box">
                   No rows remaining in the validation queue.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       return
   desc_map = get_unspsc_description_map()
   record_key = f"validation_record_index_{run_id}"
   if record_key not in st.session_state:
       st.session_state[record_key] = 0
   current_index = st.session_state[record_key]
   current_index = max(0, min(current_index, len(queue_df) - 1))
   st.session_state[record_key] = current_index
   nav_cols = st.columns([1.2, 1.2, 4.8, 1.6])
   with nav_cols[0]:
       if st.button(
           "Prev Record",
           key=f"prev_record_{run_id}",
           disabled=(current_index == 0),
           use_container_width=True,
       ):
           st.session_state[record_key] = current_index - 1
           st.rerun()
   with nav_cols[1]:
       if st.button(
           "Next Record",
           key=f"next_record_{run_id}",
           disabled=(current_index == len(queue_df) - 1),
           use_container_width=True,
       ):
           st.session_state[record_key] = current_index + 1
           st.rerun()
   with nav_cols[3]:
       st.markdown(
           f'<div class="validation-summary-chip">Record {current_index + 1} / {len(queue_df)}</div>',
           unsafe_allow_html=True
       )
   row = queue_df.iloc[current_index].copy()
   row_id = int(row["_validation_row_id"])
   def _safe_text(value, default="-"):
       if pd.isna(value) or value is None:
           return default
       value = str(value).strip()
       return value if value else default
   def _normalize_code(value):
       if pd.isna(value) or value is None:
           return ""
       return str(value).strip().replace(".0", "")
   def _first_non_empty(series, candidates):
       for col in candidates:
           if col in series.index:
               val = series.get(col)
               if pd.notna(val) and str(val).strip():
                   return str(val).strip()
       return ""
   def _render_info_box(title, body_html, height=180):
       st.markdown(f"**{title}**")
       st.markdown(
           f"""
<div style="
               background:#ffffff;
               border:1px solid #dfe3ea;
               border-radius:16px;
               padding:16px 18px;
               min-height:{height}px;
               color:#111827;
               line-height:1.6;
               font-size:15px;
               box-sizing:border-box;
               white-space:pre-wrap;
               overflow-wrap:anywhere;
           ">
               {body_html}
</div>
           """,
           unsafe_allow_html=True
       )
   short_value = _first_non_empty(
       row,
       [
           "short_descrition_(english)",
           "short_description_(english)",
           "Short Description (English)",
           "Short Description",
       ],
   )
   long_value = _first_non_empty(
       row,
       [
           "long_descritpion_(english)",
           "long_description_(english)",
           "Long Description (English)",
           "Long Description",
       ],
   )
   description_block = f"""
<div style="font-size:15px; font-weight:700; color:#111827; line-height:1.7;">
<div><span style="font-weight:800;">Short Description:</span> {html.escape(_safe_text(short_value)) if short_value is not None else "Null"}</div>
<div style="margin-top:14px;"><span style="font-weight:800;">Long description:</span> {html.escape(_safe_text(long_value)) if long_value is not None else "Null"}</div>
</div>
   """
   explanation_text = _safe_text(row.get("Explanation", ""))
   explanation_block = f"""
<div style="font-size:15px; font-weight:500; color:#1f2937; line-height:1.8;">
           {html.escape(explanation_text)}
</div>
   """
   model1_code = _normalize_code(row.get("Model 1 OP"))
   model2_code = _normalize_code(row.get("Model 2 OP"))
   model3_code = _normalize_code(row.get("Model 3 OP"))
   llm_code = _normalize_code(row.get("LLM as a Judge OP"))
   option_items = [
       ("Edit", ""),
       ("Model 1", model1_code),
       ("Model 2", model2_code),
       ("Model 3", model3_code),
       ("LLM Judge", llm_code),
   ]
   option_labels = []
   option_value_map = {}
   for source, code in option_items:
       if source == "Edit":
           label = "Edit"
           option_labels.append(label)
           option_value_map[label] = {"source": "Manual Edit", "code": ""}
       else:
           label = f"{source}: {code}" if code else f"{source}:"
           option_labels.append(label)
           option_value_map[label] = {"source": source, "code": code}
   default_label = None
   for label in option_labels:
       if label.startswith("LLM Judge") and option_value_map[label]["code"]:
           default_label = label
           break
   if default_label is None:
       for label in option_labels:
           if option_value_map[label]["code"]:
               default_label = label
               break
   if default_label is None:
       default_label = "Edit"
   def _build_pred_desc_block():
       entries = []
       for label, code in [
           ("Model 1", model1_code),
           ("Model 2", model2_code),
           ("Model 3", model3_code),
           ("LLM Judge", llm_code),
       ]:
           if not code:
               continue
           desc = _safe_text(desc_map.get(code, ""), default="-")
           entries.append(
               f"""
<div style="margin-bottom:18px;">
<div style="font-size:16px; font-weight:800; color:#111827; margin-bottom:6px;">
                       {html.escape(label)}: {html.escape(code)}
</div>
<div style="font-size:15px; color:#4b5563; line-height:1.7;">
                       {html.escape(desc)}
</div>
</div>
               """
           )
       if not entries:
           return "<div style='color:#9ca3af; font-style:italic;'>No descriptions found.</div>"
       return "".join(entries)
   pred_desc_block = _build_pred_desc_block()
   review_cols = st.columns([1.8, 2.8, 2.2, 2.8, 1.4, 1.1])
   with review_cols[0]:
       _render_info_box("Description", description_block, height=185)
   with review_cols[1]:
       _render_info_box("Explanation", explanation_block, height=185)
   with review_cols[2]:
       st.markdown("**Model Prediction**")
       selected_label = st.radio(
           "Select Output",
           options=option_labels,
           index=option_labels.index(default_label),
           key=f"validation_choice_{run_id}_{row_id}",
           label_visibility="collapsed"
       )
   selected_meta = option_value_map[selected_label]
   revised_default = "" if selected_meta["source"] == "Manual Edit" else selected_meta["code"]
   with review_cols[3]:
       _render_info_box("Predicted Code Description", pred_desc_block, height=185)
   with review_cols[4]:
       st.markdown("**Revised Code**")
       revised_code = st.text_input(
           "Revised Code",
           value=revised_default,
           key=f"revised_code_{run_id}_{row_id}",
           disabled=(selected_meta["source"] != "Manual Edit"),
           placeholder="Enter UNSPSC" if selected_meta["source"] == "Manual Edit" else "",
           label_visibility="collapsed"
       )
   with review_cols[5]:
       st.markdown("**Approve**")
       approve_clicked = st.button(
           "Approve",
           key=f"approve_row_{run_id}_{row_id}",
           use_container_width=True
       )
   final_value = revised_code.strip() if selected_meta["source"] == "Manual Edit" else selected_meta["code"].strip()
   final_source = selected_meta["source"]
   if approve_clicked:
       if not final_value:
           st.error("Please choose a predicted value or enter a revised code before approving.")
       else:
           approve_validation_row(
               run_id=run_id,
               validation_row_id=row_id,
               validated_unspsc=final_value,
               validation_source=final_source,
               validation_comment="",
           )
           new_queue_df = load_validation_queue_df(run_id)
           if new_queue_df is None or new_queue_df.empty:
               st.session_state[record_key] = 0
           else:
               st.session_state[record_key] = min(current_index, len(new_queue_df) - 1)
           st.success("Row approved and moved to Golden Dataset.")
           st.rerun()
   st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
   with st.expander("Input Parameters", expanded=False):
       extra_exclude = {
           "short_descrition_(english)",
           "short_description_(english)",
           "Short Description (English)",
           "Short Description",
           "long_descritpion_(english)",
           "long_description_(english)",
           "Long Description (English)",
           "Long Description",
       }
       input_param_columns = [
           c for c in row.index
           if c not in TOP_REVIEW_COLUMNS and c not in extra_exclude
       ]
       input_params_df = pd.DataFrame([row[input_param_columns].to_dict()])
       input_params_df = format_preview_dataframe(input_params_df)
       st.dataframe(input_params_df, use_container_width=True, hide_index=True)

def render_golden_dataset_view():
   golden_df = load_golden_dataset_df()
   st.markdown(
       """
<div class="section-card">
<div class="section-card-title">Golden Dataset</div>
<div class="section-card-subtitle">
       Approved rows appended from validation.
</div>
</div>
       """,
       unsafe_allow_html=True
   )
   if golden_df is None or golden_df.empty:
       st.markdown(
           """
<div class="section-card">
<div class="empty-state-box">
       Golden Dataset is empty.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       return
# Hide the internal technical row id by default in the display
   display_df = golden_df.copy()
   if "_validation_row_id" in display_df.columns:
       display_df = display_df.drop(columns=["_validation_row_id"])
   render_paginated_dataframe(
       display_df,
       pager_prefix="golden_dataset",
       default_page_size=10
   )

def render():
   load_css(
       get_global_css()
       + get_home_page_css()
       + get_classify_page_css()
       + get_validation_page_css()
   )
   selected_menu = get_selected_submenu()
   logo_base64 = get_base64_image("assets/Alstom_logo.svg.png")
   left_col, right_col = st.columns([1.15, 4.35], gap="medium")
   with left_col:
       st.markdown(
           f"""
<div class="classify-left-panel">
<div class="classify-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="classify-logo-img"/>
</div>
<div class="classify-title">AI-Parts Classifier</div>
<div class="classify-subtitle">Validation Assist Tool</div>
<div class="left-group-title">Section</div>
   {left_menu_btn("To Validate", "to_validate", selected_menu == "to_validate")}
   {left_menu_btn("Golden Dataset", "golden_dataset", selected_menu == "golden_dataset")}
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           f"""
<div class="validation-topbar">
   {nav_pill("🏠 Home", "home")}
   {nav_pill("🔒 Admin", "admin")}
   {nav_pill("🛡️ Super Admin", "super_admin")}
   {nav_pill("ℹ️ About", "about")}
   {nav_pill("❓ Help", "help")}
</div>
<hr class="validation-page-divider"/>
           """,
           unsafe_allow_html=True
       )
       if selected_menu == "to_validate":
           render_to_validate_view()
       elif selected_menu == "golden_dataset":
           render_golden_dataset_view()
       else:
           render_validation_detail_view()