import streamlit as st

from services.access_control_service import get_current_user_permissions
from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css, get_home_page_css


def home_action_card(label, page, sub=None):
   sub_input = ""
   if sub is not None:
       sub_input = f'<input type="hidden" name="sub" value="{sub}">'
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{page}">
   {sub_input}
<button type="submit" class="home-action-card">{label}</button>
</form>
   """


def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css())
   permissions = get_current_user_permissions()

   render_sidebar(subtitle="Home")
   render_top_nav(active_slug="home")

   left_cards = []
   right_cards = []
   if permissions["can_classify"]:
       left_cards.append(home_action_card("Classify Existing Parts", "classify_existing", "existing_parts"))
       left_cards.append(home_action_card("RUNS", "classify_existing", "runs"))
       right_cards.append(home_action_card("Create New Parts", "create_new_parts"))
   if permissions["can_validate"]:
       left_cards.insert(1, home_action_card("Validate Classified Parts", "validation"))

   st.markdown(
       f"""
<div class="options-title">Options</div>
<div class="home-custom-layout">
  <div class="home-custom-left">
    {''.join(left_cards)}
  </div>
  <div class="home-custom-divider"></div>
  <div class="home-custom-right">
    {''.join(right_cards)}
  </div>
</div>
       """,
       unsafe_allow_html=True,
   )
