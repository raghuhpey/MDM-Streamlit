import streamlit as st

from ui.layout import render_sidebar, render_top_nav
from utils.styles import load_css, get_app_shell_css, get_global_css


def render():
   load_css(get_global_css() + get_app_shell_css())
   render_sidebar(subtitle="About")
   render_top_nav(active_slug="about")
   st.title("About")
   st.write("This page describes the application.")
