import streamlit as st

from services.validation_report_service import fetch_validation_report_df
from ui.layout import render_sidebar, render_top_nav
from utils.styles import (
   get_app_shell_css,
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)


def render():
   load_css(get_global_css() + get_app_shell_css() + get_home_page_css() + get_classify_page_css())
   report_df = fetch_validation_report_df()

   render_sidebar(subtitle="Validation Report")
   render_top_nav(active_slug="super_admin")

   st.markdown(
       """
<div class="section-card">
<div class="section-card-title">Validation Report</div>
<div class="section-card-subtitle">
   Run-wise validation summary including pending records and current status.
</div>
</div>
       """,
       unsafe_allow_html=True
   )

   st.markdown("***")
   if report_df.empty:
       st.markdown(
           """
<div class="section-card">
<div class="empty-state-box">No validation report data available.</div>
</div>
           """,
           unsafe_allow_html=True
       )
   else:
       st.dataframe(report_df, use_container_width=True, hide_index=True)
