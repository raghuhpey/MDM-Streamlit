import streamlit as st
PAGES = [
   "Home",
   "Classify / Create Parts",
   "Validation",
   "Admin",
   "About",
   "Help",
]
def render_top_nav():
   current_page = st.session_state.get("current_page", "Home")
   if current_page not in PAGES:
       current_page = "Home"
       st.session_state["current_page"] = "Home"
   selected = st.radio(
       label="Navigation",
       options=PAGES,
       index=PAGES.index(current_page),
       horizontal=True,
       label_visibility="collapsed",
       key="top_nav_radio"
   )
   st.session_state["current_page"] = selected