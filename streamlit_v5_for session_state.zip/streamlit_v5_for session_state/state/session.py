import streamlit as st

def _first(value, default=None):
   if isinstance(value, list):
       return value[0] if value else default
   return value if value not in (None, "") else default

def init_session_state():
   defaults = {
       "nav_page": "home",
       "nav_sub": None,
       "nav_run_id": None,
       "current_page": "Home",
       "current_flow": None,
       "prediction_output_df": None,
       "validation_df": None,
       "prediction_job_id": None,
       "validation_job_id": None,
       "prediction_status": None,
       "validation_status": None,
       "error_message": None,
       "success_message": None,
       "current_existing_run_id": None,
       "current_new_parts_run_id": None,
       "existing_parts_upload_signature": None,
       "new_parts_upload_signature": None,
   }
   for key, value in defaults.items():
       if key not in st.session_state:
           st.session_state[key] = value

def _write_navigation_to_query_params(page=None, sub=None, run_id=None):
   params = {}
   if page:
       params["page"] = page
   if sub:
       params["sub"] = sub
   if run_id:
       params["run_id"] = run_id
   for key in list(st.query_params.keys()):
       del st.query_params[key]
   for key, value in params.items():
       st.query_params[key] = value

def sync_navigation_state():
   page = _first(st.query_params.get("page"), st.session_state.get("nav_page", "home"))
   sub = _first(st.query_params.get("sub"), st.session_state.get("nav_sub"))
   run_id = _first(st.query_params.get("run_id"), st.session_state.get("nav_run_id"))
   st.session_state["nav_page"] = page or "home"
   st.session_state["nav_sub"] = sub
   st.session_state["nav_run_id"] = run_id
   _write_navigation_to_query_params(
       page=st.session_state["nav_page"],
       sub=st.session_state["nav_sub"],
       run_id=st.session_state["nav_run_id"],
   )
   return (
       st.session_state["nav_page"],
       st.session_state["nav_sub"],
       st.session_state["nav_run_id"],
   )

def set_navigation_state(page, sub=None, run_id=None):
   st.session_state["nav_page"] = page
   st.session_state["nav_sub"] = sub
   st.session_state["nav_run_id"] = run_id
   _write_navigation_to_query_params(page=page, sub=sub, run_id=run_id)