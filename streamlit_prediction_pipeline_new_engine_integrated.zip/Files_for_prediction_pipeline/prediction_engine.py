from __future__ import annotations

import hashlib
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import pandas as pd

from services.prediction_resources import PredictionResources

TITLE_OUTPUT_COLUMNS = [
    "Model 1 OP",
    "Model 2 OP",
    "Model 3 OP",
    "LLM as a Judge OP",
    "LLM Decision Source",
    "Explanation",
]

REQUIRED_PIPELINE_COLUMNS = [
    "unspsc_code",
    "short_description_(english)",
    "long_description_(english)",
    "part_manufacturer_list_information",
    "hazardous_goods_(s.f.)",
    "is_related_to_fire&smoke?",
    "part_rohs",
    "perishable_part",
    "repairable_?",
    "unit_of_measure_information",
    "usability",
]

COLUMN_CANDIDATES = {
    "short_description_(english)": [
        "Short Description (English)",
        "short_description_(english)",
        "Short Description",
    ],
    "long_description_(english)": [
        "Long Description (English)",
        "long_description_(english)",
        "Long Description",
    ],
    "part_manufacturer_list_information": [
        "Part Manufacturer List information",
        "part_manufacturer_list_information",
    ],
    "hazardous_goods_(s.f.)": [
        "Hazardous Goods (S.F.)",
        "hazardous_goods_(s.f.)",
    ],
    "is_related_to_fire&smoke?": [
        "Is related to Fire&Smoke?",
        "is_related_to_fire&smoke?",
    ],
    "part_rohs": [
        "Part ROHS",
        "part_rohs",
    ],
    "perishable_part": [
        "Perishable Part",
        "perishable_part",
    ],
    "repairable_?": [
        "Repairable ?",
        "repairable_?",
    ],
    "unit_of_measure_information": [
        "Unit of Measure information",
        "unit_of_measure_information",
    ],
    "usability": [
        "Usability",
        "usability",
    ],
    "unspsc_code": [
        "unspsc_code",
        "UNSPSC Code",
    ],
}


def _first_present(df: pd.DataFrame, candidates: list[str]) -> str | None:
    for col in candidates:
        if col in df.columns:
            return col
    return None


def _normalize_value(value: Any) -> str:
    if pd.isna(value) or value is None:
        return ""
    text = str(value).replace(" ", " ").strip()
    if text.endswith(".0"):
        text = text[:-2]
    return text


def _build_prediction_key(row: pd.Series) -> str:
    payload = {col: _normalize_value(row.get(col)) for col in REQUIRED_PIPELINE_COLUMNS}
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _prepare_pipeline_input(input_df: pd.DataFrame) -> pd.DataFrame:
    prepared = pd.DataFrame(index=input_df.index)
    for target_col in REQUIRED_PIPELINE_COLUMNS:
        source_col = _first_present(input_df, COLUMN_CANDIDATES.get(target_col, [target_col]))
        if source_col is None:
            prepared[target_col] = None
        else:
            prepared[target_col] = input_df[source_col]

    # unspsc_code is not required for inference inputs; keep it nullable.
    if "unspsc_code" not in prepared.columns:
        prepared["unspsc_code"] = None

    prepared["_prediction_key"] = prepared.apply(_build_prediction_key, axis=1)
    return prepared


def _is_content_filter_error(exc: Exception) -> bool:
    text = repr(exc).lower()
    markers = [
        "content_filter",
        "contentpolicyviolation",
        "responsibleaipolicyviolation",
        "content management policy",
    ]
    return any(marker in text for marker in markers)


def _build_ignored_record(row_position: int, row: pd.Series, exc: Exception) -> dict:
    payload = row.to_dict()
    payload["ignored_row_position"] = row_position
    payload["ignored_df_index"] = row.name
    payload["ignored_stage"] = "llm_judge"
    payload["ignored_error_type"] = type(exc).__name__
    payload["ignored_error"] = repr(exc)
    payload["ignored_reason"] = (
        "Azure content filter blocked the LLM judge prompt."
        if _is_content_filter_error(exc)
        else "LLM judge failed for this row."
    )
    return payload


def _judge_row(prediction_module, row_position: int, row: pd.Series) -> dict:
    query = row.get("short_description_(english)")
    m1 = row.get("Model 1 OP")
    m2 = row.get("Model 2 OP")
    m3 = row.get("Model 3 OP")
    try:
        code, explanation, source = prediction_module.predict_unspsc_with_rag(
            query,
            model1=m1,
            model2=m2,
            model3=m3,
        )
        return {
            "LLM as a Judge OP": code,
            "LLM Decision Source": source,
            "Explanation": explanation,
        }
    except Exception as exc:
        print("
========== LLM JUDGE IGNORED RECORD ==========")
        print(f"row_position: {row_position}")
        print(f"df_index: {row.name}")
        print(f"short_description_(english): {row.get('short_description_(english)')}")
        print(f"long_description_(english): {row.get('long_description_(english)')}")
        print(f"Model 1 OP: {m1}")
        print(f"Model 2 OP: {m2}")
        print(f"Model 3 OP: {m3}")
        print(f"error_type: {type(exc).__name__}")
        print(f"error: {repr(exc)}")
        print("=============================================")
        raise


def _run_llm_judge(prediction_module, ml_df: pd.DataFrame, max_workers: int = 4) -> tuple[pd.DataFrame, pd.DataFrame]:
    judged_df = ml_df.copy().reset_index(drop=True)
    judged_df["LLM as a Judge OP"] = None
    judged_df["LLM Decision Source"] = None
    judged_df["Explanation"] = None

    ignored_records: list[dict] = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_judge_row, prediction_module, row_position, row.copy()): (row_position, row.copy())
            for row_position, (_, row) in enumerate(ml_df.iterrows())
        }
        for future in as_completed(futures):
            row_position, row = futures[future]
            try:
                result = future.result()
                judged_df.at[row_position, "LLM as a Judge OP"] = result.get("LLM as a Judge OP")
                judged_df.at[row_position, "LLM Decision Source"] = result.get("LLM Decision Source")
                judged_df.at[row_position, "Explanation"] = result.get("Explanation")
            except Exception as exc:
                ignored_records.append(_build_ignored_record(row_position, row, exc))
                judged_df.at[row_position, "LLM as a Judge OP"] = "IGNORED"
                judged_df.at[row_position, "LLM Decision Source"] = (
                    "Ignored(ContentFilter)" if _is_content_filter_error(exc) else "Ignored(Error)"
                )
                judged_df.at[row_position, "Explanation"] = (
                    "Row ignored because the LLM judge prompt was blocked by Azure content filtering."
                    if _is_content_filter_error(exc)
                    else "Row ignored because the LLM judge failed for this record."
                )
    ignored_df = pd.DataFrame(ignored_records)
    if not ignored_df.empty and "ignored_row_position" in ignored_df.columns:
        ignored_df = ignored_df.sort_values("ignored_row_position").reset_index(drop=True)
    return judged_df, ignored_df


def predict_dataframe(input_df: pd.DataFrame, resources: PredictionResources, max_workers: int = 4) -> tuple[pd.DataFrame, pd.DataFrame]:
    prediction_module = resources.prediction_module

    input_work_df = input_df.reset_index(drop=True).copy()
    pipeline_input_df = _prepare_pipeline_input(input_work_df)

    unique_pipeline_df = (
        pipeline_input_df
        .drop_duplicates(subset=["_prediction_key"])
        .reset_index(drop=True)
        .copy()
    )

    ml_unique_df = prediction_module.generate_ml_output(unique_pipeline_df.copy())
    ml_unique_df = ml_unique_df.copy()
    ml_unique_df.rename(columns={"Model1": "Model 1 OP", "Model2": "Model 2 OP", "Model3": "Model 3 OP"}, inplace=True)

    judged_unique_df, unique_ignored_df = _run_llm_judge(
        prediction_module,
        ml_unique_df,
        max_workers=max_workers,
    )

    prediction_cols = ["_prediction_key"] + TITLE_OUTPUT_COLUMNS
    judged_unique_df = judged_unique_df[prediction_cols].copy()

    merged_full_df = pipeline_input_df.merge(
        judged_unique_df,
        on="_prediction_key",
        how="left",
    )

    result_df = input_work_df.copy()
    for col in TITLE_OUTPUT_COLUMNS:
        result_df[col] = merged_full_df[col]

    ignored_df = pd.DataFrame()
    if not unique_ignored_df.empty:
        ignored_keys = set(unique_ignored_df.get("_prediction_key", pd.Series(dtype=str)).dropna().astype(str).tolist())
        if not ignored_keys and "_prediction_key" in judged_unique_df.columns:
            ignored_keys = set(
                judged_unique_df.loc[
                    judged_unique_df["LLM Decision Source"].astype(str).str.startswith("Ignored", na=False),
                    "_prediction_key",
                ].astype(str).tolist()
            )
        if ignored_keys:
            ignored_df = merged_full_df[merged_full_df["_prediction_key"].astype(str).isin(ignored_keys)].copy()
            ignored_df = ignored_df.merge(
                unique_ignored_df[["_prediction_key", "ignored_stage", "ignored_error_type", "ignored_error", "ignored_reason"]].drop_duplicates(subset=["_prediction_key"]),
                on="_prediction_key",
                how="left",
            )
            ignored_df.reset_index(drop=True, inplace=True)

    return result_df, ignored_df
