from __future__ import annotations

import importlib
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

DATA_FOLDER_ID = "Data_Folder"
MODEL_FOLDER_ID = "Pipeline_Models"
FAISS_FOLDER_ID = "FAISS_KB"

MODEL_1_PATH = "/Hari/2026_04_03_model_xgboost_new_wo_clamp/"
MODEL_2_PATH = "/Hari/2026_04_03_Model_Catboost_new_wo_clamp/"
MODEL_3_PATH = "/Hari/2026_04_03_model_mlp_new_wo_clamp/"

ARTIFACT_NAMES = {
    "model1_pipeline": f"{MODEL_1_PATH}model.pkl",
    "model2_pipeline": f"{MODEL_2_PATH}model.pkl",
    "model3_pipeline": f"{MODEL_3_PATH}model.keras",
    "pca_model": f"{MODEL_3_PATH}pca.pkl",
    "label_encoder_y": f"{MODEL_3_PATH}label_encoder_y_variable.pkl",
    "metadata": f"{MODEL_3_PATH}metadata.json",
    "features": f"{MODEL_3_PATH}features.json",
}


@dataclass
class PredictionResources:
    prediction_module: Any
    data_folder_id: str = DATA_FOLDER_ID
    model_folder_id: str = MODEL_FOLDER_ID
    faiss_folder_id: str = FAISS_FOLDER_ID
    artifact_names: dict[str, str] | None = None


def _import_prediction_module():
    module_names = [
        "services.predict_2026_04_03",
        "predict_2026_04_03",
    ]
    last_error = None
    for module_name in module_names:
        try:
            return importlib.import_module(module_name)
        except Exception as exc:
            last_error = exc
    raise ImportError(
        "Unable to import the new prediction pipeline module 'predict_2026_04_03'."
    ) from last_error


@lru_cache(maxsize=1)
def load_prediction_resources() -> PredictionResources:
    module = _import_prediction_module()
    return PredictionResources(
        prediction_module=module,
        artifact_names=ARTIFACT_NAMES.copy(),
    )
