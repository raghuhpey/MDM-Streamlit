print("*************** STEP Prediction FIle Libraries import START ******************")
import io
import json
import os
import re
import tempfile
import time
import warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from zoneinfo import ZoneInfo
import dataiku
import faiss
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from dataiku import pandasutils as pdu
from openai import AzureOpenAI
from sklearn.preprocessing import OneHotEncoder
from tensorflow import keras
import threading
import math
import tiktoken

from services.prediction_resources import (
   ARTIFACT_NAMES,
   DATA_FOLDER,
   EMBED_MODEL_NAME,
   FAISS_FOLDER,
   JUDGE_MODEL_NAME,
   MODEL_1_PATH,
   MODEL_2_PATH,
   MODEL_3_PATH,
   MODEL_FOLDER,
   PredictionResources,
   load_prediction_resources,
)

tz_ist = ZoneInfo("Asia/Kolkata")
warnings.filterwarnings("ignore")

print("*************** STEP Prediction FIle Libraries DONE ******************")
# ------------------------------------------------------------------
# All managed-folder ids, artifact paths, clients, and loaded models
# are owned by prediction_resources.py. This file only consumes them.
# ------------------------------------------------------------------

data_folder = None
model_folder = None
faiss_folder = None
folder = None
client_aoai = None
client_gpt = None
model1_pipeline = None
model2_pipeline = None
model3_pipeline = None
pca_model = None
label_encoder_y = None
metadata = None
feature_trained_on = None
EMBEDDING_MODEL_NAME = EMBED_MODEL_NAME
GPT_JUDGE_MODEL_NAME = JUDGE_MODEL_NAME
SMALL_RUN_CACHE_BYPASS_UNIQUE_TEXTS = 20
SMALL_RUN_CACHE_BYPASS_MISSES = 20

def configure_resources(resources: PredictionResources):
   global data_folder, model_folder, faiss_folder, folder
   global client_aoai, client_gpt
   global model1_pipeline, model2_pipeline, model3_pipeline
   global pca_model, label_encoder_y, metadata, feature_trained_on
   global EMBEDDING_MODEL_NAME, GPT_JUDGE_MODEL_NAME
   print("*************** STEP Load_Prediction resources START ******************")
   data_folder = resources.data_folder
   model_folder = resources.model_folder
   faiss_folder = resources.faiss_folder
   folder = resources.faiss_folder
   client_aoai = resources.client_aoai
   client_gpt = resources.client_gpt
   model1_pipeline = resources.model1_pipeline
   model2_pipeline = resources.model2_pipeline
   model3_pipeline = resources.model3_pipeline
   pca_model = resources.pca_model
   label_encoder_y = resources.label_encoder_y
   metadata = resources.metadata
   feature_trained_on = resources.feature_trained_on
   EMBEDDING_MODEL_NAME = resources.embed_model_name
   GPT_JUDGE_MODEL_NAME = resources.judge_model_name
   print("*************** STEP Load_Prediction resources DONE ******************")

def _ensure_resources_configured():
   if model1_pipeline is None or model2_pipeline is None or model3_pipeline is None:
       raise RuntimeError("Prediction resources are not configured. Call configure_resources(resources) before prediction.")


# Legacy aliases retained so the rest of the pipeline can stay unchanged.
DATA_FOLDER_ID = DATA_FOLDER
MODEL_FOLDER_ID = MODEL_FOLDER
FAISS_FOLDER_ID = FAISS_FOLDER

USE_CACHED_EMBEDDINGS = True
TARGET_COL = "unspsc_code"
TEXT_COL = "combined_description"
BINARY_COLS = []
CATEGORICAL_COLS = [
    "is_related_to_fire&smoke?",
    "repairable_?",
    "perishable_part",
    "hazardous_goods_(s.f.)",
    "unit_of_measure_information",
    "usability",
    "part_rohs",

]

MAX_CHUNK_TOKENS = 7000
MAX_TPM = 320_000
EMBED_BATCH_SIZE = 32
MAX_RETRIES = 3
SAVE_EVERY = 5000

EMBEDDING_CACHE_PATH = "cache/combined_description_embedding_cache.parquet"
_EMBEDDING_CACHE_DF = None
_EMBEDDING_CACHE_LOCK = threading.Lock()





# ==================== Data Cleaning & Feature Engineering ====================
def compose_description_upper(obj: str, doc: str) -> str:
   obj = obj if isinstance(obj, str) else ""
   doc = doc if isinstance(doc, str) else ""
   if obj and doc and re.search(re.escape(obj), doc, flags=re.IGNORECASE):
       head = doc
   else:
       head = f"{doc} FOR {obj}" if doc and obj else doc or obj
   return (head.strip().upper() + ".") if head.strip() else ""

def data_cleaning_pipeline(df):
   print("*************** STEP Data Cleaning START ******************")
   initial_rows = df.shape[0]
   df = df.apply(
       lambda col: col.astype(str).str.strip().str.replace(r"\s+", " ", regex=True)
       if col.dtype == "object" else col
   )
   df = df[~df['short_description_(english)'].isna()]
   df = df[['unspsc_code','short_description_(english)','long_description_(english)',
            'part_manufacturer_list_information','hazardous_goods_(s.f.)',
            'is_related_to_fire&smoke?','part_rohs','perishable_part','repairable_?',
            'unit_of_measure_information','usability',]]
   df['part_manufacturer_list_information'].fillna('unknown_manufacturer', inplace=True)
   df['hazardous_goods_(s.f.)'].fillna('unknown', inplace=True)
   df['is_related_to_fire&smoke?'].fillna('unknown', inplace=True)
   df['part_rohs'].fillna('not_defined', inplace=True)
   df['perishable_part'].fillna('unknown', inplace=True)
   df['repairable_?'].fillna('unknown', inplace=True)
   df['unit_of_measure_information'].fillna('other_measure', inplace=True)
   df['usability'].fillna('other_usability', inplace=True)

   df["combined_description"] = df.apply(
       lambda r: compose_description_upper(r["short_description_(english)"], r["long_description_(english)"]),
       axis=1
   )
   df['combined_description'] += ", manufacturer is " + df['part_manufacturer_list_information']
   df.drop(['short_description_(english)','long_description_(english)','part_manufacturer_list_information'], axis=1, inplace=True)
   df = df.reset_index(drop=True)
   print("*************** STEP Data Cleaning DONE ******************")
   return df

# ==================== Embedding & PCA ====================

# Function to get the latest embedding file number for loading/saving
def get_highest_embedding_number(data_folder):
   print("*************** STEP Get Highest Embedding START ******************")
   folder_path = "2026_02_11_Embedding"
   pattern = re.compile(
       r"combined_data_embedding_new(\d+)\.parquet"
   )
   existing_files = data_folder.list_paths_in_partition()
   max_number = 0
   for file_path in existing_files:
       # Only check files inside your folder
       if folder_path in file_path:
           match = pattern.search(file_path)  # â† use search instead of match
           if match:
               num = int(match.group(1))
               max_number = max(max_number, num)
   print("*************** STEP Get Highest Embedding DONE ******************")
   return max_number

# Function to get saved embedding
def get_existing_embedding(folder_id="Data_Folder"):
   print("*************** STEP Get Existing Embedding START ******************")
   folder = dataiku.Folder(folder_id)
   emb_no = get_highest_embedding_number(folder)
   filename=f"2026_02_11_Embedding/combined_data_embedding_new{emb_no:04d}.parquet"
   buffer = io.BytesIO()
   with folder.get_download_stream(filename) as stream:
       buffer.write(stream.read())
   buffer.seek(0)
   print("*************** STEP Get Existing Embedding DONE ******************")
   return pd.read_parquet(buffer)


# -----------------------------
# Token Counter
# -----------------------------
def count_tokens(text):
   return len(text) // 4


# -----------------------------
# Safe embedding with TPM control
# -----------------------------
def embed_batch_with_retry(texts):
   print("*************** STEP embed_batch_with_retry START ******************") 
   for attempt in range(MAX_RETRIES):
       try:
           response = client_aoai.embeddings.create(
               model=EMBEDDING_MODEL_NAME,
               input=texts
           )
           return [r.embedding for r in response.data]
       except Exception as e:
           retryable = any(
               word in str(e).lower()
               for word in ["rate limit", "timeout", "internal", "429"]
           )
           if not retryable or attempt == MAX_RETRIES - 1:
               raise
           sleep_time = 2 ** attempt
           print(f"Retry {attempt+1}, sleeping {sleep_time}s due to {e}")
           time.sleep(sleep_time)
   print("*************** STEP embed_batch_with_retry DONE ******************") 



def normalize_embedding_text(text: str) -> str:
  return " ".join(str(text or "").strip().lower().split())


def calculate_embed_batch_size(
   df,
   text_col,
   max_chunk_tokens=7000,
   model="text-embedding-3-large",
   safety_margin=0.90,
   quantile=0.90,
   max_batch_cap=128,
):
   if df is None or df.empty or text_col not in df.columns:
       return 1
   encoding = tiktoken.encoding_for_model(model)
   unique_texts = df[text_col].astype(str).drop_duplicates()
   token_counts = unique_texts.apply(lambda x: len(encoding.encode(x)))
   if token_counts.empty:
       return 1
   ref_tokens = max(1, int(token_counts.quantile(quantile)))
   usable_tokens = max(1, int(max_chunk_tokens * safety_margin))
   embed_batch_size = math.floor(usable_tokens / ref_tokens)
   return max(1, min(max_batch_cap, embed_batch_size))


def _load_embedding_cache_df(force_reload: bool = False) -> pd.DataFrame:
   global _EMBEDDING_CACHE_DF
   if _EMBEDDING_CACHE_DF is not None and not force_reload:
       return _EMBEDDING_CACHE_DF.copy()
   with _EMBEDDING_CACHE_LOCK:
       if _EMBEDDING_CACHE_DF is not None and not force_reload:
           return _EMBEDDING_CACHE_DF.copy()
       try:
           buffer = io.BytesIO()
           with data_folder.get_download_stream(EMBEDDING_CACHE_PATH) as stream:
               buffer.write(stream.read())
           buffer.seek(0)
           cache_df = pd.read_parquet(buffer)
       except Exception:
           cache_df = pd.DataFrame(columns=["cache_key", "embedding_json"])
       if "cache_key" not in cache_df.columns:
           cache_df["cache_key"] = ""
       if "embedding_json" not in cache_df.columns:
           cache_df["embedding_json"] = ""
       cache_df = cache_df[["cache_key", "embedding_json"]].copy()
       cache_df["cache_key"] = cache_df["cache_key"].astype(str)
       _EMBEDDING_CACHE_DF = cache_df
       return _EMBEDDING_CACHE_DF.copy()

def _save_embedding_cache_df(cache_df: pd.DataFrame) -> None:
   global _EMBEDDING_CACHE_DF
   serializable_df = cache_df[["cache_key", "embedding_json"]].copy()
   serializable_df["cache_key"] = serializable_df["cache_key"].astype(str)
   serializable_df = serializable_df.drop_duplicates(subset=["cache_key"], keep="last").reset_index(drop=True)
   buffer = io.BytesIO()
   serializable_df.to_parquet(buffer, index=False)
   buffer.seek(0)
   with data_folder.get_writer(EMBEDDING_CACHE_PATH) as writer:
       writer.write(buffer.read())
   _EMBEDDING_CACHE_DF = serializable_df.copy()   

def _build_embedding_batches(missing_df: pd.DataFrame, text_col: str, embed_batch_size: int):
   batches = []
   current_keys = []
   current_texts = []
   current_token_count = 0
   skipped_count = 0
   for _, row in missing_df.iterrows():
       cache_key = row["cache_key"]
       text = str(row[text_col])
       token_count = int(row["token_count"])
       if token_count > MAX_CHUNK_TOKENS:
           skipped_count += 1
           continue
       current_keys.append(cache_key)
       current_texts.append(text)
       current_token_count += token_count
       if len(current_texts) >= embed_batch_size:
           batches.append(
               {
                   "keys": current_keys,
                   "texts": current_texts,
                   "token_count": current_token_count,
               }
           )
           current_keys = []
           current_texts = []
           current_token_count = 0
   if current_texts:
       batches.append(
           {
               "keys": current_keys,
               "texts": current_texts,
               "token_count": current_token_count,
           }
       )
   if skipped_count:
       print(f"[get_embeddings] skipped oversized texts: {skipped_count}")
   return batches


def _embed_batches_parallel(batches, max_workers=2):
   if not batches:
       return []
   all_rows = []
   batch_index = 0
   window_start = time.time()
   window_used_tokens = 0
   while batch_index < len(batches):
       elapsed = time.time() - window_start
       if elapsed >= 60:
           window_start = time.time()
           window_used_tokens = 0
       wave = []
       wave_token_count = 0
       while batch_index < len(batches) and len(wave) < max_workers:
           batch = batches[batch_index]
           batch_tokens = int(batch["token_count"])
           if window_used_tokens + wave_token_count + batch_tokens > MAX_TPM:
               break
           wave.append((batch_index, batch))
           wave_token_count += batch_tokens
           batch_index += 1
       if not wave:
           sleep_time = max(0, 60 - (time.time() - window_start))
           if sleep_time > 0:
               print(f"[get_embeddings] TPM limit hit. Sleeping {sleep_time:.2f}s")
               time.sleep(sleep_time)
           window_start = time.time()
           window_used_tokens = 0
           continue
       ordered_results = {}
       with ThreadPoolExecutor(max_workers=min(max_workers, len(wave))) as executor:
           futures = {
               executor.submit(embed_batch_with_retry, batch["texts"]): (idx, batch)
               for idx, batch in wave
           }
           for future in as_completed(futures):
               idx, batch = futures[future]
               embeddings = future.result()
               ordered_results[idx] = [
                   {
                       "cache_key": key,
                       "embedding_json": json.dumps(emb),
                   }
                   for key, emb in zip(batch["keys"], embeddings)
               ]
       for idx in sorted(ordered_results):
           all_rows.extend(ordered_results[idx])
       window_used_tokens += wave_token_count
   return all_rows



# -----------------------------
# Main function
# -----------------------------

def get_embeddings(df, TEXT_COL, embed_batch_size=None, max_workers=2):
   print("*************** STEP get_embeddings START ******************")
   _ensure_resources_configured()
   if df is None or df.empty:
       return pd.DataFrame(columns=[TEXT_COL, "embedding"])
   working_df = df[[TEXT_COL]].copy()
   working_df[TEXT_COL] = working_df[TEXT_COL].astype(str)
   working_df["cache_key"] = working_df[TEXT_COL].map(normalize_embedding_text)
   unique_text_df = (
       working_df[[TEXT_COL, "cache_key"]]
       .drop_duplicates(subset=["cache_key"])
       .reset_index(drop=True)
   )
   use_persistent_cache = len(unique_text_df) >= SMALL_RUN_CACHE_BYPASS_UNIQUE_TEXTS
   if use_persistent_cache:
       cache_df = _load_embedding_cache_df()
       cache_key_to_embedding_json = (
           dict(zip(cache_df["cache_key"], cache_df["embedding_json"]))
           if not cache_df.empty else {}
       )
   else:
       cache_df = pd.DataFrame(columns=["cache_key", "embedding_json"])
       cache_key_to_embedding_json = {}
   missing_df = unique_text_df[
       ~unique_text_df["cache_key"].isin(cache_key_to_embedding_json.keys())
   ].copy()
   if not use_persistent_cache and len(missing_df) >= SMALL_RUN_CACHE_BYPASS_MISSES:
       use_persistent_cache = True
       cache_df = _load_embedding_cache_df()
       cache_key_to_embedding_json = (
           dict(zip(cache_df["cache_key"], cache_df["embedding_json"]))
           if not cache_df.empty else {}
       )
       missing_df = unique_text_df[
           ~unique_text_df["cache_key"].isin(cache_key_to_embedding_json.keys())
       ].copy()
   print(f"[get_embeddings] total unique texts: {len(unique_text_df)}")
   print(f"[get_embeddings] cache misses: {len(missing_df)}")
   print(f"[get_embeddings] cache hits: {len(unique_text_df) - len(missing_df)}")
   print(f"[get_embeddings] use_persistent_cache: {use_persistent_cache}")
   if not missing_df.empty:
       missing_df["token_count"] = missing_df[TEXT_COL].astype(str).apply(count_tokens)
       if embed_batch_size is None:
           embed_batch_size = calculate_embed_batch_size(
               missing_df,
               text_col=TEXT_COL,
               max_chunk_tokens=MAX_CHUNK_TOKENS,
               model=EMBEDDING_MODEL_NAME,
           )
       print(f"[get_embeddings] embed_batch_size: {embed_batch_size}")
       batches = _build_embedding_batches(
           missing_df=missing_df,
           text_col=TEXT_COL,
           embed_batch_size=embed_batch_size,
       )
       print(f"[get_embeddings] total batches: {len(batches)}")
       new_cache_rows = _embed_batches_parallel(
           batches=batches,
           max_workers=max_workers,
       )
       new_cache_df = pd.DataFrame(new_cache_rows) if new_cache_rows else pd.DataFrame(columns=["cache_key", "embedding_json"])
       if not new_cache_df.empty:
           new_cache_map = dict(zip(new_cache_df["cache_key"], new_cache_df["embedding_json"]))
           cache_key_to_embedding_json.update(new_cache_map)
           if use_persistent_cache:
               cache_df = pd.concat([cache_df, new_cache_df], ignore_index=True)
               cache_df = cache_df.drop_duplicates(subset=["cache_key"], keep="last").reset_index(drop=True)
               _save_embedding_cache_df(cache_df)
   result_df = working_df[[TEXT_COL, "cache_key"]].drop_duplicates(subset=[TEXT_COL]).copy()
   result_df["embedding"] = result_df["cache_key"].map(
       lambda key: json.loads(cache_key_to_embedding_json[key]) if key in cache_key_to_embedding_json else None
   )
   result_df.drop(columns=["cache_key"], inplace=True)
   print("*************** STEP get_embeddings DONE ******************")
   return result_df



# def get_embeddings(df, TEXT_COL):
#   print("*************** STEP get_embeddings START ******************")    
#   working_df = df[[TEXT_COL]].copy()
#   working_df[TEXT_COL] = working_df[TEXT_COL].astype(str)
#   working_df["cache_key"] = working_df[TEXT_COL].map(normalize_embedding_text)
#   cache_df = _load_embedding_cache_df()
#   cache_key_to_embedding_json = (
#       dict(zip(cache_df["cache_key"], cache_df["embedding_json"]))
#       if not cache_df.empty else {}
#   )
#   unique_text_df = (
#       working_df[[TEXT_COL, "cache_key"]]
#       .drop_duplicates(subset=["cache_key"])
#       .reset_index(drop=True)
#   )
#   missing_keys = [
#       row["cache_key"]
#       for _, row in unique_text_df.iterrows()
#       if row["cache_key"] not in cache_key_to_embedding_json
#   ]
#   token_budget = 0
#   start_time = time.time()
#   new_cache_rows = []
#   batch_keys = []
#   batch_texts = []
#   key_to_text = dict(zip(unique_text_df["cache_key"], unique_text_df[TEXT_COL]))
#   for cache_key in missing_keys:
#       text = str(key_to_text[cache_key])
#       tokens = count_tokens(text)
#       if tokens > MAX_CHUNK_TOKENS:
#           print(f"Skipping text >8191 tokens ({tokens})")
#           continue
#       if token_budget + tokens > MAX_TPM:
#           elapsed = time.time() - start_time
#           sleep_time = max(0, 60 - elapsed)
#           if sleep_time > 0:
#               print(f"TPM limit reached. Sleeping {sleep_time:.2f}s")
#               time.sleep(sleep_time)
#           token_budget = 0
#           start_time = time.time()
#       batch_keys.append(cache_key)
#       batch_texts.append(text)
#       token_budget += tokens
#       if len(batch_texts) >= EMBED_BATCH_SIZE:
#           embeddings = embed_batch_with_retry(batch_texts)
#           for key, emb in zip(batch_keys, embeddings):
#               new_cache_rows.append({
#                   "cache_key": key,
#                   "embedding_json": json.dumps(emb),
#               })
#           batch_keys = []
#           batch_texts = []
#   if batch_texts:
#       embeddings = embed_batch_with_retry(batch_texts)
#       for key, emb in zip(batch_keys, embeddings):
#           new_cache_rows.append({
#               "cache_key": key,
#               "embedding_json": json.dumps(emb),
#           })
#   if new_cache_rows:
#       new_cache_df = pd.DataFrame(new_cache_rows)
#       cache_df = pd.concat([cache_df, new_cache_df], ignore_index=True)
#       cache_df = cache_df.drop_duplicates(subset=["cache_key"], keep="last").reset_index(drop=True)
#       _save_embedding_cache_df(cache_df)
#   else:
#       cache_df = _load_embedding_cache_df()
#   cache_key_to_embedding_json = (
#       dict(zip(cache_df["cache_key"], cache_df["embedding_json"]))
#       if not cache_df.empty else {}
#   )
#   result_df = working_df[[TEXT_COL, "cache_key"]].drop_duplicates(subset=[TEXT_COL]).copy()
#   result_df["embedding"] = result_df["cache_key"].map(
#       lambda key: json.loads(cache_key_to_embedding_json[key]) if key in cache_key_to_embedding_json else None
#   )
#   result_df.drop(columns=["cache_key"], inplace=True)
#   print("*************** STEP get_embeddings DONE ******************")  
#   return result_df


# ==================== Binary & Categorical Processing ====================
def process_binary(df):
   return df[BINARY_COLS].replace({"True": 1, "False": 0, True: 1, False: 0}).fillna(0).astype(int).values
# ==================== Prediction Function ====================
def predict_via_neural_network(model, X_test_aligned):
#     X_test_aligned=[]
   X_np = X_test_aligned.values.astype("float32")
   logits = model.predict(X_np, verbose=0)
   y_proba = tf.nn.softmax(logits, axis=1).numpy()
   y_pred = np.argmax(y_proba, axis=1)
   return y_pred

def predict(df_input, max_workers=2):
   print("*************** STEP ML Prediction START ******************") 
   _ensure_resources_configured()
   df_cleaned = data_cleaning_pipeline(df_input.copy())
   embed_batch_size = calculate_embed_batch_size(
       df_cleaned,
       text_col=TEXT_COL,
       max_chunk_tokens=MAX_CHUNK_TOKENS,
       model=EMBEDDING_MODEL_NAME,
   )
   print(f"[predict] calculated embed_batch_size: {embed_batch_size}")
   embedding_df = get_embeddings(
       df_cleaned,
       TEXT_COL,
       embed_batch_size=embed_batch_size,
       max_workers=max_workers,
   )
   df_merged = df_cleaned.merge(
       embedding_df,
       on=TEXT_COL,
       how="left"
   )
   if df_merged["embedding"].isna().any():
       missing_count = int(df_merged["embedding"].isna().sum())
       raise ValueError(f"Missing embeddings for {missing_count} rows after merge.")
   rag_query_embeddings = df_merged["embedding"].tolist()
   df_final = df_merged.drop(columns=[TEXT_COL]).copy()
   X_test_df = df_final.drop(columns=[TARGET_COL], errors="ignore")
   # PCA
   X_test_emb = np.vstack(X_test_df["embedding"].values)
   X_test_pca = pca_model.transform(X_test_emb)
   df_X_test_pca = X_test_df.join(
       pd.DataFrame(X_test_pca, index=X_test_df.index).add_prefix("pca_")
   )
   df_X_test_pca.drop(columns=["embedding"], inplace=True)
   X_test_df = df_X_test_pca.copy()
   # Binary & Categorical
   X_test_text = X_test_df.drop(columns=[*BINARY_COLS, *CATEGORICAL_COLS], axis=1)
   X_test_bin = process_binary(X_test_df)
   ohe = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
   X_test_cat = ohe.fit_transform(X_test_df[CATEGORICAL_COLS])
   X_test_np = np.hstack([X_test_text, X_test_bin, X_test_cat])
   text_feature_names = [f"text_emb_{i}" for i in range(X_test_text.shape[1])]
   binary_feature_names = BINARY_COLS
   categorical_feature_names = ohe.get_feature_names_out(CATEGORICAL_COLS)
   feature_names = text_feature_names + binary_feature_names + list(categorical_feature_names)
   X_test_aligned = pd.DataFrame(X_test_np, columns=feature_names, index=X_test_df.index)
   # Align with training features
   X_test_aligned = X_test_aligned.reindex(columns=feature_trained_on, fill_value=0)
   # Predictions
   model1_pred = model1_pipeline.predict(X_test_aligned)
   model2_pred = model2_pipeline.predict(X_test_aligned)
   model3_pred = predict_via_neural_network(model3_pipeline, X_test_aligned)
   model1_pred_labelled = label_encoder_y.inverse_transform(model1_pred)
   model2_pred_labelled = label_encoder_y.inverse_transform(model2_pred)
   model3_pred_labelled = label_encoder_y.inverse_transform(model3_pred)
   print("*************** STEP ML Prediction DONE ******************") 
   return model1_pred_labelled, model2_pred_labelled, model3_pred_labelled, rag_query_embeddings

# def predict(df_input):
#   print("*************** STEP ML Prediction START ******************") 
#   df_cleaned = data_cleaning_pipeline(df_input.copy())
#   embedding_df = get_embeddings(df_cleaned, TEXT_COL)
#   df_merged = df_cleaned.merge(
#       embedding_df,
#       on="combined_description",
#       how="left"
#   )
#   rag_query_embeddings = df_merged["embedding"].tolist()
#   df_final = df_merged.drop(columns=[TEXT_COL]).copy()
#   X_test_df = df_final.drop(columns=[TARGET_COL])
#   # PCA
#   X_test_emb = np.vstack(X_test_df["embedding"].values)
#   X_test_pca = pca_model.transform(X_test_emb)
#   df_X_test_pca = X_test_df.join(
#       pd.DataFrame(X_test_pca, index=X_test_df.index).add_prefix("pca_")
#   )
#   df_X_test_pca.drop(columns=["embedding"], inplace=True)
#   X_test_df = df_X_test_pca.copy()
#   # Binary & Categorical
#   X_test_text = X_test_df.drop(columns=[*BINARY_COLS, *CATEGORICAL_COLS], axis=1)
#   X_test_bin = process_binary(X_test_df)
#   ohe = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
#   X_test_cat = ohe.fit_transform(X_test_df[CATEGORICAL_COLS])
#   X_test_np = np.hstack([X_test_text, X_test_bin, X_test_cat])
#   text_feature_names = [f"text_emb_{i}" for i in range(X_test_text.shape[1])]
#   binary_feature_names = BINARY_COLS
#   categorical_feature_names = ohe.get_feature_names_out(CATEGORICAL_COLS)
#   feature_names = text_feature_names + binary_feature_names + list(categorical_feature_names)
#   X_test_aligned = pd.DataFrame(X_test_np, columns=feature_names, index=X_test_df.index)
#   # Align with training features
#   X_test_aligned = X_test_aligned.reindex(columns=feature_trained_on, fill_value=0)
#   # Predictions
#   model1_pred = model1_pipeline.predict(X_test_aligned)
#   model2_pred = model2_pipeline.predict(X_test_aligned)
#   model3_pred = predict_via_neural_network(model3_pipeline, X_test_aligned)
#   model1_pred_labelled = label_encoder_y.inverse_transform(model1_pred)
#   model2_pred_labelled = label_encoder_y.inverse_transform(model2_pred)
#   model3_pred_labelled = label_encoder_y.inverse_transform(model3_pred)
#   print("*************** STEP ML Prediction DONE ******************") 
#   return model1_pred_labelled, model2_pred_labelled, model3_pred_labelled, rag_query_embeddings

def get_data(folder_name: str = "Data", filename: str = "consolidated_data_v2.csv") -> pd.DataFrame:
   folder = dataiku.Folder(folder_name)
   with folder.get_download_stream(filename) as stream:
       df = pd.read_csv(stream)
       df.columns = [col.lower().replace(" ", "_") for col in df.columns]
   return df

def merge_family_data(incoming_df):
   # Load and clean family dataset
   df_family = get_data(filename="Family-Classification_Mapping-UNSPSC-branch 1 (1).csv")
   df_family = df_family.dropna(subset=["unspsc_-_unspsc"])
   df_family["unspsc_-_unspsc"] = df_family["unspsc_-_unspsc"].astype(int)
   # Keep only Leaf Family rows
   df_leaf = df_family[df_family["type"] == "Leaf Family"]
   # Aggregate everything (including governance)
   df_family_grouped = (
       df_leaf
       .groupby("unspsc_-_unspsc")
       .agg({
           "governance": lambda x: "/".join(pd.unique(x.dropna().astype(str))),
           "parent_information": lambda x: "/".join(pd.unique(x.dropna().astype(str))),
           "branch": lambda x: "/".join(pd.unique(x.dropna().astype(str)))
           })
       .reset_index()
   )
   # Merge once
   df = (
       incoming_df
       .merge(df_family_grouped,
              left_on="unspsc_code",
              right_on="unspsc_-_unspsc",
              how="left")
       .drop(columns=["unspsc_-_unspsc"])
   )
   return df

def generate_ml_output(incoming_df, max_workers=2):
   df = incoming_df.copy()
   (
       model1_pred_labelled,
       model2_pred_labelled,
       model3_pred_labelled,
       rag_query_embeddings,
   ) = predict(df, max_workers=max_workers)
   df["Model1"] = model1_pred_labelled
   df["Model2"] = model2_pred_labelled
   df["Model3"] = model3_pred_labelled
   df["_rag_query_embedding"] = rag_query_embeddings
   return df

# def generate_ml_output(incoming_df):
#   df = incoming_df.copy()
#   model1_pred_labelled, model2_pred_labelled, model3_pred_labelled, rag_query_embeddings = predict(df)
#   df["Model1"] = model1_pred_labelled
#   df["Model2"] = model2_pred_labelled
#   df["Model3"] = model3_pred_labelled
#   df["_rag_query_embedding"] = rag_query_embeddings
#   return df

def normalize_unspsc_code(x):
    if x is None or (isinstance(x, float) and pd.isna(x)):
        return None

    if isinstance(x, (int,)):
        s = str(x)
        return s.zfill(8) if len(s) <= 8 else None

    if isinstance(x, float):
        if x.is_integer():
            s = str(int(x))
            return s.zfill(8) if len(s) <= 8 else None
        return None

    s = str(x).strip()

    m = re.match(r"^(\d{8})\.0+$", s)
    if m:
        return m.group(1)

    s = re.sub(r"\D", "", s)
    return s if len(s) == 8 else None


_GOV_INDEX_CACHE = None
_GOV_METADATA_CACHE = None
_GOV_CACHE_LOCK = threading.Lock()

def gov_index_vector(force_reload: bool = False):
  print("*************** STEP gov_index_vector START ******************")    
  global _GOV_INDEX_CACHE
  if _GOV_INDEX_CACHE is not None and not force_reload:
      return _GOV_INDEX_CACHE
  with _GOV_CACHE_LOCK:
      if _GOV_INDEX_CACHE is not None and not force_reload:
          return _GOV_INDEX_CACHE
      _ensure_resources_configured()
      folder = faiss_folder
      filename = "governance_faiss_new.index"
      # Read only
      with folder.get_download_stream(filename) as f:
          index_bytes = f.read()
      index_arr = np.frombuffer(index_bytes, dtype="uint8")
      gov_index = faiss.deserialize_index(index_arr)
      _GOV_INDEX_CACHE = gov_index
      print("*************** STEP gov_index_vector DONE ******************")  
      return _GOV_INDEX_CACHE


def gov_metadata_vector(force_reload: bool = False):
  print("*************** STEP gov_metadata_vector START ******************")   
  global _GOV_METADATA_CACHE
  if _GOV_METADATA_CACHE is not None and not force_reload:
      return _GOV_METADATA_CACHE
  with _GOV_CACHE_LOCK:
      if _GOV_METADATA_CACHE is not None and not force_reload:
          return _GOV_METADATA_CACHE
      _ensure_resources_configured()
      folder = faiss_folder
      # Read only
      with folder.get_download_stream("governance_metadata_new.json") as f:
          gov_metadata = json.load(f)
      _GOV_METADATA_CACHE = gov_metadata
      print("*************** STEP gov_metadata_vector DONE ******************")     
      return _GOV_METADATA_CACHE
    

def retrieve_governance_context(query_text=None, query_embedding=None, k=5):
   print("*************** STEP retrieve_governance_context START ******************") 
   _ensure_resources_configured()
   if query_embedding is not None:
       if isinstance(query_embedding, str):
           query_embedding = json.loads(query_embedding)
       query_vec = np.array(query_embedding, dtype="float32").reshape(1, -1)
   else:
       query_emb = client_aoai.embeddings.create(
           model=EMBEDDING_MODEL_NAME,
           input=[str(query_text).lower()]
       )
       query_vec = np.array(
           query_emb.data[0].embedding,
           dtype="float32"
       ).reshape(1, -1)
   gov_index = gov_index_vector()
   gov_metadata = gov_metadata_vector()
   D, I = gov_index.search(query_vec, k)
   retrieved = []
   for idx, dist in zip(I[0], D[0]):
       if idx < 0 or idx >= len(gov_metadata):
           continue
       item = gov_metadata[idx].copy()
       item["distance"] = float(dist)
       retrieved.append(item)
   print("*************** STEP retrieve_governance_context DONE ******************") 
   return retrieved



# def retrieve_governance_context(query_text=None, query_embedding=None, k=5):
#   print("*************** STEP retrieve_governance_context START ******************")   
#   if query_embedding is not None:
#       if isinstance(query_embedding, str):
#           query_embedding = json.loads(query_embedding)
#       query_vec = np.array(query_embedding, dtype="float32").reshape(1, -1)
#   else:
#       query_emb = client_aoai.embeddings.create(
#           model=EMBEDDING_MODEL_NAME,
#           input=[str(query_text).lower()]
#       )
#       query_vec = np.array(
#           query_emb.data[0].embedding,
#           dtype="float32"
#       ).reshape(1, -1)
#   gov_index = gov_index_vector()
#   gov_metadata = gov_metadata_vector()
#   D, I = gov_index.search(query_vec, k)
#   retrieved = []
#   for idx, dist in zip(I[0], D[0]):
#       if idx < 0 or idx >= len(gov_metadata):
#           continue
#       item = gov_metadata[idx].copy()
#       item["distance"] = float(dist)
#       retrieved.append(item)
#   print("*************** STEP retrieve_governance_context DONE ******************")     
#   return retrieved

def extract_unspsc_candidates(retrieved_items):
    candidates = {}
    for item in retrieved_items:
        code = normalize_unspsc_code(item.get("UNSPSC code"))
        if not code:
            continue

        family = item["Family Name English information"]
        part = item["Short Description (English)"]

        if code not in candidates:
            candidates[code] = {
                "family": family,
                "parent": item["Parent information"],
                "description": item["Description"],
                "part" : part

            }

    return candidates


def build_rag_prompt(part_description, retrieved_items, unspsc_candidates, model_preds=None):
    print("*************** STEP build_rag_prompt START ******************")
    governance_lines = []

    for item in retrieved_items:

        examples = []
        for i in range(1, 11):
            col_name = "Part Description Example " + str(i)
            if col_name in item and item[col_name] is not None:
                examples.append(str(item[col_name]))

        example_text = ", ".join(examples)

        line = (
            f"- Family: {item['Family Name English information']}, "
            f"Parent: {item['Parent information']}, "
            f"Description: {item['Description']}, "
            f"UNSPSC: {item['UNSPSC code']}, "
            f"Part: {item['Short Description (English)']},"
            f"Examples: {example_text}"

        )

        governance_lines.append(line)

    governance_context = "\n".join(governance_lines)

    candidate_context = "\n".join(
        [
            f"- UNSPSC {code}: Family {info['family']}, "
            f"Parent {info['parent']}, Description {info['description']}, Part{info['part']}"
            for code, info in unspsc_candidates.items()
        ]
    )


    model_block = ""
    if model_preds:
        model_block = f"""
    Model predictions (only consider these if they are supported by the Knowledge Base Context):
    - Model 1: {model_preds.get("model1")}
    - Model 2: {model_preds.get("model2")}
    - Model 3: {model_preds.get("model3")}
    """

    prompt = f"""

You are a UNSPSC classification expert working with Alstom governance rules and also an LLM that will act as a judge to select the rightly classified UNSPSC code.
You are an SME in Alstom who understands the entered part descriptions and then can match it to the 
family and parent details that it is most likely to fall under and generate the UNSPSC code accordingly.
Also look at the examples of part descriptions already matched correctly to their descriptions and use the sam approach for the new parts.
Look at all the candidates in the candidate_context and governance_context and choose the most appropriate UNSPSC code.


Part description:
"{part_description}"
{model_block}

Knowledge Base Context:
{governance_context}

Allowed UNSPSC candidates:
{candidate_context}

Judge rule:
1) First validate the Model 1 / Model 2 / Model 3 outputs against the Knowledge Base Context and check whether any model-predicted UNSPSC is a correct and supported match, using Short Description (English) where present; if Short Description is not available for a candidate, fall back to validating via Family and Parent context.  // UPDATED
    1a) If multiple model outputs are partially supported, rank them and select the best-supported one instead of rejecting all by default.
2) If one of the model codes is correct, select that exact code and treat it as accepted by the LLM, with reasoning supported by the Knowledge Base.  // UPDATED
3) If none of the model codes is correct or supported by the Knowledge Base, explicitly reject the model outputs and select the best UNSPSC ONLY from the Allowed UNSPSC candidates using Knowledge Base reasoning (prioritizing Short Description (English) match where present; otherwise Family/Parent match).  // UPDATED
4) Do NOT output a blank or empty GenAI result. If an exact match is not available, select the closest possible Family and Parent from the Knowledge Base.  // UPDATED
5) If no reasonable match exists even at the closest part description match or Family level, output UNSPSC: NONE.
6) If two UNSPSC candidates are equally valid, select the one with the closest functional use over material or form factor.

Rule:
Review the information entered and identify the closest part description match, Short Description (English) match (where available), and then Family and Parent match for the entered Part description.
Cross-reference the entries in the UNSPSC column.
Only map UNSPSC codes from the given data and not from any external source outside the Alstom master data used to create the knowledge base.
Prefer UNSPSC codes that have an explicit and exact match in the Knowledge Base over semantically similar but higher-level matches.

Notes:
Provide any pertinent but concise explanations for your classification choices.
Avoid selecting overly generic or catch-all families if a more specific Family or Parent is available in the Knowledge Base.

Output rules (mandatory):
- The first line MUST be exactly: UNSPSC: <8-digit code>  OR  UNSPSC: NONE
- The second line MUST be: Explanation: <one sentence>
- Do not add any extra lines or text.

Explanation Requirements:
The explanation must clearly describe the decision flow:

- First state whether any ML Model–predicted UNSPSC was validated and accepted by the LLM, using Knowledge Base support via Short Description (English) where present, otherwise Family/Parent context.  // UPDATED
- If a Model output is accepted, clearly mention that the final UNSPSC is selected from the Model output and justify it using Knowledge Base support.  // UPDATED
- If Model outputs are rejected, explain why they are not supported by the Knowledge Base.  // UPDATED
- If the final UNSPSC is selected by the LLM, clearly state that it is chosen from the Knowledge Base (not ML) and explain why it is the closest match (prioritizing Short Description (English) where present; otherwise Family/Parent match).  // UPDATED
- The explanation must always make it explicit whether the final UNSPSC came from ML acceptance or LLM (KB-based) judgment.
- The explanation must be exactly ONE sentence and must not contain multiple decision paths.

Respond in the following format:
UNSPSC: <8-digit code>
Explanation: <as per explanation requirements>

"""
    print("*************** STEP build_rag_prompt DONE ******************")
    return prompt


def parse_genai_response(text: str):
    """
    Robustly extract an 8-digit UNSPSC from the LLM output.
    1) Prefer 'UNSPSC: ########'
    2) If missing, fallback to any standalone 8-digit number in the text
    Also extract explanation if present.
    """
    m = re.search(r"UNSPSC\s*:\s*(\d{8}|NONE)", text, re.IGNORECASE)
    predicted = m.group(1) if m else None
    if predicted and predicted.upper() == "NONE":
        predicted = None

    if predicted is None:
        m2 = re.search(r"\b(\d{8})\b", text)
        predicted = m2.group(1) if m2 else None

    em = re.search(r"Explanation\s*:\s*(.*?)(?:Confidence\s*:|$)", text, re.DOTALL | re.IGNORECASE)
    explanation = em.group(1).strip() if em else ""

    return predicted, explanation


# def predict_unspsc_with_rag(part_description, model1=None, model2=None, model3=None):
#     print("*************** STEP predict_unspsc_with_rag START ******************")
#     gov_metadata = gov_metadata_vector()
#     KB_CODES = set()
#     for item in gov_metadata:
#         code = normalize_unspsc_code(item.get("UNSPSC code"))
#         if code:
#             KB_CODES.add(code)

#     retrieved = retrieve_governance_context(part_description, k=5)
#     unspsc_candidates = extract_unspsc_candidates(retrieved)
#     m1 = normalize_unspsc_code(model1)
#     m2 = normalize_unspsc_code(model2)
#     m3 = normalize_unspsc_code(model3)

#     m1 = m1 if m1 in KB_CODES else None
#     m2 = m2 if m2 in KB_CODES else None
#     m3 = m3 if m3 in KB_CODES else None

#     model_preds = {"model1": m1, "model2": m2, "model3": m3}
#     prompt = build_rag_prompt(part_description, retrieved, unspsc_candidates, model_preds=model_preds)

#     response = client_gpt.chat.completions.create(
#         model="gpt-5.1",
#         messages=[
#             {"role": "system", "content": "You are a UNSPSC part classification subject matter expert and an LLM as a judge."},
#             {"role": "user", "content": prompt}
#         ],
#         temperature=0
#     )

#     raw_text = response.choices[0].message.content
#     predicted_unspsc, explanation = parse_genai_response(raw_text)
#     if predicted_unspsc is None:
#         for c in [m1, m2, m3]:
#             if c and c in KB_CODES:
#                 predicted_unspsc = c
#                 if not explanation:
#                     explanation = "Chosen from ML model outputs because LLM did not return a valid UNSPSC line."
#                 break

#     if predicted_unspsc is None and len(unspsc_candidates) > 0:
#         predicted_unspsc = next(iter(unspsc_candidates.keys()))
#         if not explanation:
#             explanation = "Chosen from top retrieved KB candidate because no valid model code was accepted."

#     predicted_unspsc = normalize_unspsc_code(predicted_unspsc)
#     if predicted_unspsc and predicted_unspsc not in KB_CODES:
#         predicted_unspsc = None

#     if predicted_unspsc is None:
#         source = "NONE"
#     elif predicted_unspsc == m1:
#         source = "ML(Model1)"
#     elif predicted_unspsc == m2:
#         source = "ML(Model2)"
#     elif predicted_unspsc == m3:
#         source = "ML(Model3)"
#     else:
#         source = "GenAI"
#     print("*************** STEP predict_unspsc_with_rag DONE ******************")
#     return predicted_unspsc, explanation, source


def predict_unspsc_with_rag(part_description, model1=None, model2=None, model3=None, query_embedding=None):
    print("*************** STEP predict_unspsc_with_rag START ******************")
    gov_metadata = gov_metadata_vector()
    KB_CODES = set()
    for item in gov_metadata:
       code = normalize_unspsc_code(item.get("UNSPSC code"))
       if code:
           KB_CODES.add(code)
    retrieved = retrieve_governance_context(
       query_text=part_description,
       query_embedding=query_embedding,
       k=5
    )
    unspsc_candidates = extract_unspsc_candidates(retrieved)
    m1 = normalize_unspsc_code(model1)
    m2 = normalize_unspsc_code(model2)
    m3 = normalize_unspsc_code(model3)

    m1 = m1 if m1 in KB_CODES else None
    m2 = m2 if m2 in KB_CODES else None
    m3 = m3 if m3 in KB_CODES else None

    model_preds = {"model1": m1, "model2": m2, "model3": m3}
    prompt = build_rag_prompt(part_description, retrieved, unspsc_candidates, model_preds=model_preds)

    response = client_gpt.chat.completions.create(
        model="gpt-5.1",
        messages=[
            {"role": "system", "content": "You are a UNSPSC part classification subject matter expert and an LLM as a judge."},
            {"role": "user", "content": prompt}
        ],
        temperature=0
    )

    raw_text = response.choices[0].message.content
    predicted_unspsc, explanation = parse_genai_response(raw_text)
    if predicted_unspsc is None:
        for c in [m1, m2, m3]:
            if c and c in KB_CODES:
                predicted_unspsc = c
                if not explanation:
                    explanation = "Chosen from ML model outputs because LLM did not return a valid UNSPSC line."
                break

    if predicted_unspsc is None and len(unspsc_candidates) > 0:
        predicted_unspsc = next(iter(unspsc_candidates.keys()))
        if not explanation:
            explanation = "Chosen from top retrieved KB candidate because no valid model code was accepted."

    predicted_unspsc = normalize_unspsc_code(predicted_unspsc)
    if predicted_unspsc and predicted_unspsc not in KB_CODES:
        predicted_unspsc = None

    if predicted_unspsc is None:
        source = "NONE"
    elif predicted_unspsc == m1:
        source = "ML(Model1)"
    elif predicted_unspsc == m2:
        source = "ML(Model2)"
    elif predicted_unspsc == m3:
        source = "ML(Model3)"
    else:
        source = "GenAI"
    print("*************** STEP predict_unspsc_with_rag DONE ******************")
    return predicted_unspsc, explanation, source
