import streamlit as st
import base64
from utils.role_ui import get_visible_top_nav_items
from utils.styles import load_css, get_global_css, get_home_page_css
from services.access_control_service import get_current_user_permissions

def get_base64_image(image_path):
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label, slug, active=False):
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def home_action_card(label, page, sub=None):
   sub_input = ""
   if sub is not None:
       sub_input = f'<input type="hidden" name="sub" value="{sub}">'
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{page}">
   {sub_input}
<button type="submit" class="home-action-card">{label}</button>
</form>
   """

def render():
   load_css(get_global_css() + get_home_page_css())
   permissions = get_current_user_permissions()
   logo_base64 = get_base64_image(
       "/home/dataiku/workspace/code_studio-versioned/streamlit/assets/Alstom_logo.svg.png"
   )
   nav_html = "".join(
       nav_pill(label, slug, active=(slug == "home"))
       for label, slug in get_visible_top_nav_items()
   )
   left_cards = []
   right_cards = []
   if permissions["can_classify"]:
       left_cards.append(
           home_action_card("Classify Existing Parts", "classify_existing", "existing_parts")
       )
       left_cards.append(
           home_action_card("RUNS", "classify_existing", "runs")
       )
       right_cards.append(
           home_action_card("Create New Parts", "create_new_parts")
       )
   if permissions["can_validate"]:
       left_cards.insert(
           1,
           home_action_card("Validate Classified Parts", "validation")
       )
   left_cards_html = "".join(left_cards)
   right_cards_html = "".join(right_cards)
   st.markdown(
       f"""
<div class="home-shell">
<div class="brand-panel">
<div class="brand-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="brand-logo-img"/>
</div>
<div class="brand-title">AI-Parts Classifier</div>
<div class="brand-subtitle">Home</div>
</div>
<div class="content-panel">
<div class="nav-strip">
           {nav_html}
</div>
<hr class="section-divider"/>
<div class="options-title">Options</div>
<div class="home-custom-layout">
<div class="home-custom-left">
               {left_cards_html}
</div>
<div class="home-custom-divider"></div>
<div class="home-custom-right">
               {right_cards_html}
</div>
</div>
</div>
</div>
       """,
       unsafe_allow_html=True
   )