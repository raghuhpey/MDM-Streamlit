import base64
import streamlit as st
from services.access_control_service import get_current_user_permissions
from utils.styles import (
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def get_base64_image(image_path: str) -> str:
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label: str, slug: str, active: bool = False) -> str:
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def option_card(label: str, target_page: str, disabled: bool = False) -> str:
   if disabled:
       return f"""
<div class="option-card-wrap-disabled">
<div class="option-card disabled">{label}</div>
</div>
       """
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{target_page}">
<button type="submit" class="option-card">{label}</button>
</form>
   """

def render():
   load_css(
       get_global_css()
       + get_home_page_css()
       + get_classify_page_css()
   )
   permissions = get_current_user_permissions()
   logo_base64 = get_base64_image("assets/Alstom_logo.svg.png")
   left_col, right_col = st.columns([1, 4.35], gap="medium")
   with left_col:
       st.markdown(
           f"""
<div class="classify-left-panel">
<div class="classify-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="classify-logo-img"/>
</div>
<div class="classify-title">AI-Parts Classifier</div>
<hr class="left-divider"/>
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           f"""
<div class="classify-topbar">
               {nav_pill("🏠 Home", "home")}
               {nav_pill("🔒 Admin", "admin", active=True)}
               {nav_pill("🛡️ Super Admin", "super_admin")}
               {nav_pill("ℹ️ About", "about")}
               {nav_pill("❓ Help", "help")}
</div>
<hr class="page-divider"/>
           """,
           unsafe_allow_html=True
       )
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Admin</div>
<div class="section-card-subtitle">
                   Choose an administrative function.
</div>
</div>
           """,
           unsafe_allow_html=True
       )
       st.markdown(
           f"""
<div style="margin-top:18px; max-width:460px;">
               {option_card("Model Retraining", "retraining", disabled=not permissions["can_retrain"])}
</div>
           """,
           unsafe_allow_html=True
       )