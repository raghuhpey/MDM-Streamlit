import base64
import streamlit as st
from services.validation_report_service import fetch_validation_report_df
from utils.role_ui import get_visible_top_nav_items
from utils.styles import (
   get_classify_page_css,
   get_global_css,
   get_home_page_css,
   load_css,
)

def get_base64_image(image_path: str) -> str:
   with open(image_path, "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def nav_pill(label: str, slug: str, active: bool = False) -> str:
   css_class = "nav-pill active" if active else "nav-pill"
   return f"""
<form method="get" style="margin:0;">
<input type="hidden" name="page" value="{slug}">
<button type="submit" class="{css_class}">{label}</button>
</form>
   """

def render():
   load_css(
       get_global_css()
       + get_home_page_css()
       + get_classify_page_css()
   )
   logo_base64 = get_base64_image("assets/Alstom_logo.svg.png")
   nav_html = "".join(
       nav_pill(label, slug, active=(slug == "validation_report"))
       for label, slug in get_visible_top_nav_items()
   )
   report_df = fetch_validation_report_df()
   left_col, right_col = st.columns([1.15, 4.35], gap="medium")
   with left_col:
       st.markdown(
           f"""
<div class="classify-left-panel">
<div class="classify-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="classify-logo-img"/>
</div>
<div class="classify-title">AI-Parts Classifier</div>
<div class="classify-subtitle">Validation Report</div>
</div>
           """,
           unsafe_allow_html=True
       )
   with right_col:
       st.markdown(
           f"""
<div class="classify-topbar">
               {nav_html}
</div>
<hr class="page-divider"/>
           """,
           unsafe_allow_html=True
       )
       st.markdown(
           """
<div class="section-card">
<div class="section-card-title">Validation Report</div>
<div class="section-card-subtitle">
                   Run-wise validation summary including pending records and current status.
</div>
</div>
           """,
           unsafe_allow_html=True
       )

       st.markdown("***")
       if report_df.empty:
           st.markdown(
               """
<div class="section-card">
<div class="empty-state-box">No validation report data available.</div>
</div>
               """,
               unsafe_allow_html=True
           )
       else:
           st.dataframe(report_df, use_container_width=True, hide_index=True)