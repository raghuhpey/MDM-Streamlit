import base64
from pathlib import Path
from urllib.parse import urlencode
import streamlit as st
from utils.role_ui import get_visible_top_nav_items

def _asset_path(filename: str = "Alstom_logo.svg.png") -> Path:
   return Path(__file__).resolve().parents[1] / "assets" / filename

def get_base64_image(filename: str = "Alstom_logo.svg.png") -> str:
   with open(_asset_path(filename), "rb") as img_file:
       return base64.b64encode(img_file.read()).decode()

def _build_href(page_value: str, sub_value: str | None = None, run_id: str | None = None) -> str:
   params = {"page": page_value}
   if sub_value:
       params["sub"] = sub_value
   if run_id:
       params["run_id"] = run_id
   return f"?{urlencode(params)}"

def nav_pill(label: str, slug: str, active: bool = False) -> str:
   css_class = "nav-pill active" if active else "nav-pill"
   href = _build_href(slug)
   return f'<a href="{href}" target="_self" class="{css_class}">{label}</a>'

def sidebar_menu_btn(label: str, page_value: str, sub_value: str | None = None, active: bool = False) -> str:
   css_class = "left-menu-btn active" if active else "left-menu-btn"
   href = _build_href(page_value, sub_value=sub_value)
   return f'<a href="{href}" target="_self" class="{css_class}">{label}</a>'

def render_sidebar(title: str = "AI-Parts Classifier", subtitle: str = "", section_label: str | None = None, menu_items: list[dict] | None = None) -> None:
   logo_base64 = get_base64_image()
   menu_html = ""
   if section_label and menu_items:
       items_html = "".join(
           sidebar_menu_btn(
               item["label"],
               item["page"],
               item.get("sub"),
               item.get("active", False),
           )
           for item in menu_items
       )
       menu_html = f"""
<hr class="left-divider"/>
<div class="left-group-title">{section_label}</div>
{items_html}
       """
   with st.sidebar:
       st.markdown(
           f"""
<div class="app-sidebar-inner">
<div class="classify-logo-wrap">
<img src="data:image/png;base64,{logo_base64}" class="classify-logo-img"/>
</div>
<div class="classify-title">{title}</div>
 {menu_html}
</div>
           """,
           unsafe_allow_html=True,
       )

def render_top_nav(active_slug: str | None = None) -> None:
   nav_html = "".join(
       nav_pill(label, slug, active=(slug == active_slug))
       for label, slug in get_visible_top_nav_items()
   )
   st.markdown(
       f"""
<div class="app-topbar-wrap">
<div class="classify-topbar">
   {nav_html}
</div>
<hr class="page-divider"/>
</div>
       """,
       unsafe_allow_html=True,
   )