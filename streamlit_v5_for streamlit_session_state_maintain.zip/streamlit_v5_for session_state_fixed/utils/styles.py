import streamlit as st
def load_css(css: str):
  st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)
def get_global_css():
  return """
  .stApp {
      background-color: #ffffff;
  }
  header[data-testid="stHeader"] {
      height: 0rem;
      background: transparent;
  }
  [data-testid="stToolbar"] {
      right: 10px;
      top: 10px;
  }
  #MainMenu {
      visibility: hidden;
  }
  footer {
      visibility: hidden;
  }
  .block-container {
      padding-top: 1rem;
      padding-left: 0.7rem;
      padding-right: 0.7rem;
      padding-bottom: 1rem;
      max-width: 100%;
  }
  """
def get_app_shell_css():
  return """
  section[data-testid="stSidebar"] {
      width: 270px !important;
      min-width: 270px !important;
      border-right: none !important;
  }
  section[data-testid="stSidebar"] > div {
      width: 270px !important;
      background: #0f4f70 !important;
  }
  section[data-testid="stSidebar"] [data-testid="stSidebarContent"] {
      background: #0f4f70 !important;
      min-height: 100vh;
      padding: 0rem 0rem 0rem 0rem;
  }
  section[data-testid="stSidebar"] .block-container {
      padding: 0 !important;
  }
  [data-testid="stSidebarCollapseButton"] {
      display: none;
  }
  .app-sidebar-inner {
      min-height: calc(100vh - 1.7rem);
      background: #0f4f70;
      border-radius: 18px;
      padding: 14px 10px 20px 10px;
      color: #ffffff;
      box-sizing: border-box;
  }
  .app-sidebar-page-name {
      font-size: 13px;
      font-weight: 700;
      color: #dbe8ff;
      margin-top: 8px;
      line-height: 1.35;
  }
  .classify-logo-wrap {
      margin-bottom: 22px;
  }
  .classify-logo-img {
      width: 100%;
      max-width: 245px;
      display: block;
      border-radius: 3px;
  }
  .classify-title {
      font-size: 18px;
      font-weight: 700;
      color: #ffffff;
      margin-bottom: 8px;
      line-height: 1.3;
  }
  .left-group-title {
      font-size: 13px;
      font-weight: 700;
      color: #dbe8ff;
      margin-top: 10px;
      margin-bottom: 14px;
  }
  .left-divider {
      border: none;
      height: 1px;
      background: rgba(255,255,255,0.18);
      margin-top: 18px;
      margin-bottom: 16px;
  }
  .left-menu-form {
      margin: 0 0 10px 0;
  }
  .left-menu-btn {
      width: 100%;
      border: 1px solid #d7d9dd;
      border-radius: 10px;
      padding: 11px 12px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      background: #f7f7f8;
      color: #4b5563;
      box-sizing: border-box;
      font-family: inherit;
      appearance: none;
      -webkit-appearance: none;
  }
  .left-menu-btn.active {
      background: #f44747;
      color: #ffffff;
      border-color: #f44747;
  }
  .app-topbar-wrap {
      position: sticky;
      top: 0;
      z-index: 10;
      background: #ffffff;
      padding-top: 0rem;
  }
  .classify-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 18px;
      display: grid;
      grid-template-columns: repeat(5, minmax(0, 5fr));
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 10px;
  }
  .nav-pill {
      background: #f7f7f8;
      border: 1px solid #d6d8dd;
      border-radius: 12px;
      text-align: center;
      padding: 12px 10px;
      font-size: 14px;
      font-weight: 600;
      color: #6b7280 !important;
      line-height: 1.2;
      box-sizing: border-box;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      display: block;
      text-decoration: none !important;
      transition: 0.1s ease;
      width: 100%;
      cursor: pointer;
      appearance: none;
      -webkit-appearance: none;
      font-family: inherit;
  }
  .nav-pill:hover {
      transform: translateY(-1px);
  }
  .nav-pill.active {
      background: #f44747;
      color: #ffffff !important;
      border-color: #f44747;
  }
  .page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  @media (max-width: 1200px) {
      .classify-topbar {
          grid-template-columns: repeat(3, minmax(0, 1fr));
      }
  }
  @media (max-width: 900px) {
      section[data-testid="stSidebar"] {
          width: 100% !important;
          min-width: 100% !important;
      }
      section[data-testid="stSidebar"] > div {
          width: 100% !important;
      }
      .app-sidebar-inner {
          min-height: auto;
      }
      .classify-topbar {
          grid-template-columns: repeat(2, minmax(0, 1fr));
      }
  }
  @media (max-width: 600px) {
      .classify-topbar {
          grid-template-columns: 1fr;
      }
  }
  """

def get_home_page_css():
  return """
  .home-shell {
      display: flex;
      gap: 18px;
      align-items: flex-start;
      width: 100%;
      box-sizing: border-box;
  }
  .brand-panel {
      background: #0f4f70;
      border-radius: 22px;
      padding: 24px 20px;
      min-height: 620px;
      box-sizing: border-box;
      color: #ffffff;
  }
  .brand-logo-wrap {
      margin-bottom: 22px;
  }
  .brand-logo-img {
      width: 250px;
      max-width: 100%;
      display: block;
  }
  .brand-title {
      font-size: 18px;
      font-weight: 700;
      color: #ffd8cc;
      margin-bottom: 8px;
      line-height: 1.3;
  }
  .brand-subtitle {
      font-size: 13px;
      font-weight: 600;
      color: #dbe8ff;
      line-height: 1.35;
  }
  .content-panel {
      flex: 1;
      box-sizing: border-box;
      min-width: 0;
  }
  .nav-strip {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 34px;
  }
  .nav-pill {
  background: #f7f7f8;
  border: 1px solid #d6d8dd;
  border-radius: 14px;
  text-align: center;
  padding: 13px 10px;
  font-size: 15px;
  font-weight: 600;
  color: #6b7280 !important;
  line-height: 1.2;
  box-sizing: border-box;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: block;
  text-decoration: none !important;
  transition: 0.2s ease;
  width: 100%;
  cursor: pointer;
  appearance: none;
  -webkit-appearance: none;
  font-family: inherit;
  }
  .nav-pill:hover {
  transform: translateY(-1px);
  }
  .nav-pill.active {
  background: #f44747;
  color: #ffffff !important;
  border: 1px solid #f44747;
  }
  .section-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 18px;
      margin-bottom: 34px;
  }
  .option-card.disabled {
  background: #e5e7eb !important;
  color: #6b7280 !important;
  border: 1px solid #d1d5db !important;
  box-shadow: none !important;
  cursor: not-allowed !important;
  pointer-events: none !important;
  opacity: 0.85;
  }
  .option-card-wrap-disabled {
  margin: 0;
  }
  .option-card-disabled-note {
  margin-top: 6px;
  font-size: 12px;
  color: #9ca3af;
  }
  .options-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 28px;
      line-height: 1.2;
  }
  .options-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 24px;
      width: 100%;
  }
  .option-card {
  background: #dce9fb;
  border: 1px solid #c9daf4;
  border-radius: 16px;
  text-align: center;
  padding: 10px 14px;
  font-size: 15px;
  font-weight: 600;
  color: #566fbe !important;
  box-sizing: border-box;
  display: block;
  text-decoration: none !important;
  transition: 0.2s ease;
  width: 100%;
  cursor: pointer;
  appearance: none;
  -webkit-appearance: none;
  font-family: inherit;
}
  .option-card:hover {
  transform: translateY(-1px);
  background: #d4e4fb;
}
  @media (max-width: 1200px) {
      .nav-strip {
          grid-template-columns: 1fr 1fr 1fr;
      }
      .options-grid {
          grid-template-columns: 1fr;
      }
  }
  @media (max-width: 900px) {
      .home-shell {
          flex-direction: column;
      }
      .brand-panel {
          width: 100%;
          min-height: 220px;
          border-radius: 22px;
      }
      .nav-strip {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 600px) {
      .nav-strip {
          grid-template-columns: 1fr;
      }
  }
  .home-options-row {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 26px;
  margin-top: 50px;
  align-items: start;
  }
  .option-card-home {
  background: #0f4f70 !important;
  color: #ffffff !important;
  border-radius: 12px !important;
  min-height: 60px !important;
  font-size: 25px !important;
  font-weight: 700 !important;
  box-shadow: none !important;
  }
  .option-card-home:hover {
  background: #0c4561 !important;
  color: #ffffff !important;
  }
  @media (max-width: 1200px) {
   .home-options-row {
      grid-template-columns: repeat(2, minmax(0, 1fr));
   }
  }
  @media (max-width: 700px) {
   .home-options-row {
      grid-template-columns: 1fr;
   }
  }
  .home-custom-layout {
  display: grid;
  grid-template-columns: 1fr 24px 1fr;
  gap: 38px;
  align-items: start;
  margin-top: 42px;
  min-height: 420px;
  }
  .home-custom-left{
  display: flex;
  flex-direction: column;
  justify-content:center;
  align-items: center;
  gap: 50px;
  padding-top: 25px;
 }
  .home-custom-right {
  display: flex;
  flex-direction: column;
  justify-content:center;
  align-items: center;
  gap: 50px;
  padding-top: 120px;
 }
  .home-custom-divider {
  width: 2px;
  min-height: 380px;
  background: #D3D3D3;
  justify-self: center;
  border-radius: 1px;
}
  .home-action-card {
  width: 450px !important;
  max-width: 100% !important;
  min-height: 62px !important;
  border-radius: 12px !important;
  border: 3px solid #93bdd4 !important;
  background: #0f5778 !important;
  color: #ffffff !important;
  font-size: 17px !important;
  font-weight: 800 !important;
  cursor: pointer !important;
  box-shadow: none !important;
   }
  .home-action-card:hover {
  background: #0b4865 !important;
  color: #ffffff !important;
   }
  .home-action-card,
  .nav-pill,
  .left-menu-btn {
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  text-align: center !important;
  text-decoration: none !important;
  line-height: 1.2 !important;
  }
  .home-action-card:visited,
  .home-action-card:hover,
  .home-action-card:focus,
  .nav-pill:visited,
  .nav-pill:hover,
  .nav-pill:focus,
  .left-menu-btn:visited,
  .left-menu-btn:hover,
  .left-menu-btn:focus {
  text-decoration: none !important;
  }
  @media (max-width: 1200px) {
  .home-custom-layout {
      grid-template-columns: 1fr;
      gap: 24px;
  }
  .home-custom-divider {
      display: none;
  }
  .home-custom-left,
  .home-custom-right {
      padding-top: 0;
  }
}
  """

def get_workflow_page_css():
  return """
  .workflow-shell {
      display: flex;
      gap: 18px;
      align-items: flex-start;
      width: 100%;
      box-sizing: border-box;
  }
  .workflow-left {
      width: 320px;
      background: #0d47a1;
      border-radius: 22px;
      padding: 24px 20px;
      box-sizing: border-box;
      flex-shrink: 0;
      color: white;
      min-height: 640px;
  }
  .workflow-left-title {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 10px;
      line-height: 1.25;
      color: #ffffff;
  }
  .workflow-left-subtitle {
      font-size: 14px;
      line-height: 1.5;
      color: #dbe8ff;
      margin-bottom: 24px;
  }
  .section-label {
      font-size: 14px;
      font-weight: 700;
      color: #ffffff;
      margin-top: 18px;
      margin-bottom: 8px;
  }
  .upload-box {
      border: 2px dashed rgba(255,255,255,0.45);
      border-radius: 16px;
      padding: 22px 16px;
      text-align: center;
      color: #dbe8ff;
      background: rgba(255,255,255,0.06);
      margin-bottom: 18px;
  }
  .upload-box-title {
      font-size: 15px;
      font-weight: 700;
      margin-bottom: 6px;
      color: #ffffff;
  }
  .upload-box-subtext {
      font-size: 13px;
      color: #dbe8ff;
      line-height: 1.4;
  }
  .workflow-right {
      flex: 1;
      min-width: 0;
      box-sizing: border-box;
  }
  .workflow-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 24px;
  }
  .content-card {
      background: #ffffff;
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 22px;
      box-sizing: border-box;
      margin-bottom: 18px;
  }
  .content-card-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .content-card-subtitle {
      font-size: 14px;
      color: #6b7280;
      margin-bottom: 18px;
      line-height: 1.5;
  }
  .status-box {
      background: #fff4db;
      border: 1px solid #f4d58d;
      color: #8a6514;
      border-radius: 14px;
      padding: 14px 16px;
      font-size: 14px;
      font-weight: 600;
  }
  .preview-box {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 14px;
      padding: 26px 18px;
      text-align: center;
      color: #64748b;
      font-size: 14px;
  }
  .stFileUploader {
      background: transparent;
  }
  .stSelectbox > div > div {
      border-radius: 12px;
  }
  .stButton > button {
      width: 100%;
      border-radius: 12px;
      min-height: 42px;
      font-weight: 700;
  }
  @media (max-width: 1200px) {
      .workflow-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .workflow-shell {
          flex-direction: column;
      }
      .workflow-left {
          width: 100%;
          min-height: auto;
      }
      .workflow-topbar {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 600px) {
      .workflow-topbar {
          grid-template-columns: 1fr;
      }
  }
  """

def get_classify_page_css():
  return """
  .classify-left-panel {
      background: #0f4f70;
      border-radius: 22px;
      padding: 20px 10px 400px 20px;
      min-height: 620px;
      box-sizing: border-box;
      color: #ffffff;
  }
  .classify-logo-wrap {
      margin-bottom: 22px;
  }
  .classify-logo-img {
      width: 250px;
      max-width: 100%;
      display: block;
  }
  .classify-title {
      font-size: 18px;
      font-weight: 700;
      color: #ffd8cc;
      margin-bottom: 8px;
      line-height: 1.3;
  }
  .classify-subtitle {
      font-size: 13px;
      font-weight: 600;
      color: #dbe8ff;
      line-height: 1.35;
      margin-bottom: 28px;
  }
  .left-group-title {
      font-size: 14px;
      font-weight: 700;
      color: #ffffff;
      margin-top: 10px;
      margin-bottom: 20px;
  }
  .left-divider {
      border: none;
      height: 1px;
      background: rgba(255,255,255,0.18);
      margin-top: 18px;
      margin-bottom: 18px;
  }
  .left-menu-form {
      margin: 0 0 10px 0;
  }
  .left-menu-btn {
      width: 100%;
      border: 1px solid #d7d9dd;
      border-radius: 14px;
      padding: 13px 14px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      background: #f7f7f8;
      color: #4b5563;
      box-sizing: border-box;
      font-family: inherit;
      appearance: none;
      -webkit-appearance: none;
  }
  .left-menu-btn.active {
      background: #f44747;
      color: #ffffff;
      border: 1px solid #f44747;
  }
  .classify-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 22px;
  }
  .page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  .panel-title {
      font-size: 15px;
      font-weight: 700;
      color: #4b5563;
      margin-bottom: 10px;
  }
  .upload-hint-box {
      background: #dce9fb;
      border: 1px solid #c9daf4;
      border-radius: 12px;
      padding: 14px 16px;
      color: #4177bb;
      font-size: 14px;
      font-weight: 600;
      margin-top: 14px;
      margin-bottom: 18px;
  }
  .section-card {
      background: linear-gradient(135deg, #163454 0%, #264a6d 100%);
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 8px;
      box-sizing: border-box;
      margin-top: 0.2px;
  }
  .section-card-title {
      font-size: 18px;
      font-weight: 800;
      color: #ffffff;
      margin-bottom: 8px;
  }
  .section-card-subtitle {
      font-size: 12px;
      color: rgba(255,255,255,0.82);
      line-height: 0.5;
      margin-bottom: 14px;
  }
  .empty-state-box {
      background: #f8fafc;
      border: 1px dashed #cbd5e1;
      border-radius: 14px;
      padding: 28px 18px;
      text-align: center;
      color: #64748b;
      font-size: 14px;
  }
  .runs-placeholder {
      background: #ffffff;
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 24px;
      margin-top: 18px;
  }
  .runs-placeholder-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 8px;
  }
  .runs-placeholder-text {
      font-size: 14px;
      color: #6b7280;
      line-height: 1.5;
  }
  .runs-header-cell {
      background: #4b5563;
      color: #ffffff;
      border-radius: 12px;
      padding: 20px 10px;
      padding-top: 5px;
      padding-bottom: 5px;
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 8px;
  }
  .runs-cell {
      padding-top: 10px;
      padding-bottom: 10px;
      font-size: 14px;
      color: #374151;
      word-break: break-word;
  }
  .status-pill {
   display: inline-block;
   padding: 5px 12px;
   border-radius: 999px;
   color: #ffffff;
   font-size: 12px;
   font-weight: 700;
   }
  .status-pill.uploaded {
   background: #64748b;
   }
  .status-pill.submitted {
   background: #f59e0b;
   }
  .status-pill.running {
   background: #2563eb;
   }
  .status-pill.completed {
   background: #16a34a;
   }
  .status-pill.failed {
   background: #dc2626;
   }
  .status-pill.stopped {
   background: #64748b;
   }
  .status-pill.aborted {
   background: #64748b;
   }
  .status-pill.pending {
   background: #f59e0b;
   }
  .status-pill.in_progress {
   background: #2563eb;
   }
  .run-meta-card {
      background: #ffffff;
      border: 1px solid #e4e7ec;
      border-radius: 18px;
      padding: 18px;
      margin-bottom: 18px;
  }
  .run-meta-title {
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .run-meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;
      gap: 12px;
  }
  .run-meta-item {
      background: #f8fafc;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 12px;
  }
  .run-meta-label {
      font-size: 12px;
      color: #6b7280;
      margin-bottom: 4px;
      font-weight: 600;
  }
  .run-meta-value {
      font-size: 14px;
      color: #111827;
      font-weight: 700;
      word-break: break-word;
  }
  .pagination-summary {
      text-align: center;
      font-size: 16px;
      font-weight: 700;
      color: #374151;
      padding-top: 8px;
  }
  .pagination-right-label {
      font-size: 12px;
      font-weight: 700;
      color: #6b7280;
      margin-bottom: 4px;
  }
  .pagination-table-wrap {
      margin-top: 6px;
  }
  .stFileUploader {
      margin-bottom: 0.25rem;
  }
  @media (max-width: 1200px) {
      .classify-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
      .run-meta-grid {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .classify-topbar {
          grid-template-columns: 1fr 1fr;
      }
      .run-meta-grid {
          grid-template-columns: 1fr;
      }
  }
  @media (max-width: 600px) {
      .classify-topbar {
          grid-template-columns: 1fr;
      }
  }
  """
######################## Validation CSS ###################################################
def get_validation_page_css():
  return """
  .validation-topbar {
      background: #e3e5ea;
      border-radius: 18px;
      padding: 8px;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr 1fr 1fr;
      gap: 14px;
      box-sizing: border-box;
      width: 100%;
      margin-bottom: 22px;
  }
  .validation-page-divider {
      border: none;
      height: 1px;
      background: #d2d6dc;
      margin-top: 10px;
      margin-bottom: 24px;
  }
  .validation-summary-chip {
      display: inline-block;
      background: #eef2ff;
      border: 1px solid #c7d2fe;
      border-radius: 999px;
      padding: 6px 12px;
      font-size: 12px;
      font-weight: 700;
      color: #4338ca;
      margin-right: 8px;
      margin-bottom: 8px;
  }
  .validation-help-box {
      background: #dce9fb;
      border: 1px solid #c9daf4;
      border-radius: 12px;
      padding: 14px 16px;
      color: #4177bb;
      font-size: 14px;
      font-weight: 600;
      margin-top: 14px;
      margin-bottom: 18px;
  }
  .validation-record-header {
      font-size: 22px;
      font-weight: 700;
      color: #111827;
      margin-bottom: 12px;
  }
  .validation-subtitle {
      font-size: 14px;
      color: #6b7280;
      line-height: 1.5;
      margin-bottom: 14px;
  }
  .validation-label {
      font-size: 13px;
      font-weight: 700;
      color: #374151;
      margin-bottom: 8px;
  }
  .validation-display-box {
      background: #ffffff;
      border: 1px solid #dfe3ea;
      border-radius: 16px;
      padding: 16px 18px;
      min-height: 150px;
      color: #111827;
      line-height: 1.6;
      font-size: 15px;
      box-sizing: border-box;
      overflow-wrap: anywhere;
      white-space: pre-wrap;
  }
  .validation-display-box.compact {
      min-height: 120px;
  }
  .validation-display-box.description-box {
      min-height: 150px;
  }
  .validation-shortdesc {
      font-size: 16px;
      font-weight: 700;
      color: #111827;
      line-height: 1.5;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .validation-explanation {
      font-size: 15px;
      font-weight: 500;
      color: #1f2937;
      line-height: 1.7;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .validation-review-header-bar {
  display: grid;
  grid-template-columns: 1.8fr 2.8fr 2.2fr 2.8fr 1.4fr 1.1fr;
  gap: 18px;
  background: #dce9fb;
  border: 1px solid #c9daf4;
  border-radius: 16px;
  padding: 14px 18px;
  margin-bottom: 14px;
  align-items: center;
  }
  .validation-review-header-cell {
  font-size: 14px;
  font-weight: 800;
  color: #334155;
  }  
  .pred-desc-entry {
      margin-bottom: 18px;
  }
  .pred-desc-code {
      font-size: 16px;
      font-weight: 800;
      color: #111827;
      margin-bottom: 6px;
  }
  .pred-desc-text {
      font-size: 15px;
      color: #4b5563;
      line-height: 1.6;
      white-space: pre-wrap;
      overflow-wrap: anywhere;
  }
  .pred-desc-missing {
      font-size: 14px;
      color: #9ca3af;
      font-style: italic;
  }
  @media (max-width: 1200px) {
      .validation-topbar {
          grid-template-columns: 1fr 1fr 1fr;
      }
  }
  @media (max-width: 900px) {
      .validation-topbar {
          grid-template-columns: 1fr 1fr;
      }
  }
  @media (max-width: 600px) {
      .validation-topbar {
          grid-template-columns: 1fr;
      }
  }
  """